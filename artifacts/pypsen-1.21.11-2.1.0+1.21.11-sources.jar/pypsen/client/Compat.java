package pypsen.client;

import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_2394;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/** Compatibility helpers for the 1.21+ networking/component API. */
public final class Compat {
    private Compat() {}

    public static class_243 entityPos(class_1297 e) {
        return new class_243(e.method_23317(), e.method_23318(), e.method_23321());
    }

    public static class_243 cameraPos(class_4184 camera) {
        return camera.method_71156();
    }

    public static void addParticle(class_638 world, class_2394 effect,
                                   double x, double y, double z,
                                   double vx, double vy, double vz) {
        world.method_8466(effect, false, false, x, y, z, vx, vy, vz);
    }

    public static float moveForward(class_746 p) {
        var i = p.field_3913.field_54155;
        return (i.comp_3159() ? 1f : 0f) - (i.comp_3160() ? 1f : 0f);
    }

    public static float moveSideways(class_746 p) {
        var i = p.field_3913.field_54155;
        return (i.comp_3162() ? 1f : 0f) - (i.comp_3161() ? 1f : 0f);
    }

    public static boolean isSword(class_1799 stack) {
        return stack.method_31573(class_3489.field_42611);
    }

    public static boolean isAxe(class_1799 stack) {
        return stack.method_31573(class_3489.field_42612);
    }

    public static boolean isArmor(class_1799 stack) {
        return stack.method_31573(class_3489.field_48297) || stack.method_31573(class_3489.field_48296)
            || stack.method_31573(class_3489.field_48295) || stack.method_31573(class_3489.field_48294);
    }

    public static int armorSlot(class_1799 stack) {
        if (stack.method_31573(class_3489.field_48297)) return 0;
        if (stack.method_31573(class_3489.field_48296)) return 1;
        if (stack.method_31573(class_3489.field_48295)) return 2;
        if (stack.method_31573(class_3489.field_48294)) return 3;
        return -1;
    }

    private static final class_1304[] ARMOR_SLOTS = {
        class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166
    };

    public static class_1799 armorStack(class_1657 p, int type) {
        if (type < 0 || type >= ARMOR_SLOTS.length) return class_1799.field_8037;
        return p.method_6118(ARMOR_SLOTS[type]);
    }

    public static int enchantLevel(class_1799 stack, String id) {
        var world = class_310.method_1551().field_1687;
        if (world == null || stack.method_7960()) return 0;
        var registry = world.method_30349().method_30530(class_7924.field_41265);
        return registry.method_10223(class_2960.method_60655("minecraft", id))
            .map(entry -> class_1890.method_8225(entry, stack))
            .orElse(0);
    }

    private static int armorProtection(class_1799 stack) {
        String path = class_7923.field_41178.method_10221(stack.method_7909()).method_12832();
        if (path.contains("netherite")) return 5;
        if (path.contains("diamond")) return 4;
        if (path.contains("iron")) return 3;
        if (path.contains("chain")) return 2;
        if (path.contains("turtle")) return 2;
        return 1;
    }

    public static int getArmorScore(class_1799 stack) {
        if (!isArmor(stack)) return -1;
        return armorProtection(stack) + enchantLevel(stack, "protection");
    }

    public static float weaponDamage(class_1799 stack) {
        float damage = isSword(stack) ? 4f : isAxe(stack) ? 7f : 0f;
        if (damage <= 0f) return -1f;
        return damage + enchantLevel(stack, "sharpness") * 0.5f;
    }

    public static int findBestWeapon(class_746 p, boolean preferAxe) {
        int bestSlot = -1;
        float bestDamage = -1f;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = p.method_31548().method_5438(i);
            float damage = weaponDamage(stack);
            if (damage < 0f) continue;
            if (preferAxe && isAxe(stack)) damage += 1000f;
            if (damage > bestDamage) {
                bestDamage = damage;
                bestSlot = i;
            }
        }
        return bestSlot;
    }
}
