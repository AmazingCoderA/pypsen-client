package pypsen.client.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pypsen.client.PypsenClient;

@Mixin(class_1297.class)
public class EntityMixin {

    @Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true)
    private void pypsen$hitbox(CallbackInfoReturnable<Float> cir) {
        if (PypsenClient.hitboxOn && (Object) this instanceof class_1309 && !((Object) this instanceof class_746)) {
            cir.setReturnValue(PypsenClient.hitboxVal);
        }
    }

    @Inject(method = "getDimensions", at = @At("RETURN"), cancellable = true)
    private void pypsen$getDimensions(class_4050 pose, CallbackInfoReturnable<class_4048> cir) {
        if (PypsenClient.hitboxOn && (Object) this instanceof class_1309 && !((Object) this instanceof class_746)) {
            cir.setReturnValue(cir.getReturnValue().method_18383(PypsenClient.hitboxVal));
        }
    }

    @Inject(method = "pushAwayFrom", at = @At("HEAD"), cancellable = true)
    private void pypsen$pushAwayFrom(class_1297 entity, CallbackInfo ci) {
        if (PypsenClient.velocityOn && (Object) this instanceof class_746) {
            ci.cancel();
        }
    }

    @Inject(method = "isInvisibleTo", at = @At("HEAD"), cancellable = true)
    private void pypsen$isInvisibleTo(class_1657 player, CallbackInfoReturnable<Boolean> cir) {
        if (PypsenClient.seeInvisOn) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "slowMovement", at = @At("HEAD"), cancellable = true)
    private void pypsen$slowMovement(net.minecraft.class_2680 state, net.minecraft.class_243 multiplier, CallbackInfo ci) {
        if (PypsenClient.noWebOn && (Object) this instanceof class_746) {
            if (PypsenClient.noWebMode == 0 || PypsenClient.noWebMode == 1) {
                ci.cancel();
            } else if (PypsenClient.noWebMode == 2) {
                // Grim: just reduce the effect slightly, handled in tick if needed, or just cancel here
                ci.cancel();
            }
        }
    }
}

