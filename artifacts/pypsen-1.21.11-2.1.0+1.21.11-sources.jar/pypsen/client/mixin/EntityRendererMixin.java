package pypsen.client.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pypsen.client.PypsenClient;

@Mixin(class_897.class)
public abstract class EntityRendererMixin<T extends class_1297> {
    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true)
    private void onHasLabel(T entity, CallbackInfoReturnable<Boolean> cir) {
        if (PypsenClient.playerEspOn && entity instanceof class_1657) {
            cir.setReturnValue(true);
        }
    }

    @ModifyVariable(method = "renderLabelIfPresent", at = @At("HEAD"), ordinal = 0, argsOnly = true)
    private class_2561 modifyLabel(class_2561 text, T entity) {
        if (PypsenClient.nameHiderOn && text != null && class_310.method_1551().method_1548() != null) {
            String myName = class_310.method_1551().method_1548().method_1676();
            String str = text.getString();
            if (str.contains(myName)) {
                return class_2561.method_43470(str.replace(myName, PypsenClient.fakeName));
            }
        }
        return text;
    }
}
