package pypsen.client.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import pypsen.client.PypsenClient;

@Mixin(class_338.class)
public class ChatHudMixin {
    @ModifyVariable(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V", at = @At("HEAD"), ordinal = 0, argsOnly = true)
    private class_2561 modifyChatMessage(class_2561 message) {
        if (PypsenClient.nameHiderOn && message != null && class_310.method_1551().method_1548() != null) {
            String myName = class_310.method_1551().method_1548().method_1676();
            String str = message.getString();
            if (str.contains(myName)) {
                return class_2561.method_43470(str.replace(myName, PypsenClient.fakeName));
            }
        }
        return message;
    }
}
