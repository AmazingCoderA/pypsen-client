package pypsen.client.mixin;

import net.minecraft.class_2664;
import net.minecraft.class_2743;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pypsen.client.PypsenClient;

@Mixin(class_634.class)
public class NetworkMixin {

    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void pypsen$onVelocity(class_2743 packet, CallbackInfo ci) {
        if (PypsenClient.velocityOn && class_310.method_1551().field_1724 != null) {
            if (packet.method_11818() == class_310.method_1551().field_1724.method_5628()) {
                ci.cancel();
            }
        }
    }

    @Inject(method = "onExplosion", at = @At("HEAD"), cancellable = true)
    private void pypsen$onExplosion(class_2664 packet, CallbackInfo ci) {
        if (PypsenClient.velocityOn) {
            // Отменяем отталкивание от взрывов
            ci.cancel();
        }
    }
}
