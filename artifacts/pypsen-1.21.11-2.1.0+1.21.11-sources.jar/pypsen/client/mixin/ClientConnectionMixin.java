package pypsen.client.mixin;

import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pypsen.client.PypsenClient;
import pypsen.client.PypsenFeatures;

@Mixin(class_2535.class)
public class ClientConnectionMixin {
    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void onSend(class_2596<?> packet, CallbackInfo ci) {
        if (PypsenFeatures.onSendPacket(packet)) {
            ci.cancel();
            return;
        }
        if (PypsenClient.freecamOn && packet instanceof class_2828) {
            ci.cancel();
        }
        if (PypsenClient.freezeOn && PypsenClient.freezeMode == 1 && packet instanceof class_2828) {
            ci.cancel();
        }
    }
}
