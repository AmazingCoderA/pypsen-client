package pypsen.client.mixin;

import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pypsen.client.PypsenClient;

@Mixin(class_2248.class)
public class BlockMixin {

    @Inject(method = "shouldDrawSide", at = @At("HEAD"), cancellable = true)
    private static void pypsen$xray(class_2680 state, class_1922 world,
                                    class_2338 pos, class_2350 side,
                                    class_2338 otherPos,
                                    CallbackInfoReturnable<Boolean> cir) {
        if (PypsenClient.xrayOn) {
            cir.setReturnValue(PypsenClient.xrayShouldDrawSide(state.method_26204(), side));
        }
    }
}
