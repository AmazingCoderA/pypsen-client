package pypsen.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7923;
import org.lwjgl.glfw.GLFW;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

/**
 * Extra feature pack: AI aura, crystal aura, food, fake lag and advanced visuals.
 * Kept in its own class so every existing module stays intact.
 */
public final class PypsenFeatures {

    // ── TOGGLES ──
    public static boolean aiAuraOn = false, crystalAuraOn = false, fakeLagOn = false;
    public static boolean autoEatOn = false, noclipProOn = false, spiderProOn = false;
    public static boolean advancedVisualsOn = true, nameTagDetailsOn = true, hudRainbow = false;
    // AI KillAura upgrades
    public static boolean aiUseLearning = true, aiAutoTrain = true, aiAutoSave = false;
    public static boolean aiFocusTarget = true, aiOnlyPlayers = false;
    // Crystal Aura upgrades
    public static boolean crystalSafety = true, crystalAutoSwitch = true, crystalRotate = true;
    public static boolean crystalOffHand = false, crystalOnlyPlayers = false;

    // ── VALUES ──
    public static float aiRange = 6f, aiCps = 10f, crystalRange = 6f, crystalCps = 8f;
    public static float fakeLagDelay = 120f, autoEatHealth = 14f, autoEatHunger = 12f;
    public static float spiderBoost = 0.14f, noclipStep = 0.35f;
    public static int aiSamples = 300;
    // AI learning values
    public static float aiLearningRate = 0.15f, aiModelInfluence = 0.7f, aiSmooth = 1f;
    public static float aiJitter = 0f, aiTimingJitter = 20f, aiSwitchDelay = 180f;
    public static int aiTrainRounds = 60;
    // Crystal placement values
    public static float crystalPlaceRange = 5f, crystalPlaceDelay = 160f, crystalPredict = 0f;
    public static float crystalMinHp = 0f, crystalSelfDmg = 8f, crystalTotemHp = 0.5f;
    public static float crystalFaceArmor = 6f, crystalFaceHp = 8f;
    public static int crystalMaxCrystals = 2;

    // ── MODES ──
    public static int aiPreset = 0, crystalMode = 0, fakeLagMode = 0, spiderProMode = 0;
    public static int noclipProMode = 0, hudStyle = 1;
    public static int aiTargetMode = 0, aiRotationMode = 0;
    public static int crystalTargetMode = 0, crystalPlaceMode = 0;
    public static final String[] AI_PRESETS = {"Balanced", "Aggressive", "Legit", "HvH", "Smart"};
    public static final String[] AI_TARGET_MODES = {"AI Score", "Lowest HP", "Closest", "Shield First", "Armor Break"};
    public static final String[] AI_ROTATION_MODES = {"Instant", "Smooth", "Jitter", "No Rotate"};
    public static final String[] CRYSTAL_MODES = {"Attack + Place", "Attack Only", "Smart Danger",
        "AntiTotem Rush", "FacePlace", "Crystal Storm", "Safe Hybrid"};
    public static final String[] CRYSTAL_TARGET_MODES = {"Smart", "Closest", "Lowest HP", "No Shield", "High Armor"};
    public static final String[] CRYSTAL_PLACE_MODES = {"Feet", "Head", "Offset", "Smart Angle"};
    public static final String[] FAKELAG_MODES = {"Motion", "All C2S", "Burst"};
    public static final String[] SPIDER_PRO_MODES = {"Wall Climb", "AntiStuck", "Phase Jump", "Turbo"};
    public static final String[] NOCLIP_PRO_MODES = {"Phantom", "Phase Step", "Compact", "Ghost"};
    public static final String[] HUD_STYLES = {"Classic", "Modern", "Minimal", "Compact", "Rainbow"};

    // ── KEYBINDS ──
    public static int keyAiAura = GLFW.GLFW_KEY_UNKNOWN;
    public static int keyCrystalAura = GLFW.GLFW_KEY_UNKNOWN;
    public static int keyFakeLag = GLFW.GLFW_KEY_UNKNOWN;
    public static int keyAutoEat = GLFW.GLFW_KEY_UNKNOWN;
    public static int keyNoclipPro = GLFW.GLFW_KEY_UNKNOWN;
    public static int keySpiderPro = GLFW.GLFW_KEY_UNKNOWN;
    public static int keyVisualsPro = GLFW.GLFW_KEY_UNKNOWN;

    public static String aiTrainFile = "pypsen_ai.txt";

    // ── RUNTIME STATE ──
    private static final List<class_2596<?>> packets = new ArrayList<>();
    private static final Set<Integer> pressedFeatureKeys = new HashSet<>();
    private static final List<double[]> training = new ArrayList<>();
    private static final Random random = new Random();
    private static boolean flushing = false;
    private static double[] presetWeights = {0.35, 0.25, 0.20, 0.10, 0.10, 0.20, 0.02, 1.0};
    private static double[] weights = presetWeights.clone();
    private static class_1309 aiTarget = null;
    private static File runDir = null;
    private static long lastFlush = 0L, lastAiAttack = 0L, lastCrystal = 0L, lastEat = 0L;
    private static long lastAiSwitch = 0L, lastCrystalPlace = 0L, lastAutoTrain = 0L;
    private static int aiTick = 0, samplesLoaded = 0, samplesLearned = 0;
    public static double aiConfidence = 0.0;

    private PypsenFeatures() {}

    /** Called once by the main mod initializer. */
    public static void init(class_310 mc) {
        runDir = mc.field_1697;
        applyPreset(aiPreset);
        loadAiFile(mc.field_1697);
        if (aiAutoTrain) trainModel(aiTrainRounds);
    }

    /** Called from the main client tick handler. */
    public static void tick(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        var p = mc.field_1724;

        handleFakeLag(mc);
        tickAutoEat(mc, p);
        tickSpiderPro(p);
        tickNoclipPro(p);
        tickAiAura(mc, p);
        tickCrystalAura(mc, p);
        tickHudRainbow(mc);
    }

    /** Called from the main HUD render callback. */
    public static void render(class_332 ctx, class_310 mc) {
        if (!advancedVisualsOn || mc.field_1724 == null) return;
        class_1309 target = aiTarget != null && aiTarget.method_5805() ? aiTarget : PypsenClient.getAuraTarget();
        if (target == null) return;

        int sw = mc.method_22683().method_4486();
        int sh = mc.method_22683().method_4502();
        int x = hudStyle == 2 ? 4 : sw / 2 - 110;
        int y = hudStyle == 2 ? sh - 74 : sh / 2 - 74;
        int w = hudStyle == 3 ? 120 : 220;
        int h = hudStyle == 2 ? 46 : 70;

        int bg = hudRainbow ? rainbow(0x55) : 0x90081014;
        int accent = hudRainbow ? rainbow(0) : 0xFF55FF55;
        ctx.method_25294(x, y, x + w, y + h, bg);
        ctx.method_25294(x, y, x + w, y + 2, accent);

        float hp = target.method_6032();
        float maxHp = target.method_6063();
        String name = target.method_5477().getString();
        String line1 = "\u00a7f" + name;
        String line2 = "\u00a7c\u2764 " + String.format("%.1f", hp) + "/" + String.format("%.0f", maxHp)
            + " \u00a77| \u00a7b" + String.format("%.1fm", mc.field_1724.method_5739(target));
        String line3 = "\u00a77AI \u00a7f" + AI_PRESETS[clamp(aiPreset, 0, AI_PRESETS.length - 1)]
            + " \u00a77samples \u00a7f" + (samplesLoaded + samplesLearned);

        if (hudStyle == 0 || hudStyle == 1 || hudStyle == 4) {
            ctx.method_27535(mc.field_1772, class_2561.method_43470(line1), x + 6, y + 8, 0xFFFFFF);
            ctx.method_27535(mc.field_1772, class_2561.method_43470(line2), x + 6, y + 22, 0xFFFFFF);
            ctx.method_27535(mc.field_1772, class_2561.method_43470(line3), x + 6, y + 36, 0xFFFFFF);
        } else {
            ctx.method_27535(mc.field_1772, class_2561.method_43470(line1), x + 6, y + 8, 0xFFFFFF);
            ctx.method_27535(mc.field_1772, class_2561.method_43470(line2), x + 6, y + 22, 0xFFFFFF);
        }

        int barW = w - 12;
        int filled = maxHp <= 0 ? 0 : (int) (barW * Math.max(0f, Math.min(1f, hp / maxHp)));
        ctx.method_25294(x + 6, y + h - 12, x + 6 + barW, y + h - 6, 0xFF333333);
        ctx.method_25294(x + 6, y + h - 12, x + 6 + filled, y + h - 6, accent);

        if (nameTagDetailsOn && target instanceof class_1657 tp) {
            String tag = (PypsenClient.friends.contains(tp.method_5477().getString()) ? "\u00a7aFRIEND" : "\u00a7cENEMY")
                + (tp.method_6039() ? " \u00a7e[SHIELD]" : "")
                + " \u00a77armor " + tp.method_6096();
            ctx.method_27535(mc.field_1772, class_2561.method_43470(tag), x + 6, y + h - 28, 0xFFFFFF);
        }
    }

    private static int rainbow(int alpha) {
        int hue = (int) ((System.currentTimeMillis() / 12L) % 360);
        float r = 0.5f + 0.5f * (float) Math.cos(Math.toRadians(hue));
        float g = 0.5f + 0.5f * (float) Math.cos(Math.toRadians(hue + 120));
        float b = 0.5f + 0.5f * (float) Math.cos(Math.toRadians(hue + 240));
        int rr = (int) (r * 255), gg = (int) (g * 255), bb = (int) (b * 255);
        return alpha << 24 | rr << 16 | gg << 8 | bb;
    }

    // ══════════ AI KILLAURA ══════════

    private static void tickAiAura(class_310 mc, class_1657 p) {
        if (!aiAuraOn) { aiTarget = null; return; }
        if (!aiUseLearning) weights = presetWeights.clone();

        float range = Math.max(1f, aiRange);
        List<class_1309> candidates = new ArrayList<>();
        for (class_1297 e : mc.field_1687.method_8333(p, p.method_5829().method_1014(range), entity -> true)) {
            if (!(e instanceof class_1309 living) || !living.method_5805() || e == p || e.method_7325()) continue;
            if (PypsenClient.friends.contains(living.method_5477().getString())) continue;
            if (aiOnlyPlayers && !(living instanceof class_1657)) continue;
            if (p.method_5739(living) <= range) candidates.add(living);
        }

        class_1309 best = null;
        double bestScore = -1e9;
        for (class_1309 living : candidates) {
            double score = scoreTarget(p, living, p.method_5739(living), range);
            if (score > bestScore) { bestScore = score; best = living; }
        }

        long now = System.currentTimeMillis();
        if (aiFocusTarget && aiTarget != null && aiTarget.method_5805() && candidates.contains(aiTarget)
            && now - lastAiSwitch < (long) Math.max(0f, aiSwitchDelay)) {
            best = aiTarget;
        }
        if (best != aiTarget) {
            lastAiSwitch = now;
            aiTarget = best;
        }
        if (best == null) return;

        // Negative examples teach the model which targets NOT to pick, rate-limited.
        if (aiUseLearning && aiTick % 20 == 0 && candidates.size() > 1) {
            int added = 0;
            for (class_1309 living : candidates) {
                if (living == best || added >= 2) continue;
                recordSample(p, living, 0);
                added++;
            }
        }

        if (clamp(aiRotationMode, 0, AI_ROTATION_MODES.length - 1) != 3) {
            float[] rot = smartRotations(p, best);
            p.method_36456(rot[0]);
            p.method_36457(rot[1]);
        }

        long cooldown = (long) Math.max(1L, Math.round(20L / Math.max(1f, aiCps))) * 50L;
        long jitter = (long) Math.max(0f, aiTimingJitter);
        if (jitter > 0L) cooldown += (long) (random.nextDouble() * jitter);
        if (now - lastAiAttack >= cooldown) {
            lastAiAttack = now;
            mc.field_1761.method_2918(p, best);
            p.method_6104(class_1268.field_5808);
            if (aiUseLearning) recordSample(p, best, 1);
            int autoEvery = Math.max(100, clamp(aiSamples, 100, 2000) / 2);
            if (aiAutoTrain && samplesLearned > 0 && samplesLearned % autoEvery == 0) trainModel(aiTrainRounds);
        }
        aiTick++;
    }

    private static float[] smartRotations(class_1657 p, class_1309 t) {
        float[] target = rotations(p, t, eye(t));
        int mode = clamp(aiRotationMode, 0, AI_ROTATION_MODES.length - 1);
        if (mode == 0) return target;
        if (mode == 1) {
            float f = clamp(aiSmooth, 0f, 1f);
            return new float[]{
                p.method_36454() + MathHelperWrapDegrees(target[0] - p.method_36454()) * f,
                p.method_36455() + (target[1] - p.method_36455()) * f
            };
        }
        if (mode == 2) {
            float j = Math.max(0f, aiJitter);
            return new float[]{
                target[0] + (float) (random.nextDouble() * 2.0 - 1.0) * j,
                clamp(target[1] + (float) (random.nextDouble() * 2.0 - 1.0) * j, -90f, 90f)
            };
        }
        return target;
    }

    private static double scoreTarget(class_1657 p, class_1309 t, double dist, float range) {
        int mode = clamp(aiTargetMode, 0, AI_TARGET_MODES.length - 1);
        double hpPart = 1.0 - t.method_6032() / Math.max(1f, t.method_6063());
        double closePart = 1.0 - dist / Math.max(1f, range);
        if (mode == 1) return hpPart * 1000.0 + closePart * 50.0 - t.method_6096();
        if (mode == 2) return -dist;
        if (mode == 3) return (t.method_6039() ? 1000.0 : 0.0) + hpPart * 200.0 + closePart * 50.0;
        if (mode == 4) return t.method_6096() * 25.0 + hpPart * 300.0 + closePart * 50.0;

        double yawPart = 1.0 - Math.abs(MathHelperWrapDegrees(p.method_36454() - rotations(p, t, eye(t))[0])) / 180.0;
        double base = weights[0] * closePart
            + weights[1] * hpPart
            + weights[2] * yawPart
            + weights[3] * Math.min(1.0, t.method_6096() / 20.0)
            + weights[4] * (t.method_6039() ? 1.0 : 0.0)
            + weights[5] * hpPart
            + weights[6] * Math.min(1.0, (Math.abs(t.method_18798().field_1352) + Math.abs(t.method_18798().field_1350)) / 0.5)
            + weights[7] * 0.5;
        if (!aiUseLearning) return base * 100.0;

        double[] f = features(p, t);
        double model = sigmoid(dot(f, weights));
        aiConfidence = model;
        float influence = clamp(aiModelInfluence, 0f, 1f);
        return model * 100.0 * influence + base * 100.0 * (1.0 - influence);
    }

    private static class_243 eye(class_1309 e) {
        return new class_243(e.method_23317(), e.method_23318() + e.method_17682() * 0.5, e.method_23321());
    }

    private static float MathHelperWrapDegrees(float v) {
        while (v > 180f) v -= 360f;
        while (v < -180f) v += 360f;
        return v;
    }

    private static float[] rotations(class_1657 p, class_1297 target, class_243 pos) {
        double dx = pos.field_1352 - p.method_23317();
        double dy = pos.field_1351 - (p.method_23318() + p.method_18381(p.method_18376()));
        double dz = pos.field_1350 - p.method_23321();
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.max(0.0001, dist)));
        return new float[]{MathHelperWrapDegrees(yaw), Math.max(-90f, Math.min(90f, pitch))};
    }

    private static double[] features(class_1657 p, class_1309 t) {
        double d = p.method_5739(t);
        float yawDiff = Math.abs(MathHelperWrapDegrees(p.method_36454() - rotations(p, t, eye(t))[0]));
        float maxHp = Math.max(1f, t.method_6063());
        double lowHp = 1.0 - t.method_6032() / maxHp;
        return new double[]{
            Math.max(0.0, 1.0 - d / Math.max(1f, aiRange)),
            lowHp,
            1.0 - yawDiff / 180.0,
            Math.min(1.0, t.method_6096() / 20.0),
            t.method_6039() ? 1.0 : 0.0,
            lowHp,
            Math.min(1.0, (Math.abs(t.method_18798().field_1352) + Math.abs(t.method_18798().field_1350)) / 0.5),
            1.0
        };
    }

    private static void recordSample(class_1657 p, class_1309 t, double label) {
        double[] f = features(p, t);
        double[] s = new double[f.length + 1];
        System.arraycopy(f, 0, s, 0, f.length);
        s[f.length] = label;
        training.add(s);
        samplesLearned++;
        int max = clamp(aiSamples, 100, 2000);
        while (training.size() > max) training.remove(0);
        if (!aiUseLearning) return;
        double pred = sigmoid(dot(f, weights));
        double lr = clamp(aiLearningRate, 0f, 2f) / Math.max(1, training.size());
        for (int i = 0; i < weights.length && i < f.length; i++) {
            weights[i] += lr * (label - pred) * f[i];
        }
        normalizeWeights();
    }

    private static void normalizeWeights() {
        double sum = 0;
        for (int i = 0; i < weights.length; i++) sum += Math.max(0.001, weights[i]);
        for (int i = 0; i < weights.length; i++) weights[i] = Math.max(0.001, weights[i]) / sum;
    }

    private static double dot(double[] a, double[] b) {
        double result = 0;
        for (int i = 0; i < a.length && i < b.length; i++) result += a[i] * b[i];
        return result;
    }

    private static double sigmoid(double x) {
        double v = Math.max(-12.0, Math.min(12.0, x));
        return 1.0 / (1.0 + Math.exp(-v));
    }

    /** Batch-retrains the live model on the recorded sample file. */
    public static void trainModel(int rounds) {
        if (training.isEmpty()) return;
        int r = clamp(rounds, 1, 2000);
        double lr = clamp(aiLearningRate, 0f, 2f) * 0.25;
        for (int round = 0; round < r; round++) {
            for (double[] s : training) {
                if (s.length < 2) continue;
                double[] f = new double[s.length - 1];
                System.arraycopy(s, 0, f, 0, f.length);
                double label = s[s.length - 1];
                double pred = sigmoid(dot(f, weights));
                for (int i = 0; i < weights.length && i < f.length; i++) {
                    weights[i] += lr * (label - pred) * f[i];
                }
            }
            normalizeWeights();
        }
        lastAutoTrain = System.currentTimeMillis();
    }

    public static void resetLearning() {
        weights = presetWeights.clone();
        training.clear();
        samplesLoaded = 0;
        samplesLearned = 0;
        aiConfidence = 0.0;
    }

    public static int sampleCount() {
        return samplesLoaded + samplesLearned;
    }

    public static void applyPreset(int preset) {
        switch (clamp(preset, 0, AI_PRESETS.length - 1)) {
            case 1 -> presetWeights = new double[]{0.48, 0.28, 0.10, 0.06, 0.08, 0.28, 0.03, 1.0};
            case 2 -> presetWeights = new double[]{0.18, 0.14, 0.56, 0.06, 0.06, 0.14, 0.02, 1.0};
            case 3 -> presetWeights = new double[]{0.30, 0.20, 0.12, 0.24, 0.14, 0.22, 0.06, 1.0};
            case 4 -> presetWeights = new double[]{0.34, 0.32, 0.18, 0.10, 0.06, 0.34, 0.04, 1.0};
            default -> presetWeights = new double[]{0.35, 0.25, 0.20, 0.10, 0.10, 0.25, 0.02, 1.0};
        }
        weights = presetWeights.clone();
        normalizeWeights();
        presetWeights = weights.clone();
    }

    public static void loadAiFile(File runDir) {
        File f = new File(runDir, safeName(aiTrainFile));
        training.clear();
        samplesLoaded = 0;
        if (!f.isFile()) return;
        int max = clamp(aiSamples, 100, 2000);
        try (BufferedReader r = Files.newBufferedReader(f.toPath(), StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] parts = line.trim().split(",");
                double[] s;
                if (parts.length >= 9) {
                    s = new double[9];
                } else if (parts.length == 6) {
                    // Legacy 5-feature samples from the earlier AI version.
                    s = new double[9];
                    String label = parts[5];
                    parts = new String[]{parts[0], parts[1], parts[2], parts[3], parts[4],
                        "0", "0", "1", label};
                } else {
                    continue;
                }
                boolean ok = true;
                int features = s.length - 1;
                for (int i = 0; i < features; i++) {
                    try { s[i] = Double.parseDouble(parts[i]); } catch (NumberFormatException ex) { ok = false; break; }
                }
                if (!ok) continue;
                try { s[features] = Double.parseDouble(parts[features]); } catch (NumberFormatException ex) { continue; }
                if (training.size() >= max) training.remove(0);
                training.add(s);
                samplesLoaded++;
            }
        } catch (IOException ignored) {
        }
    }

    private static double parseSafe(String value) {
        try { return Double.parseDouble(value.trim()); } catch (NumberFormatException ex) { return 0; }
    }

    public static void saveAiFile(File runDir) {
        File f = new File(runDir, safeName(aiTrainFile));
        try (FileWriter w = new FileWriter(f, false)) {
            for (double[] s : training) {
                StringBuilder line = new StringBuilder();
                for (int i = 0; i < s.length; i++) {
                    if (i > 0) line.append(',');
                    line.append(String.format(Locale.ROOT, "%.5f", s[i]));
                }
                w.write(line.append('\n').toString());
            }
        } catch (IOException ignored) {
        }
    }

    private static String safeName(String name) {
        String s = name == null ? "" : name.trim();
        return s.isEmpty() ? "pypsen_ai.txt" : s.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    // ══════════ CRYSTAL AURA ══════════

    private static void tickCrystalAura(class_310 mc, class_1657 p) {
        if (!crystalAuraOn) return;
        int mode = clamp(crystalMode, 0, CRYSTAL_MODES.length - 1);
        long now = System.currentTimeMillis();
        double range = Math.max(1f, crystalRange);

        List<class_1511> crystals = new ArrayList<>();
        for (class_1297 e : mc.field_1687.method_8333(p, p.method_5829().method_1014(range), entity -> true)) {
            if (e instanceof class_1511 crystal && p.method_5739(crystal) <= range) crystals.add(crystal);
        }
        crystals.sort((a, b) -> Double.compare(crystalBreakScore(p, a), crystalBreakScore(p, b)));

        long cd = (long) Math.max(1L, Math.round(20L / Math.max(1f, crystalCps))) * 50L;
        if (!crystals.isEmpty() && now - lastCrystal >= cd) {
            class_1511 crystal = crystals.get(0);
            if (crystalRotate) {
                class_243 crystalEye = new class_243(crystal.method_23317(), crystal.method_23318() + crystal.method_17682() * 0.5, crystal.method_23321());
                float[] rot = rotations(p, crystal, crystalEye);
                p.method_36456(rot[0]);
                p.method_36457(rot[1]);
            }
            lastCrystal = now;
            mc.field_1761.method_2918(p, crystal);
            p.method_6104(class_1268.field_5808);
        }

        if (mode == 1) return;
        float placeDelay = crystalPlaceDelay;
        if (mode == 5) placeDelay *= 0.5f;
        if (now - lastCrystalPlace < Math.max(0f, placeDelay)) return;
        int maxCrystals = clamp(crystalMaxCrystals, 0, 8);
        if (maxCrystals <= 0 || crystals.size() >= maxCrystals) return;

        boolean holding = holdingCrystal(p);
        int slot = findCrystal(p);
        if (!crystalAutoSwitch && !holding) return;
        if (slot >= 0 && (crystalAutoSwitch || !holding)) selectSlot(p, slot);
        if (!holding && slot < 0) return;

        class_1309 enemy = findCrystalTarget(mc, p, range);
        if (enemy == null) return;
        float hpRatio = enemy.method_6032() / Math.max(1f, enemy.method_6063());
        if (mode == 3 && hpRatio > Math.max(0f, crystalTotemHp) && enemy.method_6067() <= 0f) return;
        if (mode == 4 && !(enemy.method_6096() <= crystalFaceArmor || enemy.method_6032() <= crystalFaceHp)) return;
        if (crystalMinHp > 0f && hpRatio > crystalMinHp && mode != 3 && mode != 4 && mode != 5) return;

        class_243 placePos = crystalPosition(p, enemy);
        if (!canPlaceSafely(p, placePos, mode)) return;

        float[] rot = rotations(p, enemy, placePos);
        p.method_36456(rot[0]);
        p.method_36457(rot[1]);
        if (crystalOffHand) {
            mc.field_1761.method_2919(p, class_1268.field_5810);
            p.method_6104(class_1268.field_5810);
        } else {
            mc.field_1761.method_2919(p, class_1268.field_5808);
            p.method_6104(class_1268.field_5808);
        }
        lastCrystalPlace = now;
    }

    private static double crystalBreakScore(class_1657 p, class_1511 crystal) {
        int mode = clamp(crystalTargetMode, 0, CRYSTAL_TARGET_MODES.length - 1);
        double d = p.method_5739(crystal);
        if (mode == 2) return d + (crystal.method_5805() ? 0.0 : 1000.0);
        if (mode == 3) return d * 0.75;
        if (mode == 4) return d * 0.5;
        return d;
    }

    private static class_1309 findCrystalTarget(class_310 mc, class_1657 p, double range) {
        class_1309 best = null;
        double bestScore = -1e9;
        int mode = clamp(crystalTargetMode, 0, CRYSTAL_TARGET_MODES.length - 1);
        double searchRange = Math.max(range, crystalPlaceRange);
        for (class_1297 e : mc.field_1687.method_8333(p, p.method_5829().method_1014(searchRange), entity -> true)) {
            if (!(e instanceof class_1309 living) || e == p || !living.method_5805() || e.method_7325()) continue;
            if (PypsenClient.friends.contains(living.method_5477().getString())) continue;
            if (crystalOnlyPlayers && !(living instanceof class_1657)) continue;
            double d = p.method_5739(living);
            if (d > searchRange) continue;
            double hp = 1.0 - living.method_6032() / Math.max(1f, living.method_6063());
            double close = 1.0 - d / Math.max(1f, searchRange);
            double score;
            switch (mode) {
                case 1 -> score = close * 1000.0;
                case 2 -> score = hp * 1000.0 + close * 50.0;
                case 3 -> score = (living.method_6039() ? 1000.0 : 0.0) + hp * 300.0 + close * 50.0;
                case 4 -> score = living.method_6096() * 40.0 + hp * 300.0 + close * 50.0;
                default -> score = hp * 500.0 + close * 250.0 - living.method_6067() * 5.0;
            }
            if (score > bestScore) { bestScore = score; best = living; }
        }
        return best;
    }

    private static class_243 crystalPosition(class_1657 p, class_1309 enemy) {
        int mode = clamp(crystalPlaceMode, 0, CRYSTAL_PLACE_MODES.length - 1);
        double ticks = Math.max(0f, crystalPredict);
        double x = enemy.method_23317() + enemy.method_18798().field_1352 * ticks;
        double y = enemy.method_23318() + 0.2;
        double z = enemy.method_23321() + enemy.method_18798().field_1350 * ticks;
        if (mode == 1) {
            y = enemy.method_23318() + enemy.method_17682();
        } else if (mode == 2) {
            x += 0.5;
            z += 0.5;
            y += 0.3;
        } else if (mode == 3) {
            double dx = p.method_23317() - x;
            double dz = p.method_23321() - z;
            double len = Math.max(0.001, Math.sqrt(dx * dx + dz * dz));
            x -= dx / len * 0.35;
            z -= dz / len * 0.35;
            y = enemy.method_23318() + enemy.method_17682() * 0.5;
        }
        return new class_243(x, y, z);
    }

    private static boolean canPlaceSafely(class_1657 p, class_243 pos, int mode) {
        if (mode == 3 || mode == 4 || mode == 5) return true;
        if (!crystalSafety && mode != 2 && mode != 6) return true;
        double dx = pos.field_1352 - p.method_23317();
        double dy = pos.field_1351 - p.method_23318();
        double dz = pos.field_1350 - p.method_23321();
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        float factor = Math.max(0f, 1f - (float) dist / 8f);
        float selfDamage = 12f * factor * factor;
        return p.method_6032() + p.method_6067() - selfDamage >= Math.max(0f, crystalSelfDmg);
    }

    private static boolean holdingCrystal(class_1657 p) {
        class_1799 main = p.method_6047();
        class_1799 off = p.method_6079();
        return (!main.method_7960() && main.method_7909() == net.minecraft.class_1802.field_8301)
            || (!off.method_7960() && off.method_7909() == net.minecraft.class_1802.field_8301);
    }

    private static int findCrystal(class_1657 p) {
        for (int i = 0; i < 9; i++) {
            class_1799 s = p.method_31548().method_5438(i);
            if (!s.method_7960() && s.method_7909() == net.minecraft.class_1802.field_8301) return i;
        }
        return -1;
    }

    // ══════════ AUTO EAT / FOOD ══════════

    private static void tickAutoEat(class_310 mc, class_1657 p) {
        if (!autoEatOn || mc.field_1755 != null) return;
        float hp = p.method_6032() + p.method_6067();
        int food = p.method_7344().method_7586();
        if (hp > autoEatHealth && food > autoEatHunger) return;
        if (System.currentTimeMillis() - lastEat < 350L) return;

        int slot = findFood(p);
        if (slot < 0) return;
        selectSlot(p, slot);
        lastEat = System.currentTimeMillis();
        mc.field_1761.method_2919(p, class_1268.field_5808);
        p.method_6104(class_1268.field_5808);
    }

    private static int findFood(class_1657 p) {
        int best = -1;
        float bestScore = -1f;
        for (int i = 0; i < 9; i++) {
            class_1799 s = p.method_31548().method_5438(i);
            if (s.method_7960()) continue;
            String path = class_7923.field_41178.method_10221(s.method_7909()).method_12832();
            float score = foodScore(path);
            if (score > bestScore) { bestScore = score; best = i; }
        }
        return best;
    }

    private static float foodScore(String path) {
        if (path.contains("golden_apple") || path.contains("enchanted_golden_apple")) return 5f;
        if (path.contains("apple")) return 3f;
        if (path.contains("stew") || path.contains("soup")) return 2.5f;
        if (path.contains("bread") || path.contains("cake") || path.contains("cookie")) return 2f;
        if (path.contains("meat") || path.contains("fish") || path.contains("chicken")) return 1.8f;
        if (path.contains("potato") || path.contains("carrot") || path.contains("melon")) return 1.2f;
        return -1f;
    }

    private static void selectSlot(class_1657 p, int slot) {
        if (slot < 0 || slot > 8) return;
        try {
            var inv = p.method_31548();
            try {
                inv.getClass().getField("selectedSlot").setInt(inv, slot);
                return;
            } catch (NoSuchFieldException ignored) {
            }
            inv.getClass().getMethod("setSelectedSlot", int.class).invoke(inv, slot);
        } catch (Exception ignored) {
        }
    }

    // ══════════ FAKE LAG ══════════

    /** Called by ClientConnectionMixin. Returns true when the packet was queued. */
    public static boolean onSendPacket(class_2596<?> packet) {
        if (flushing || !fakeLagOn) return false;
        if (PypsenClient.freecamOn || (PypsenClient.freezeOn && PypsenClient.freezeMode == 1)) return false;
        int mode = clamp(fakeLagMode, 0, FAKELAG_MODES.length - 1);
        boolean hold = mode == 1 || packet instanceof class_2828;
        if (!hold) return false;
        packets.add(packet);
        int max = mode == 2 ? 6 : 24;
        if (packets.size() > max) flushPackets();
        return true;
    }

    private static void handleFakeLag(class_310 mc) {
        if (!fakeLagOn || packets.isEmpty()) return;
        long delay = (long) Math.max(20L, fakeLagDelay);
        if (System.currentTimeMillis() - lastFlush >= delay) flushPackets();
    }

    public static void flushPackets() {
        if (packets.isEmpty() || flushing) return;
        flushing = true;
        try {
            class_310 mc = class_310.method_1551();
            if (mc.method_1562() != null) {
                for (class_2596<?> packet : packets) mc.method_1562().method_2883(packet);
            }
            packets.clear();
        } finally {
            flushing = false;
        }
        lastFlush = System.currentTimeMillis();
    }

    // ══════════ SPIDER / NOCLIP PRO ══════════

    private static void tickSpiderPro(class_1657 p) {
        if (!spiderProOn || !p.field_5976) return;
        int mode = clamp(spiderProMode, 0, SPIDER_PRO_MODES.length - 1);
        class_243 v = p.method_18798();
        switch (mode) {
            case 1 -> {
                double bx = Math.signum(v.field_1352) * 0.06;
                double bz = Math.signum(v.field_1350) * 0.06;
                p.method_5814(p.method_23317() + bx, p.method_23318(), p.method_23321() + bz);
                p.method_18800(v.field_1352, spiderBoost, v.field_1350);
            }
            case 2 -> {
                p.method_18800(v.field_1352, p.field_6012 % 4 == 0 ? spiderBoost * 1.5 : spiderBoost * 0.6, v.field_1350);
                if (p.field_6012 % 6 == 0) p.method_5814(p.method_23317(), p.method_23318() + 0.03, p.method_23321());
            }
            case 3 -> p.method_18800(v.field_1352 * 1.08, spiderBoost * 1.35, v.field_1350 * 1.08);
            default -> p.method_18800(v.field_1352, spiderBoost, v.field_1350);
        }
        p.field_6017 = 0f;
    }

    private static void tickNoclipPro(class_1657 p) {
        if (!noclipProOn) return;
        p.field_5960 = true;
        p.field_6017 = 0f;
        int mode = clamp(noclipProMode, 0, NOCLIP_PRO_MODES.length - 1);
        if (mode == 1 && p.field_6012 % 3 == 0) {
            class_243 dir = p.method_5828(1f).method_1021(noclipStep);
            p.method_5814(p.method_23317() + dir.field_1352, p.method_23318() + dir.field_1351, p.method_23321() + dir.field_1350);
        } else if (mode == 2 && p.field_6012 % 2 == 0) {
            p.method_5814(p.method_23317(), p.method_23318() + noclipStep, p.method_23321());
        } else if (mode == 3) {
            class_243 v = p.method_18798();
            p.method_18800(v.field_1352 * 0.98, Math.max(v.field_1351, -0.02), v.field_1350 * 0.98);
        }
    }

    private static void tickHudRainbow(class_310 mc) {
        if (!hudRainbow) return;
        // Colour is computed from wall-clock time in render(); nothing else needed.
    }

    // ══════════ KEY HANDLING ══════════

    public static void handleKey(long handle) {
        if (wasPressed(handle, keyAiAura)) aiAuraOn = !aiAuraOn;
        if (wasPressed(handle, keyCrystalAura)) crystalAuraOn = !crystalAuraOn;
        if (wasPressed(handle, keyFakeLag)) fakeLagOn = !fakeLagOn;
        if (wasPressed(handle, keyAutoEat)) autoEatOn = !autoEatOn;
        if (wasPressed(handle, keyNoclipPro)) noclipProOn = !noclipProOn;
        if (wasPressed(handle, keySpiderPro)) spiderProOn = !spiderProOn;
        if (wasPressed(handle, keyVisualsPro)) advancedVisualsOn = !advancedVisualsOn;
    }

    private static boolean wasPressed(long handle, int key) {
        if (key == GLFW.GLFW_KEY_UNKNOWN) return false;
        boolean down = GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
        if (down && pressedFeatureKeys.add(key)) return true;
        if (!down) pressedFeatureKeys.remove(key);
        return false;
    }

    public static void panic() {
        aiAuraOn = false;
        crystalAuraOn = false;
        fakeLagOn = false;
        autoEatOn = false;
        noclipProOn = false;
        spiderProOn = false;
        aiTarget = null;
        flushPackets();
    }

    // ══════════ CONFIG ══════════

    public static void save(FileWriter w) throws IOException {
        w.write("aiAuraOn=" + aiAuraOn + "\n");
        w.write("crystalAuraOn=" + crystalAuraOn + "\n");
        w.write("fakeLagOn=" + fakeLagOn + "\n");
        w.write("autoEatOn=" + autoEatOn + "\n");
        w.write("noclipProOn=" + noclipProOn + "\n");
        w.write("spiderProOn=" + spiderProOn + "\n");
        w.write("advancedVisualsOn=" + advancedVisualsOn + "\n");
        w.write("nameTagDetailsOn=" + nameTagDetailsOn + "\n");
        w.write("hudRainbow=" + hudRainbow + "\n");
        w.write("aiUseLearning=" + aiUseLearning + "\n");
        w.write("aiAutoTrain=" + aiAutoTrain + "\n");
        w.write("aiAutoSave=" + aiAutoSave + "\n");
        w.write("aiFocusTarget=" + aiFocusTarget + "\n");
        w.write("aiOnlyPlayers=" + aiOnlyPlayers + "\n");
        w.write("crystalSafety=" + crystalSafety + "\n");
        w.write("crystalAutoSwitch=" + crystalAutoSwitch + "\n");
        w.write("crystalRotate=" + crystalRotate + "\n");
        w.write("crystalOffHand=" + crystalOffHand + "\n");
        w.write("crystalOnlyPlayers=" + crystalOnlyPlayers + "\n");
        w.write("aiPreset=" + aiPreset + "\n");
        w.write("aiTargetMode=" + aiTargetMode + "\n");
        w.write("aiRotationMode=" + aiRotationMode + "\n");
        w.write("crystalMode=" + crystalMode + "\n");
        w.write("crystalTargetMode=" + crystalTargetMode + "\n");
        w.write("crystalPlaceMode=" + crystalPlaceMode + "\n");
        w.write("fakeLagMode=" + fakeLagMode + "\n");
        w.write("spiderProMode=" + spiderProMode + "\n");
        w.write("noclipProMode=" + noclipProMode + "\n");
        w.write("hudStyle=" + hudStyle + "\n");
        w.write("aiSamples=" + aiSamples + "\n");
        w.write("aiTrainRounds=" + aiTrainRounds + "\n");
        w.write("aiLearningRate=" + aiLearningRate + "\n");
        w.write("aiModelInfluence=" + aiModelInfluence + "\n");
        w.write("aiSmooth=" + aiSmooth + "\n");
        w.write("aiJitter=" + aiJitter + "\n");
        w.write("aiTimingJitter=" + aiTimingJitter + "\n");
        w.write("aiSwitchDelay=" + aiSwitchDelay + "\n");
        w.write("aiRange=" + aiRange + "\n");
        w.write("aiCps=" + aiCps + "\n");
        w.write("crystalRange=" + crystalRange + "\n");
        w.write("crystalCps=" + crystalCps + "\n");
        w.write("crystalPlaceRange=" + crystalPlaceRange + "\n");
        w.write("crystalPlaceDelay=" + crystalPlaceDelay + "\n");
        w.write("crystalPredict=" + crystalPredict + "\n");
        w.write("crystalMinHp=" + crystalMinHp + "\n");
        w.write("crystalSelfDmg=" + crystalSelfDmg + "\n");
        w.write("crystalTotemHp=" + crystalTotemHp + "\n");
        w.write("crystalFaceArmor=" + crystalFaceArmor + "\n");
        w.write("crystalFaceHp=" + crystalFaceHp + "\n");
        w.write("crystalMaxCrystals=" + crystalMaxCrystals + "\n");
        w.write("fakeLagDelay=" + fakeLagDelay + "\n");
        w.write("autoEatHealth=" + autoEatHealth + "\n");
        w.write("autoEatHunger=" + autoEatHunger + "\n");
        w.write("spiderBoost=" + spiderBoost + "\n");
        w.write("noclipStep=" + noclipStep + "\n");
        w.write("aiTrainFile=" + aiTrainFile + "\n");
        w.write("keyAiAura=" + keyAiAura + "\n");
        w.write("keyCrystalAura=" + keyCrystalAura + "\n");
        w.write("keyFakeLag=" + keyFakeLag + "\n");
        w.write("keyAutoEat=" + keyAutoEat + "\n");
        w.write("keyNoclipPro=" + keyNoclipPro + "\n");
        w.write("keySpiderPro=" + keySpiderPro + "\n");
        w.write("keyVisualsPro=" + keyVisualsPro + "\n");
        if (aiAutoSave && runDir != null) saveAiFile(runDir);
    }

    public static void load(String key, String val) {
        try {
            switch (key) {
                case "aiAuraOn" -> aiAuraOn = Boolean.parseBoolean(val);
                case "crystalAuraOn" -> crystalAuraOn = Boolean.parseBoolean(val);
                case "fakeLagOn" -> fakeLagOn = Boolean.parseBoolean(val);
                case "autoEatOn" -> autoEatOn = Boolean.parseBoolean(val);
                case "noclipProOn" -> noclipProOn = Boolean.parseBoolean(val);
                case "spiderProOn" -> spiderProOn = Boolean.parseBoolean(val);
                case "advancedVisualsOn" -> advancedVisualsOn = Boolean.parseBoolean(val);
                case "nameTagDetailsOn" -> nameTagDetailsOn = Boolean.parseBoolean(val);
                case "hudRainbow" -> hudRainbow = Boolean.parseBoolean(val);
                case "aiUseLearning" -> aiUseLearning = Boolean.parseBoolean(val);
                case "aiAutoTrain" -> aiAutoTrain = Boolean.parseBoolean(val);
                case "aiAutoSave" -> aiAutoSave = Boolean.parseBoolean(val);
                case "aiFocusTarget" -> aiFocusTarget = Boolean.parseBoolean(val);
                case "aiOnlyPlayers" -> aiOnlyPlayers = Boolean.parseBoolean(val);
                case "crystalSafety" -> crystalSafety = Boolean.parseBoolean(val);
                case "crystalAutoSwitch" -> crystalAutoSwitch = Boolean.parseBoolean(val);
                case "crystalRotate" -> crystalRotate = Boolean.parseBoolean(val);
                case "crystalOffHand" -> crystalOffHand = Boolean.parseBoolean(val);
                case "crystalOnlyPlayers" -> crystalOnlyPlayers = Boolean.parseBoolean(val);
                case "aiPreset" -> aiPreset = Integer.parseInt(val);
                case "aiTargetMode" -> aiTargetMode = Integer.parseInt(val);
                case "aiRotationMode" -> aiRotationMode = Integer.parseInt(val);
                case "crystalMode" -> crystalMode = Integer.parseInt(val);
                case "crystalTargetMode" -> crystalTargetMode = Integer.parseInt(val);
                case "crystalPlaceMode" -> crystalPlaceMode = Integer.parseInt(val);
                case "fakeLagMode" -> fakeLagMode = Integer.parseInt(val);
                case "spiderProMode" -> spiderProMode = Integer.parseInt(val);
                case "noclipProMode" -> noclipProMode = Integer.parseInt(val);
                case "hudStyle" -> hudStyle = Integer.parseInt(val);
                case "aiSamples" -> aiSamples = Integer.parseInt(val);
                case "aiTrainRounds" -> aiTrainRounds = Integer.parseInt(val);
                case "aiLearningRate" -> aiLearningRate = Float.parseFloat(val);
                case "aiModelInfluence" -> aiModelInfluence = Float.parseFloat(val);
                case "aiSmooth" -> aiSmooth = Float.parseFloat(val);
                case "aiJitter" -> aiJitter = Float.parseFloat(val);
                case "aiTimingJitter" -> aiTimingJitter = Float.parseFloat(val);
                case "aiSwitchDelay" -> aiSwitchDelay = Float.parseFloat(val);
                case "aiRange" -> aiRange = Float.parseFloat(val);
                case "aiCps" -> aiCps = Float.parseFloat(val);
                case "crystalRange" -> crystalRange = Float.parseFloat(val);
                case "crystalCps" -> crystalCps = Float.parseFloat(val);
                case "crystalPlaceRange" -> crystalPlaceRange = Float.parseFloat(val);
                case "crystalPlaceDelay" -> crystalPlaceDelay = Float.parseFloat(val);
                case "crystalPredict" -> crystalPredict = Float.parseFloat(val);
                case "crystalMinHp" -> crystalMinHp = Float.parseFloat(val);
                case "crystalSelfDmg" -> crystalSelfDmg = Float.parseFloat(val);
                case "crystalTotemHp" -> crystalTotemHp = Float.parseFloat(val);
                case "crystalFaceArmor" -> crystalFaceArmor = Float.parseFloat(val);
                case "crystalFaceHp" -> crystalFaceHp = Float.parseFloat(val);
                case "crystalMaxCrystals" -> crystalMaxCrystals = Integer.parseInt(val);
                case "fakeLagDelay" -> fakeLagDelay = Float.parseFloat(val);
                case "autoEatHealth" -> autoEatHealth = Float.parseFloat(val);
                case "autoEatHunger" -> autoEatHunger = Float.parseFloat(val);
                case "spiderBoost" -> spiderBoost = Float.parseFloat(val);
                case "noclipStep" -> noclipStep = Float.parseFloat(val);
                case "aiTrainFile" -> aiTrainFile = val;
                case "keyAiAura" -> keyAiAura = Integer.parseInt(val);
                case "keyCrystalAura" -> keyCrystalAura = Integer.parseInt(val);
                case "keyFakeLag" -> keyFakeLag = Integer.parseInt(val);
                case "keyAutoEat" -> keyAutoEat = Integer.parseInt(val);
                case "keyNoclipPro" -> keyNoclipPro = Integer.parseInt(val);
                case "keySpiderPro" -> keySpiderPro = Integer.parseInt(val);
                case "keyVisualsPro" -> keyVisualsPro = Integer.parseInt(val);
                default -> { }
            }
        } catch (NumberFormatException ignored) {
        }
    }

    public static void clamp() {
        aiPreset = clamp(aiPreset, 0, AI_PRESETS.length - 1);
        aiTargetMode = clamp(aiTargetMode, 0, AI_TARGET_MODES.length - 1);
        aiRotationMode = clamp(aiRotationMode, 0, AI_ROTATION_MODES.length - 1);
        crystalMode = clamp(crystalMode, 0, CRYSTAL_MODES.length - 1);
        crystalTargetMode = clamp(crystalTargetMode, 0, CRYSTAL_TARGET_MODES.length - 1);
        crystalPlaceMode = clamp(crystalPlaceMode, 0, CRYSTAL_PLACE_MODES.length - 1);
        fakeLagMode = clamp(fakeLagMode, 0, FAKELAG_MODES.length - 1);
        spiderProMode = clamp(spiderProMode, 0, SPIDER_PRO_MODES.length - 1);
        noclipProMode = clamp(noclipProMode, 0, NOCLIP_PRO_MODES.length - 1);
        hudStyle = clamp(hudStyle, 0, HUD_STYLES.length - 1);
        aiSamples = clamp(aiSamples, 100, 2000);
        aiTrainRounds = clamp(aiTrainRounds, 1, 2000);
        aiLearningRate = clamp(aiLearningRate, 0f, 2f);
        aiModelInfluence = clamp(aiModelInfluence, 0f, 1f);
        aiSmooth = clamp(aiSmooth, 0f, 1f);
        aiJitter = clamp(aiJitter, 0f, 15f);
        aiTimingJitter = clamp(aiTimingJitter, 0f, 500f);
        aiSwitchDelay = clamp(aiSwitchDelay, 0f, 2000f);
        aiRange = clamp(aiRange, 2f, 16f);
        aiCps = clamp(aiCps, 1f, 20f);
        crystalRange = clamp(crystalRange, 2f, 12f);
        crystalCps = clamp(crystalCps, 1f, 20f);
        crystalPlaceRange = clamp(crystalPlaceRange, 1f, 12f);
        crystalPlaceDelay = clamp(crystalPlaceDelay, 0f, 2000f);
        crystalPredict = clamp(crystalPredict, 0f, 10f);
        crystalMinHp = clamp(crystalMinHp, 0f, 1f);
        crystalSelfDmg = clamp(crystalSelfDmg, 0f, 20f);
        crystalTotemHp = clamp(crystalTotemHp, 0f, 1f);
        crystalFaceArmor = clamp(crystalFaceArmor, 0f, 20f);
        crystalFaceHp = clamp(crystalFaceHp, 0f, 20f);
        crystalMaxCrystals = clamp(crystalMaxCrystals, 0, 8);
        fakeLagDelay = clamp(fakeLagDelay, 20f, 1000f);
        autoEatHealth = clamp(autoEatHealth, 1f, 20f);
        autoEatHunger = clamp(autoEatHunger, 0f, 20f);
        spiderBoost = clamp(spiderBoost, 0.02f, 0.5f);
        noclipStep = clamp(noclipStep, 0.05f, 2f);
    }

    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    private static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }

    // ══════════ ADVANCED SETTINGS SCREEN ══════════

    public static class FeaturesScreen extends class_437 {
        private final class_437 parent;
        private int binding = -1;
        private int page = 0;
        private int y = 8;
        private static final int PAGE_COUNT = 6;

        public FeaturesScreen(class_437 parent) {
            super(class_2561.method_43470("Pypsen Advanced Features"));
            this.parent = parent;
        }

        @Override
        protected void method_25426() {
            int x = field_22789 / 2 - 150;
            int w = 300;
            y = 8;
            nav(x, y, w);

            switch (page) {
                case 0 -> {
                    toggle(x, y, w, "AI KillAura", aiAuraOn, v -> aiAuraOn = v);
                    cycle(x, y, w, "AI Preset", AI_PRESETS, aiPreset, v -> { aiPreset = v; applyPreset(v); });
                    cycle(x, y, w, "AI Target", AI_TARGET_MODES, aiTargetMode, v -> aiTargetMode = v);
                    cycle(x, y, w, "AI Rotation", AI_ROTATION_MODES, aiRotationMode, v -> aiRotationMode = v);
                    plusMinus(x, y, w, "AI Samples", aiSamples, 100, 2000, 100, v -> aiSamples = v);
                    plusMinusF(x, y, w, "AI Range", aiRange, 2f, 16f, 1f, v -> aiRange = v);
                    plusMinusF(x, y, w, "AI CPS", aiCps, 1f, 20f, 1f, v -> aiCps = v);
                    toggle(x, y, w, "Focus Target", aiFocusTarget, v -> aiFocusTarget = v);
                    toggle(x, y, w, "Players Only", aiOnlyPlayers, v -> aiOnlyPlayers = v);
                    bind(x, y, w, "AI Key", keyAiAura, 0);
                    addDrawable(button(x, y, w, "Load AI File", b -> loadAiFile(class_310.method_1551().field_1697)));
                    addDrawable(button(x, y, w, "Save AI File", b -> saveAiFile(class_310.method_1551().field_1697)));
                }
                case 1 -> {
                    toggle(x, y, w, "Use Learning", aiUseLearning, v -> aiUseLearning = v);
                    toggle(x, y, w, "Auto Train", aiAutoTrain, v -> aiAutoTrain = v);
                    toggle(x, y, w, "Auto Save AI", aiAutoSave, v -> aiAutoSave = v);
                    plusMinusF(x, y, w, "Influence", aiModelInfluence, 0f, 1f, 0.05f, v -> aiModelInfluence = v);
                    plusMinusF(x, y, w, "Learn Rate", aiLearningRate, 0f, 2f, 0.05f, v -> aiLearningRate = v);
                    plusMinus(x, y, w, "Train Rounds", aiTrainRounds, 1, 2000, 10, v -> aiTrainRounds = v);
                    plusMinusF(x, y, w, "Smooth", aiSmooth, 0f, 1f, 0.05f, v -> aiSmooth = v);
                    plusMinusF(x, y, w, "Rot Jitter", aiJitter, 0f, 15f, 0.5f, v -> aiJitter = v);
                    plusMinusF(x, y, w, "Hit Jitter ms", aiTimingJitter, 0f, 500f, 10f, v -> aiTimingJitter = v);
                    plusMinusF(x, y, w, "Switch ms", aiSwitchDelay, 0f, 2000f, 50f, v -> aiSwitchDelay = v);
                    addDrawable(button(x, y, w, "Train 100 Hits", b -> trainModel(100)));
                    addDrawable(button(x, y, w, "Train 500 Hits", b -> trainModel(500)));
                    addDrawable(button(x, y, w, "Train 2000 Hits", b -> trainModel(2000)));
                    addDrawable(button(x, y, w, "Reset Learning", b -> resetLearning()));
                }
                case 2 -> {
                    toggle(x, y, w, "Crystal Aura", crystalAuraOn, v -> crystalAuraOn = v);
                    cycle(x, y, w, "Mode", CRYSTAL_MODES, crystalMode, v -> crystalMode = v);
                    cycle(x, y, w, "Target", CRYSTAL_TARGET_MODES, crystalTargetMode, v -> crystalTargetMode = v);
                    cycle(x, y, w, "Place Pos", CRYSTAL_PLACE_MODES, crystalPlaceMode, v -> crystalPlaceMode = v);
                    plusMinusF(x, y, w, "Range", crystalRange, 2f, 12f, 1f, v -> crystalRange = v);
                    plusMinusF(x, y, w, "CPS", crystalCps, 1f, 20f, 1f, v -> crystalCps = v);
                    plusMinusF(x, y, w, "Place Range", crystalPlaceRange, 1f, 12f, 1f, v -> crystalPlaceRange = v);
                    plusMinusF(x, y, w, "Place Delay", crystalPlaceDelay, 0f, 2000f, 20f, v -> crystalPlaceDelay = v);
                    plusMinus(x, y, w, "Max Crystals", crystalMaxCrystals, 0, 8, 1, v -> crystalMaxCrystals = v);
                    toggle(x, y, w, "Auto Switch", crystalAutoSwitch, v -> crystalAutoSwitch = v);
                    toggle(x, y, w, "Rotate", crystalRotate, v -> crystalRotate = v);
                    bind(x, y, w, "Crystal Key", keyCrystalAura, 1);
                }
                case 3 -> {
                    toggle(x, y, w, "Safety Check", crystalSafety, v -> crystalSafety = v);
                    toggle(x, y, w, "Off Hand", crystalOffHand, v -> crystalOffHand = v);
                    toggle(x, y, w, "Players Only", crystalOnlyPlayers, v -> crystalOnlyPlayers = v);
                    plusMinusF(x, y, w, "Predict", crystalPredict, 0f, 10f, 0.5f, v -> crystalPredict = v);
                    plusMinusF(x, y, w, "Min HP %", crystalMinHp, 0f, 1f, 0.05f, v -> crystalMinHp = v);
                    plusMinusF(x, y, w, "Keep HP", crystalSelfDmg, 0f, 20f, 1f, v -> crystalSelfDmg = v);
                    plusMinusF(x, y, w, "Totem HP %", crystalTotemHp, 0f, 1f, 0.05f, v -> crystalTotemHp = v);
                    plusMinusF(x, y, w, "Face Armor", crystalFaceArmor, 0f, 20f, 1f, v -> crystalFaceArmor = v);
                    plusMinusF(x, y, w, "Face HP", crystalFaceHp, 0f, 20f, 1f, v -> crystalFaceHp = v);
                }
                case 4 -> {
                    toggle(x, y, w, "Fake Lag", fakeLagOn, v -> fakeLagOn = v);
                    cycle(x, y, w, "Lag Mode", FAKELAG_MODES, fakeLagMode, v -> fakeLagMode = v);
                    plusMinusF(x, y, w, "Lag Delay ms", fakeLagDelay, 20f, 1000f, 20f, v -> fakeLagDelay = v);
                    bind(x, y, w, "Lag Key", keyFakeLag, 2);
                    toggle(x, y, w, "Auto Eat", autoEatOn, v -> autoEatOn = v);
                    plusMinusF(x, y, w, "Eat at HP", autoEatHealth, 1f, 20f, 1f, v -> autoEatHealth = v);
                    plusMinusF(x, y, w, "Eat at Hunger", autoEatHunger, 0f, 20f, 1f, v -> autoEatHunger = v);
                    bind(x, y, w, "Eat Key", keyAutoEat, 3);
                    toggle(x, y, w, "Spider Pro", spiderProOn, v -> spiderProOn = v);
                    cycle(x, y, w, "Spider Mode", SPIDER_PRO_MODES, spiderProMode, v -> spiderProMode = v);
                    plusMinusF(x, y, w, "Boost", spiderBoost, 0.02f, 0.5f, 0.02f, v -> spiderBoost = v);
                    bind(x, y, w, "Spider Key", keySpiderPro, 4);
                    toggle(x, y, w, "Noclip Pro", noclipProOn, v -> noclipProOn = v);
                    cycle(x, y, w, "Noclip Mode", NOCLIP_PRO_MODES, noclipProMode, v -> noclipProMode = v);
                    plusMinusF(x, y, w, "Step", noclipStep, 0.05f, 2f, 0.05f, v -> noclipStep = v);
                    bind(x, y, w, "Noclip Key", keyNoclipPro, 5);
                }
                default -> {
                    toggle(x, y, w, "Advanced HUD", advancedVisualsOn, v -> advancedVisualsOn = v);
                    toggle(x, y, w, "Tag Details", nameTagDetailsOn, v -> nameTagDetailsOn = v);
                    toggle(x, y, w, "Rainbow HUD", hudRainbow, v -> hudRainbow = v);
                    cycle(x, y, w, "HUD Style", HUD_STYLES, hudStyle, v -> hudStyle = v);
                    bind(x, y, w, "Visuals Key", keyVisualsPro, 6);
                }
            }
        }

        private void nav(int x, int y, int w) {
            addDrawable(button(x, y, w, "\u00a7bPage " + (page + 1) + "/" + PAGE_COUNT + " - Next >>>",
                b -> { page = (page + 1) % PAGE_COUNT; rebuild(); }));
        }

        @Override
        public boolean method_25404(int keyCode, int scanCode, int modifiers) {
            if (binding >= 0 && keyCode != GLFW.GLFW_KEY_ESCAPE) {
                switch (binding) {
                    case 0 -> keyAiAura = keyCode;
                    case 1 -> keyCrystalAura = keyCode;
                    case 2 -> keyFakeLag = keyCode;
                    case 3 -> keyAutoEat = keyCode;
                    case 4 -> keySpiderPro = keyCode;
                    case 5 -> keyNoclipPro = keyCode;
                    case 6 -> keyVisualsPro = keyCode;
                    default -> { }
                }
                binding = -1;
                rebuild();
                return true;
            }
            return super.method_25404(keyCode, scanCode, modifiers);
        }

        private class_4185 button(int x, int y, int w, String label, java.util.function.Consumer<class_4185> onClick) {
            return class_4185.method_46430(class_2561.method_43470(label), onClick::accept).method_46434(x, y, w, 20).method_46431();
        }

        private void addDrawable(class_4185 b) { method_37063(b); y += 22; }

        private void toggle(int x, int y, int w, String label, boolean on, java.util.function.Consumer<Boolean> setter) {
            addDrawable(button(x, y, w, label + ": " + (on ? "\u00a7aON" : "\u00a7cOFF"),
                b -> { setter.accept(!on); rebuild(); }));
        }

        private void cycle(int x, int y, int w, String label, String[] options, int current, java.util.function.IntConsumer setter) {
            addDrawable(button(x, y, w, label + ": \u00a7b" + options[clamp(current, 0, options.length - 1)],
                b -> { setter.accept((current + 1) % options.length); rebuild(); }));
        }

        private void bind(int x, int y, int w, String label, int key, int id) {
            addDrawable(button(x, y, w, label + ": \u00a7e" + (binding == id ? "[...]" : keyLabel(key)),
                b -> { binding = id; rebuild(); }));
        }

        private String keyLabel(int key) {
            if (key == GLFW.GLFW_KEY_UNKNOWN) return "-";
            String name = GLFW.glfwGetKeyName(key, 0);
            return name == null || name.isEmpty() ? String.valueOf(key) : name.toUpperCase(Locale.ROOT);
        }

        private void plusMinus(int x, int y, int w, String label, int val, int min, int max, int step, java.util.function.IntConsumer setter) {
            int bw = w / 2 - 2;
            method_37063(class_4185.method_46430(class_2561.method_43470("\u00a7c- " + label + " \u00a7f" + val),
                b -> { setter.accept(clamp(val - step, min, max)); rebuild(); }).method_46434(x, y, bw, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("\u00a7a+"),
                b -> { setter.accept(clamp(val + step, min, max)); rebuild(); }).method_46434(x + bw + 4, y, bw, 20).method_46431());
            this.y += 22;
        }

        private void plusMinusF(int x, int y, int w, String label, float val, float min, float max, float step, java.util.function.Consumer<Float> setter) {
            int bw = w / 2 - 2;
            String txt = String.format(Locale.ROOT, "%s %.2f", label, val);
            method_37063(class_4185.method_46430(class_2561.method_43470("\u00a7c- " + txt),
                b -> { setter.accept(clamp(val - step, min, max)); rebuild(); }).method_46434(x, y, bw, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("\u00a7a+"),
                b -> { setter.accept(clamp(val + step, min, max)); rebuild(); }).method_46434(x + bw + 4, y, bw, 20).method_46431());
            this.y += 22;
        }

        private void rebuild() {
            class_310.method_1551().method_1507(this);
        }

        @Override
        public void method_25419() {
            class_310.method_1551().method_1507(parent);
        }
    }
}
