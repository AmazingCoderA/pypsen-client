package pypsen.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import pypsen.client.HudCompat26;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import pypsen.client.DrawContext26;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.util.*;

public class PypsenClient implements ClientModInitializer {

    // ══════════ TOGGLES ══════════
    public static boolean speedOn = false, auraOn = false, hitboxOn = false, flyOn = false;
    public static boolean xrayOn = false, velocityOn = false, aimOn = false, visualsOn = false;
    public static boolean strafeOn = false, noclipOn = false, antiFlagOn = false, autoClickerOn = false;
    public static boolean hudOn = true, triggerBotOn = false, targetHudOn = true, panicOn = false;
    public static boolean freecamOn = false, playerEspOn = false, auraSpinBot = false;
    public static boolean triggerWeaponOnly = false, autoTotemOn = false, aimLockOn = false;
    public static boolean antiBotOn = true, fullBrightOn = false, nameHiderOn = false;
    public static boolean spiderOn = false, noWebOn = false, freezeOn = false, useModernGui = false;
    public static boolean serverCrasherOn = false, godModeOn = false, autoArmorOn = false, fastBowOn = false;
    public static boolean bowJump = false, auraPredict = true, auraRandomize = true, dropAllItems = false;
    public static boolean jesusOn = false;

    // ══════════ VISUALS SUB-TOGGLES ══════════
    public static boolean seeInvisOn = false, noFireOn = false, noNauseaOn = false;
    public static boolean targetEspOn = false, noHurtCamOn = false;

    // ══════════ 2D ESP OVERLAY ══════════
    public static boolean espOn = false, espBoxesOn = true, espNamesOn = true, espHealthOn = true;
    public static boolean espDistanceOn = true, espItemsOn = false, espTracersOn = false, espFillOn = false;
    public static boolean espPlayersOn = true, espMobsOn = true, espAnimalsOn = false;
    public static float espRange = 64f;

    // ══════════ KILLAURA ADVANCED ══════════
    public static boolean auraJump = false, auraThroughWalls = true, auraHitInGuis = true;
    public static boolean autoWeapon = false, criticals = false, shieldBreaker = false, waterCrits = false;
    public static boolean auraRayCast = true;
    public static boolean auraTargetPlayers = true, auraTargetMobs = false, auraTargetAnimals = false;

    // ══════════ TRIGGERBOT ADVANCED ══════════
    public static boolean triggerThroughWalls = false, triggerSmartDelay = true;
    public static boolean triggerTargetPlayers = true, triggerTargetMobs = false, triggerTargetAnimals = false;
    public static boolean triggerAutoWeapon = false, triggerCriticals = false, triggerWaitHurtTime = true;
    public static float triggerCooldown = 0.95f, triggerJitter = 10f, triggerFov = 30f;

    // ══════════ VALUES ══════════
    public static float speedVal = 5f, auraRange = 6f, hitboxVal = 1f, flySpeed = 2f;
    public static float aimSpeed = 50f, clickerCps = 12f, triggerCps = 10f;
    public static float auraAimJitter = 0.0f, triggerRange = 3.0f;
    public static float auraStickiness = 0.0f, auraRotCurve = 0.0f, auraFov = 360f, auraRotSpeed = 180f;
    public static float autoTotemHealth = 20f;
    public static String fakeName = "Protected";

    // ══════════ MODES ══════════
    public static int auraMode = 0, auraTargetMode = 0, auraRotMode = 0;
    public static int auraTimingMode = 0, auraTargetPart = 1, visualsTargetMode = 0;
    public static int autoTotemMode = 0;
    public static int spiderMode = 0, noWebMode = 0, freezeMode = 0, crasherMode = 0, crasherTimerMode = 0;
    public static boolean airJumpOn = false, noFallOn = false;
    public static int airJumpMode = 0, noFallMode = 0, velocityMode = 0, jesusMode = 0, visualsParticles = 0;
    public static final String[] AIRJUMP_MODES = {"Vanilla", "GhostBlock", "Packet"};
    public static final String[] NOFALL_MODES = {"Packet", "WaterBucket", "Web", "Vulcan", "Grim", "LiquidBounce", "Matrix", "NCP"};
    public static final String[] VELOCITY_MODES = {"Cancel", "Matrix", "Grim", "LiquidBounce", "AAC"};
    public static final String[] JESUS_MODES = {"Solid", "Bounce", "LiquidBounce", "Matrix"};
    public static final String[] PARTICLES_MODES = {"None", "Heart", "Flame", "Magic", "LiquidBounce"};
    public static final String[] AURA_MODES = {"1.9 (Strict Cooldown)", "1.8 (Spam)", "Adaptive"};
    public static final String[] AURA_TARGETS = {"Distance", "Health", "Armor", "Angle"};
    public static final String[] AURA_ROTS = {"None", "Snap", "Smooth", "Silent", "Matrix", "Predict", "Smart", "Legit", "HvH", "Derp", "Cinematic", "NCP", "AAC", "Sunrise", "Vulcan", "Intave", "Legit Smooth", "Looping", "LiquidBounce", "Custom", "Noise"};
    public static final String[] AURA_TIMINGS = {"All", "Fall (Crits)", "Jump (Crits)"};
    public static final String[] AURA_PARTS = {"Head", "Chest", "Legs", "Feet"};
    public static final String[] VISUALS_TARGETS = {"All", "Enemies", "Friends"};
    public static final String[] TOTEM_MODES = {"Instant", "Legit"};
    public static final String[] SPIDER_MODES = {"Vanilla", "Jump", "Grim", "GhostBlock"};
    public static final String[] NOWEB_MODES = {"Vanilla", "Fast", "Grim", "Intave", "EdgeTP"};
    public static final String[] FREEZE_MODES = {"Vanilla", "Packet", "Intave", "GhostBlock", "LiquidBounce"};
    public static final String[] CRASHER_MODES = {"Position", "Swing", "Interact", "MathBreaker", "BrandPayload", "SettingsExploit", "TabComplete"};
    public static final String[] CRASHER_TIMERS = {"Infinite", "5s", "10s", "Auto-Disable"};
    public static final String[] GODMODE_MODES = {"Vanilla", "Packet", "Vulcan", "LiquidBounce"};
    public static int godModeMode = 0;

    public static int speedBypass = 0, auraBypass = 0, flyBypass = 0, noclipBypass = 0;
    public static final String[] BYPASS_NAMES = {"None", "Vanilla", "Timer", "Strafe", "NCP", "Matrix", "Grim", "Funtime", "ReallyWorld", "Vulcan", "Spartan", "Grim AC", "Polar AC", "Intave"};
    public static final String[] NOCLIP_MODES = {"Vanilla", "VClip", "HClip", "Packet"};

    // ══════════ KEYBINDS ══════════
    public static int keyMenu = GlfwCompat.GLFW_KEY_MINUS, keySpeed = GlfwCompat.GLFW_KEY_V, keyAura = GlfwCompat.GLFW_KEY_R;
    public static int keyFly = GlfwCompat.GLFW_KEY_G, keyXray = GlfwCompat.GLFW_KEY_X, keyHitbox = GlfwCompat.GLFW_KEY_H;
    public static int keyVelocity = GlfwCompat.GLFW_KEY_UNKNOWN, keyAim = GlfwCompat.GLFW_KEY_UNKNOWN;
    public static int keyVisuals = GlfwCompat.GLFW_KEY_UNKNOWN, keyStrafe = GlfwCompat.GLFW_KEY_UNKNOWN;
    public static int keyNoclip = GlfwCompat.GLFW_KEY_UNKNOWN, keyAntiFlag = GlfwCompat.GLFW_KEY_UNKNOWN;
    public static int keyAutoClicker = GlfwCompat.GLFW_KEY_UNKNOWN, keyTriggerBot = GlfwCompat.GLFW_KEY_UNKNOWN;
    public static int keyPanic = GlfwCompat.GLFW_KEY_UNKNOWN, keyFreecam = GlfwCompat.GLFW_KEY_UNKNOWN;
    public static int keyAutoTotem = GlfwCompat.GLFW_KEY_UNKNOWN, keyAimLock = GlfwCompat.GLFW_KEY_UNKNOWN;
    public static boolean autoClickerRight = false, autoClickerFarm = false;
    public static int keySpider = GlfwCompat.GLFW_KEY_UNKNOWN, keyNoWeb = GlfwCompat.GLFW_KEY_UNKNOWN, keyFreeze = GlfwCompat.GLFW_KEY_UNKNOWN;
    public static int keyCrasher = GlfwCompat.GLFW_KEY_UNKNOWN, keyGodMode = GlfwCompat.GLFW_KEY_UNKNOWN, keyAutoArmor = GlfwCompat.GLFW_KEY_UNKNOWN, keyFastBow = GlfwCompat.GLFW_KEY_UNKNOWN;
    public static int keyAirJump = GlfwCompat.GLFW_KEY_UNKNOWN, keyNoFall = GlfwCompat.GLFW_KEY_UNKNOWN, keyJesus = GlfwCompat.GLFW_KEY_UNKNOWN;
    public static int keyEsp = GlfwCompat.GLFW_KEY_UNKNOWN;

    public static final Set<String> friends = new HashSet<>();
    private static boolean middleClickWasDown = false;
    private static boolean wasFullBright = false;
    private static Vec3 freecamPos = null;
    private static float freecamYaw = 0, freecamPitch = 0;
    private static int totemTimer = 0, totemStep = 0, totemTargetSlot = -1;
    private static long lastTimeUpdate = 0;
    private static long crasherStartTime = 0;
    private static float currentTps = 20.0f;

    public static final Set<Block> XRAY_BLOCKS = new HashSet<>(Arrays.asList(
            Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE,
            Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE,
            Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE,
            Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE, Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE,
            Blocks.ANCIENT_DEBRIS, Blocks.NETHER_GOLD_ORE, Blocks.CHEST, Blocks.ENDER_CHEST, Blocks.SPAWNER
    ));

    private static int auraTick = 0, clickTimer = 0, triggerTimer = 0;
    private static float triggerFloatTimer = 0f;
    private static boolean xrayWasOn = false, visualsWasOn = false;
    private static LivingEntity currentTarget = null;

    public static LivingEntity getAuraTarget() {
        return currentTarget;
    }

    // Smooth rotation targets
    private static float targetYaw = 0f;
    private static float targetPitch = 0f;
    private static boolean isRotating = false;

    @Override
    public void onInitializeClient() {
        loadConfig();
        PypsenFeatures.clamp();
        PypsenFeatures.init(Minecraft.getInstance());

        HudCompat26.register((ctx, tickCounter) -> {
        float tickDelta = tickCounter.getGameTimeDeltaPartialTick(true);
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || panicOn) return;

            // ── MAIN HUD ──
            if (hudOn && PypsenFeatures.hudVisible()) {
                List<String> lines = new ArrayList<>();
                lines.add("\u00a7a\u00a7lPypsen v2 \u00a77[PRO]");
                if (speedOn)       lines.add("\u00a7bSpeed \u00a77" + String.format("%.1f", speedVal) + " [" + BYPASS_NAMES[speedBypass] + "]");
                if (auraOn)        lines.add("\u00a7cKillAura \u00a77" + String.format("%.1f", auraRange) + " [" + BYPASS_NAMES[auraBypass] + "]");
                if (hitboxOn)      lines.add("\u00a7eHitbox \u00a77" + String.format("%.1f", hitboxVal));
                if (flyOn)         lines.add("\u00a7dFly \u00a77" + String.format("%.1f", flySpeed) + " [" + BYPASS_NAMES[flyBypass] + "]");
                if (xrayOn)        lines.add("\u00a76XRay");
                if (velocityOn)    lines.add("\u00a79Velocity");
                if (aimOn)         lines.add("\u00a75AimAssist");
                if (visualsOn)     lines.add("\u00a7aVisuals");
                if (strafeOn)      lines.add("\u00a73Strafe");
                if (noclipOn)      lines.add("\u00a78Noclip");
                if (antiFlagOn)    lines.add("\u00a7eAnti-Flag");
                if (freecamOn)     lines.add("\u00a7bFreeCam");
                if (autoTotemOn)   lines.add("\u00a76AutoTotem");
                if (aimLockOn)     lines.add("\u00a75AimLock");
                if (antiBotOn)     lines.add("\u00a7aAntiBot");
                if (spiderOn)      lines.add("\u00a72Spider");
                if (noWebOn)       lines.add("\u00a7fNoWeb");
                if (freezeOn)      lines.add("\u00a7bFreeze");
                if (airJumpOn)     lines.add("\u00a7bAirJump");
                if (noFallOn)      lines.add("\u00a7aNoFall");
                if (jesusOn)       lines.add("\u00a7bJesus");
                if (serverCrasherOn)lines.add("\u00a7cServer Crasher");
                if (godModeOn)     lines.add("\u00a7eGodMode");
                if (autoArmorOn)   lines.add("\u00a7bAutoArmor");
                if (fastBowOn)     lines.add("\u00a7aFastBow");
                if (fullBrightOn)  lines.add("\u00a7eFullBright");
                if (nameHiderOn)   lines.add("\u00a7dNameHider");
                if (autoClickerOn) lines.add("\u00a7cAutoClicker \u00a77" + String.format("%.1f", clickerCps) + (autoClickerRight ? " [RMB]" : " [LMB]"));
                if (triggerBotOn)  lines.add("\u00a7cTriggerBot \u00a77" + String.format("%.1f", triggerCps) + " \u00a78[" + String.format("%.0f", triggerJitter) + "% jit]");
                if (espOn)         lines.add("\u00a7b2D ESP \u00a77" + String.format("%.0fm", espRange));
                if (PypsenFeatures.aiAuraOn) lines.add("\u00a75AI Aura \u00a77" + String.format("%.0fm", PypsenFeatures.aiRange)
                    + " [" + PypsenFeatures.AI_PRESETS[Mth.clamp(PypsenFeatures.aiPreset, 0, PypsenFeatures.AI_PRESETS.length - 1)]
                    + "/" + PypsenFeatures.AI_TARGET_MODES[Mth.clamp(PypsenFeatures.aiTargetMode, 0, PypsenFeatures.AI_TARGET_MODES.length - 1)]
                    + "] \u00a78" + String.format("%.0f%%", PypsenFeatures.aiConfidence * 100f)
                    + " \u00a77s" + PypsenFeatures.sampleCount());
                if (PypsenFeatures.crystalAuraOn) lines.add("\u00a7cCrystal Aura \u00a77" + String.format("%.0fm", PypsenFeatures.crystalRange)
                    + " [" + PypsenFeatures.CRYSTAL_MODES[Mth.clamp(PypsenFeatures.crystalMode, 0, PypsenFeatures.CRYSTAL_MODES.length - 1)]
                    + "/" + PypsenFeatures.CRYSTAL_PLACE_MODES[Mth.clamp(PypsenFeatures.crystalPlaceMode, 0, PypsenFeatures.CRYSTAL_PLACE_MODES.length - 1)] + "]");
                if (PypsenFeatures.fakeLagOn) lines.add("\u00a78FakeLag \u00a77" + String.format("%.0fms", PypsenFeatures.fakeLagDelay));
                if (PypsenFeatures.autoEatOn) lines.add("\u00a7aAutoEat \u00a77" + String.format("%.0fHP", PypsenFeatures.autoEatHealth));
                if (PypsenFeatures.spiderProOn) lines.add("\u00a72Spider Pro");
                if (PypsenFeatures.noclipProOn) lines.add("\u00a78Noclip Pro");
                if (PypsenFeatures.stealthOn) lines.add("\u00a78Stealth \u00a77" + PypsenFeatures.STEALTH_MODES[Mth.clamp(PypsenFeatures.stealthMode, 0, PypsenFeatures.STEALTH_MODES.length - 1)]);
                if (PypsenFeatures.comboCounterOn && PypsenFeatures.comboCount() > 1) lines.add("\u00a7eCombo x" + PypsenFeatures.comboCount());
                if (PypsenFeatures.killFeedOn && PypsenFeatures.killCount() > 0) lines.add("\u00a7cKills \u00a77" + PypsenFeatures.killCount());

                // TPS & Ping
                lines.add("");
                lines.add("§7TPS: §f" + String.format("%.1f", currentTps));
                if (mc.getConnection() != null && mc.getConnection().getPlayerInfo(mc.player.getUUID()) != null) {
                    lines.add("§7Ping: §f" + mc.getConnection().getPlayerInfo(mc.player.getUUID()).getLatency() + "ms");
                }

                int y = 4;
                for (String s : lines) {
                    ctx.drawTextWithShadow(mc.font, Component.literal(s), 4, y, 0xFFFFFF);
                    y += 11;
                }
            }

            // ── TARGET HUD ──
            if (targetHudOn && PypsenFeatures.hudVisible() && currentTarget != null && currentTarget.isAlive() && mc.player.distanceTo(currentTarget) <= auraRange * 1.5) {
                int sw = mc.getWindow().getGuiScaledWidth();
                int sh = mc.getWindow().getGuiScaledHeight();
                int tx = sw / 2 + 20;
                int ty = sh / 2 + 20;

                ctx.fill(tx, ty, tx + 140, ty + 50, 0x90000000); // Background
                ctx.fill(tx, ty, tx + 140, ty + 2, 0xFF55FF55);  // Top border

                String name = PypsenFeatures.label(currentTarget.getName().getString(), "Player");
                float hp = currentTarget.getHealth();
                float maxHp = currentTarget.getMaxHealth();
                int armor = currentTarget.getArmorValue();
                float dist = mc.player.distanceTo(currentTarget);

                ctx.drawTextWithShadow(mc.font, Component.literal("\u00a7l" + name), tx + 5, ty + 6, 0xFFFFFF);
                ctx.drawTextWithShadow(mc.font, Component.literal("\u00a7c\u2764 " + String.format("%.1f", hp)), tx + 5, ty + 18, 0xFFFFFF);
                ctx.drawTextWithShadow(mc.font, Component.literal("\u00a7b\u25A0 " + armor), tx + 50, ty + 18, 0xFFFFFF);
                ctx.drawTextWithShadow(mc.font, Component.literal("\u00a77" + String.format("%.1fm", dist)), tx + 95, ty + 18, 0xFFFFFF);

                int hpBarWidth = (int) ((hp / maxHp) * 130);
                ctx.fill(tx + 5, ty + 35, tx + 5 + 130, ty + 42, 0xFF333333);
                ctx.fill(tx + 5, ty + 35, tx + 5 + hpBarWidth, ty + 42, getHealthColor(hp, maxHp));
            }

            // ── 2D ESP OVERLAY ──
            drawEsp(ctx, mc, tickDelta);

            // ── ADVANCED TARGET VISUALS ──
            PypsenFeatures.render(ctx, mc);
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.level == null) return;
            var p = mc.player;
            long handle = Compat26.windowHandle(mc.getWindow());

            // ── NAMEHIDER (TAB & SCOREBOARD) ──
            if (nameHiderOn && mc.getConnection() != null) {
                for (net.minecraft.client.multiplayer.PlayerInfo entry : mc.getConnection().getOnlinePlayers()) {
                    if (entry.getProfile().id().equals(p.getUUID())) {
                        entry.setTabListDisplayName(Component.literal(fakeName));
                    }
                }
            }

            // ── TPS CALCULATION ──
            long now = System.currentTimeMillis();
            if (now - lastTimeUpdate > 1000) {
                if (mc.getConnection() != null && mc.getConnection().getPlayerInfo(p.getUUID()) != null) {
                    int ping = mc.getConnection().getPlayerInfo(p.getUUID()).getLatency();
                    // Simple approximation based on ping for visual effect if real TPS is unavailable
                    currentTps = 20.0f - (ping > 100 ? (ping / 1000.0f) : 0);
                    if (currentTps < 0) currentTps = 0;
                }
                lastTimeUpdate = now;
            }

            // ── PANIC KEY ──
            if (wasPressed(handle, keyPanic)) {
                panicOn = !panicOn;
                if (panicOn) {
                    speedOn = auraOn = hitboxOn = flyOn = xrayOn = velocityOn = aimOn = visualsOn = false;
                    strafeOn = noclipOn = antiFlagOn = autoClickerOn = triggerBotOn = freecamOn = playerEspOn = false;
                    autoTotemOn = aimLockOn = fullBrightOn = nameHiderOn = spiderOn = noWebOn = freezeOn = false;
                    jesusOn = false;
                    PypsenFeatures.panic();
                    mc.levelRenderer.resetLevelRenderData();
                }
            }

            if (panicOn) return;

            // ── FRIENDS (MIDDLE CLICK) ──
            boolean middleClickDown = GlfwCompat.glfwGetMouseButton(handle, GlfwCompat.GLFW_MOUSE_BUTTON_MIDDLE) == GlfwCompat.GLFW_PRESS;
            if (middleClickDown && !middleClickWasDown && Compat26.currentScreen(mc) == null) {
                if (mc.hitResult != null && mc.hitResult.getType() == HitResult.Type.ENTITY) {
                    Entity e = ((EntityHitResult) mc.hitResult).getEntity();
                    if (e instanceof net.minecraft.world.entity.player.Player) {
                        String name = e.getName().getString();
                        if (friends.contains(name)) {
                            friends.remove(name);
                            p.sendSystemMessage(Component.literal("\u00a7cRemoved friend: " + name));
                        } else {
                            friends.add(name);
                            p.sendSystemMessage(Component.literal("\u00a7aAdded friend: " + name));
                        }
                    }
                }
            }
            middleClickWasDown = middleClickDown;

            // ── KEYBINDS ──
            if (Compat26.currentScreen(mc) == null) {
                if (wasPressed(handle, keyMenu)) mc.setScreenAndShow(useModernGui ? new ModernGuiScreen() : new MenuScreen());
                if (wasPressed(handle, keySpeed))       speedOn       = !speedOn;
                if (wasPressed(handle, keyAura))        auraOn        = !auraOn;
                if (wasPressed(handle, keyFly))         flyOn         = !flyOn;
                if (wasPressed(handle, keyHitbox))      hitboxOn      = !hitboxOn;
                if (wasPressed(handle, keyVelocity))    velocityOn    = !velocityOn;
                if (wasPressed(handle, keyAim))         aimOn         = !aimOn;
                if (wasPressed(handle, keyStrafe))      strafeOn      = !strafeOn;
                if (wasPressed(handle, keyVisuals))     visualsOn     = !visualsOn;
                if (wasPressed(handle, keyNoclip))      noclipOn      = !noclipOn;
                if (wasPressed(handle, keyAntiFlag))    antiFlagOn    = !antiFlagOn;
                if (wasPressed(handle, keyAutoClicker)) autoClickerOn = !autoClickerOn;
                if (wasPressed(handle, keyTriggerBot))  triggerBotOn  = !triggerBotOn;
                if (wasPressed(handle, keyEsp))         espOn         = !espOn;
                if (wasPressed(handle, keyAutoTotem))   autoTotemOn   = !autoTotemOn;
                if (wasPressed(handle, keyAimLock))     aimLockOn     = !aimLockOn;
                if (wasPressed(handle, keySpider))      spiderOn      = !spiderOn;
                if (wasPressed(handle, keyNoWeb))       noWebOn       = !noWebOn;
                if (wasPressed(handle, keyFreeze))      freezeOn      = !freezeOn;
                if (wasPressed(handle, keyAirJump))     airJumpOn     = !airJumpOn;
                if (wasPressed(handle, keyNoFall))      noFallOn      = !noFallOn;
                if (wasPressed(handle, keyJesus))       jesusOn       = !jesusOn;
                if (wasPressed(handle, keyFreecam)) {
                    freecamOn = !freecamOn;
                    if (freecamOn) {
                        freecamPos = Compat.entityPos(p);
                        freecamYaw = p.getYRot();
                        freecamPitch = p.getXRot();
                    } else {
                        p.noPhysics = false;
                        p.getAbilities().flying = false;
                        if (freecamPos != null) {
                            p.setPos(freecamPos);
                            p.setYRot(freecamYaw);
                            p.setXRot(freecamPitch);
                            p.setDeltaMovement(0, 0, 0);
                        }
                    }
                }
                if (wasPressed(handle, keyXray)) {
                    xrayOn = !xrayOn;
                    mc.levelRenderer.resetLevelRenderData();
                }
                PypsenFeatures.handleKey(handle);
            }

            // hitbox rendering toggle is not exposed by this Minecraft version

            // ── ANTI-FLAG ──
            if (antiFlagOn) {
                if (speedVal > 2.0f) speedVal = 2.0f;
                if (flySpeed > 1.5f) flySpeed = 1.5f;
                if (auraRange > 4.5f) auraRange = 4.5f;
                if (clickerCps > 15f) clickerCps = 15f;
                if (triggerCps > 15f) triggerCps = 15f;
            }

            // ── AIRJUMP ──
            if (airJumpOn && mc.options.keyJump.isDown() && !p.onGround() && p.fallDistance > 0.1f) {
                if (p.tickCount % 5 == 0) {
                    if (airJumpMode == 0) { // Vanilla
                        p.jumpFromGround();
                    } else if (airJumpMode == 1) { // GhostBlock
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundPlayerActionPacket(net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND, net.minecraft.core.BlockPos.ZERO, net.minecraft.core.Direction.DOWN));
                        p.jumpFromGround();
                    } else if (airJumpMode == 2) { // Packet
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX(), p.getY(), p.getZ(), true, false));
                        p.jumpFromGround();
                    }
                }
            }

            // ── NOFALL ──
            if (noFallOn && p.fallDistance > 2.5f) {
                if (noFallMode == 0) { // Packet
                    mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX(), p.getY(), p.getZ(), true, false));
                    p.fallDistance = 0;
                } else if (noFallMode == 1) { // WaterBucket
                    int slot = -1;
                    for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).getItem() == net.minecraft.world.item.Items.WATER_BUCKET) slot = i;
                    if (slot != -1) {
                        int oldSlot = p.getInventory().getSelectedSlot();
                        p.getInventory().setSelectedSlot(slot);
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot(p.getYRot(), 90, p.onGround(), false));
                        mc.gameMode.useItem(p, net.minecraft.world.InteractionHand.MAIN_HAND);
                        p.getInventory().setSelectedSlot(oldSlot);
                        p.fallDistance = 0;
                    }
                } else if (noFallMode == 2) { // Web
                    int slot = -1;
                    for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).getItem() == net.minecraft.world.item.Items.COBWEB) slot = i;
                    if (slot != -1) {
                        int oldSlot = p.getInventory().getSelectedSlot();
                        p.getInventory().setSelectedSlot(slot);
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot(p.getYRot(), 90, p.onGround(), false));
                        mc.gameMode.useItem(p, net.minecraft.world.InteractionHand.MAIN_HAND);
                        p.getInventory().setSelectedSlot(oldSlot);
                        p.fallDistance = 0;
                    }
                } else if (noFallMode == 3) { // Vulcan
                    mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX(), p.getY() - 0.1, p.getZ(), true, false));
                    p.fallDistance = 0;
                } else if (noFallMode == 4) { // Grim
                    mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX(), p.getY() + 1E-9, p.getZ(), false, false));
                    mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX(), p.getY(), p.getZ(), true, false));
                    p.fallDistance = 0;
                } else if (noFallMode == 5) { // LiquidBounce
                    mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX(), p.getY() - 1000, p.getZ(), true, false));
                    p.fallDistance = 0;
                } else if (noFallMode == 6) { // Matrix
                    if (p.fallDistance > 3f) {
                        p.setDeltaMovement(p.getDeltaMovement().x, -0.05, p.getDeltaMovement().z);
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX(), p.getY(), p.getZ(), true, false));
                        p.fallDistance = 0;
                    }
                } else if (noFallMode == 7) { // NCP
                    mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX(), p.getY() - 0.01, p.getZ(), true, false));
                    p.fallDistance = 0;
                }
            }

            // ── JESUS ──
            if (jesusOn && p.isInWater()) {
                if (jesusMode == 0) { // Solid
                    p.setDeltaMovement(p.getDeltaMovement().x, 0, p.getDeltaMovement().z);
                    p.setOnGround(true);
                } else if (jesusMode == 1) { // Bounce
                    p.setDeltaMovement(p.getDeltaMovement().x, 0.2, p.getDeltaMovement().z);
                } else if (jesusMode == 2) { // LiquidBounce
                    if (p.tickCount % 2 == 0) p.setDeltaMovement(p.getDeltaMovement().x, 0.05, p.getDeltaMovement().z);
                    else p.setDeltaMovement(p.getDeltaMovement().x, -0.05, p.getDeltaMovement().z);
                } else if (jesusMode == 3) { // Matrix
                    if (p.isInWater()) {
                        p.setDeltaMovement(p.getDeltaMovement().x, 0.1, p.getDeltaMovement().z);
                        p.setSprinting(false);
                    }
                }
            }

            // ── FREEZE ──
            if (freezeOn) {
                if (freezeMode == 0) { // Vanilla
                    p.setDeltaMovement(0, 0, 0);
                    p.fallDistance = 0; // Prevent fall damage accumulation
                } else if (freezeMode == 1) { // Packet
                    p.setDeltaMovement(0, 0, 0);
                    mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX(), p.getY(), p.getZ(), true, false));
                } else if (freezeMode == 2) { // Intave
                    // Micro-falling to bypass fly checks
                    p.setDeltaMovement(0, -0.01, 0);
                    p.fallDistance = 0;
                } else if (freezeMode == 3) { // GhostBlock
                    if (p.tickCount % 4 == 0) {
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundPlayerActionPacket(net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND, net.minecraft.core.BlockPos.ZERO, net.minecraft.core.Direction.DOWN));
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundPlayerActionPacket(net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.DROP_ITEM, net.minecraft.core.BlockPos.ZERO, net.minecraft.core.Direction.DOWN));
                        p.setDeltaMovement(p.getDeltaMovement().x, 0.2, p.getDeltaMovement().z);
                    } else {
                        p.setDeltaMovement(p.getDeltaMovement().x, 0, p.getDeltaMovement().z); // Hover between jumps
                    }
                    p.fallDistance = 0;
                } else if (freezeMode == 4) { // LiquidBounce
                    p.setDeltaMovement(0, 0, 0);
                    if (p.tickCount % 2 == 0) {
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX(), p.getY() + 1E-5, p.getZ(), p.onGround(), false));
                    }
                }
            }

            // ── SPIDER ──
            if (spiderOn && p.horizontalCollision) {
                if (spiderMode == 0) { // Vanilla
                    Vec3 v = p.getDeltaMovement();
                    p.setDeltaMovement(v.x, 0.2, v.z);
                } else if (spiderMode == 1) { // Jump
                    if (p.onGround()) p.jumpFromGround();
                } else if (spiderMode == 2) { // Grim
                    if (p.tickCount % 4 == 0) {
                        Vec3 v = p.getDeltaMovement();
                        p.setDeltaMovement(v.x, 0.4, v.z);
                    }
                } else if (spiderMode == 3) { // GhostBlock (F+Q Exploit)
                    if (p.tickCount % 4 == 0) {
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundPlayerActionPacket(net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND, net.minecraft.core.BlockPos.ZERO, net.minecraft.core.Direction.DOWN));
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundPlayerActionPacket(net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.DROP_ITEM, net.minecraft.core.BlockPos.ZERO, net.minecraft.core.Direction.DOWN));
                        p.jumpFromGround();
                    }
                }
            }

            // ── NOWEB (Fast mode logic) ──
            if (noWebOn) {
                Block block = mc.level.getBlockState(p.blockPosition()).getBlock();
                boolean isWeb = block == net.minecraft.world.level.block.Blocks.COBWEB || block == net.minecraft.world.level.block.Blocks.SWEET_BERRY_BUSH;

                if (isWeb) {
                    if (noWebMode == 1) { // Fast
                        p.setDeltaMovement(p.getDeltaMovement().x, -0.1, p.getDeltaMovement().z);
                    } else if (noWebMode == 3) { // Intave
                        // Shift sideways slightly to desync web collision on server, and fall fast
                        p.setDeltaMovement(0.05, -0.4, 0.05);
                    } else if (noWebMode == 4) { // EdgeTP
                        boolean foundEdge = false;
                        for (int x = -3; x <= 3 && !foundEdge; x++) {
                            for (int z = -3; z <= 3 && !foundEdge; z++) {
                                if (x == 0 && z == 0) continue;
                                net.minecraft.core.BlockPos checkPos = p.blockPosition().offset(x, 0, z);
                                Block checkBlock = mc.level.getBlockState(checkPos).getBlock();
                                if (checkBlock != net.minecraft.world.level.block.Blocks.COBWEB && checkBlock != net.minecraft.world.level.block.Blocks.SWEET_BERRY_BUSH) {
                                    Vec3 target = new Vec3(checkPos.getX() + 0.5, checkPos.getY(), checkPos.getZ() + 0.5);
                                    mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(target.x, target.y, target.z, p.onGround(), false));
                                    p.setPos(target);
                                    p.setDeltaMovement(0, p.getDeltaMovement().y, 0);
                                    foundEdge = true;
                                }
                            }
                        }
                        if (!foundEdge) {
                            p.setDeltaMovement(0, -0.4, 0); // Fallback if no edge found
                        }
                    }
                }
            }

            // ── AUTOTOTEM ──
            if (autoTotemOn && Compat26.currentScreen(mc) == null) {
                float hp = p.getHealth() + p.getAbsorptionAmount();
                if (hp <= autoTotemHealth && p.getOffhandItem().getItem() != net.minecraft.world.item.Items.TOTEM_OF_UNDYING) {
                    if (autoTotemMode == 0) { // Instant
                        int slot = -1;
                        for (int i = 9; i < 45; i++) {
                            if (p.inventoryMenu.getSlot(i).getItem().getItem() == net.minecraft.world.item.Items.TOTEM_OF_UNDYING) {
                                slot = i;
                                break;
                            }
                        }
                        if (slot != -1) {
                            Compat26.clickSlot(mc.gameMode, 0, slot, 0, 0, p);
                            Compat26.clickSlot(mc.gameMode, 0, 45, 0, 0, p);
                            Compat26.clickSlot(mc.gameMode, 0, slot, 0, 0, p);
                        }
                    } else { // Legit (Step-by-step)
                        if (totemTimer > 0) {
                            totemTimer--;
                        } else {
                            if (totemStep == 0) {
                                totemTargetSlot = -1;
                                for (int i = 9; i < 45; i++) {
                                    if (p.inventoryMenu.getSlot(i).getItem().getItem() == net.minecraft.world.item.Items.TOTEM_OF_UNDYING) {
                                        totemTargetSlot = i;
                                        break;
                                    }
                                }
                                if (totemTargetSlot != -1) {
                                    Compat26.clickSlot(mc.gameMode, 0, totemTargetSlot, 0, 0, p);
                                    totemStep = 1;
                                    totemTimer = 2; // 2 ticks delay
                                }
                            } else if (totemStep == 1) {
                                Compat26.clickSlot(mc.gameMode, 0, 45, 0, 0, p);
                                totemStep = 2;
                                totemTimer = 2;
                            } else if (totemStep == 2) {
                                Compat26.clickSlot(mc.gameMode, 0, totemTargetSlot, 0, 0, p);
                                totemStep = 0;
                                totemTimer = 10; // Cooldown
                            }
                        }
                    }
                } else {
                    totemStep = 0; // Reset if we have a totem or health is high
                }
            }

            // ── NOCLIP ──
            if (noclipOn) {
                if (noclipBypass == 0) { // Vanilla
                    p.noPhysics = true;
                    p.fallDistance = 0;
                } else if (noclipBypass == 1) { // VClip (Vertical teleport)
                    if (mc.options.keyJump.isDown()) p.setPos(p.getX(), p.getY() + 0.5, p.getZ());
                    if (mc.options.keyShift.isDown()) p.setPos(p.getX(), p.getY() - 0.5, p.getZ());
                } else if (noclipBypass == 2) { // HClip (Horizontal teleport)
                    Vec3 forward = p.getViewVector(1.0f).scale(0.5);
                    p.setPos(p.getX() + forward.x, p.getY(), p.getZ() + forward.z);
                } else if (noclipBypass == 3) { // Packet (Desync)
                    p.noPhysics = true;
                    if (p.tickCount % 2 == 0) {
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX(), p.getY() - 0.01, p.getZ(), false, false));
                    }
                }
                p.fallDistance = 0;
            } else if (!freecamOn) {
                p.noPhysics = false;
            }

            // ── FREECAM ──
            if (freecamOn) {
                p.noPhysics = true;
                p.getAbilities().flying = true;
                double vy = 0;
                if (mc.options.keyJump.isDown()) vy = 0.5;
                if (mc.options.keyShift.isDown()) vy = -0.5;
                float fw = Compat.moveForward(p);
                float st = Compat.moveSideways(p);
                double vx = 0, vz = 0;
                if (fw != 0 || st != 0) {
                    double yaw = Math.toRadians(p.getYRot());
                    double angle = yaw - Math.atan2(fw, st) + Math.PI / 2;
                    vx = -Math.sin(angle) * 0.5;
                    vz = Math.cos(angle) * 0.5;
                }
                p.setDeltaMovement(vx, vy, vz);
            }

            // ── SERVER CRASHER ──
            if (serverCrasherOn) {
                if (crasherStartTime == 0) crasherStartTime = System.currentTimeMillis();
                long elapsed = System.currentTimeMillis() - crasherStartTime;

                if ((crasherTimerMode == 1 && elapsed > 5000) || (crasherTimerMode == 2 && elapsed > 10000)) {
                    serverCrasherOn = false;
                    crasherStartTime = 0;
                } else if (mc.getConnection() == null && crasherTimerMode == 3) {
                    serverCrasherOn = false;
                    crasherStartTime = 0;
                }
            } else {
                crasherStartTime = 0;
            }

            if (serverCrasherOn && mc.getConnection() != null) {
                if (crasherMode == 0) { // Position
                    for (int i = 0; i < 1000; i++) {
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX() + 9999999, p.getY() + 9999999, p.getZ() + 9999999, true, false));
                    }
                } else if (crasherMode == 1) { // Swing
                    for (int i = 0; i < 5000; i++) {
                        Compat26.swing(mc.player);
                    }
                } else if (crasherMode == 2) { // Interact
                    for (int i = 0; i < 1000; i++) {
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundPlayerActionPacket(net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND, net.minecraft.core.BlockPos.ZERO, net.minecraft.core.Direction.DOWN));
                    }
                } else if (crasherMode == 3) { // MathBreaker (NaN/Infinity)
                    for (int i = 0; i < 100; i++) {
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(Double.NaN, Double.POSITIVE_INFINITY, Double.NaN, true, false));
                    }
                } else if (crasherMode == 4) { // BrandPayload
                    net.minecraft.network.FriendlyByteBuf buf = new net.minecraft.network.FriendlyByteBuf(io.netty.buffer.Unpooled.buffer());
                    buf.writeUtf("A".repeat(32000));
                    // Brand payload packet layout is version-specific; skipped on this target.
                } else if (crasherMode == 5) { // SettingsExploit
                    // Client settings packet layout is version-specific; skipped on this target.
                } else if (crasherMode == 6) { // TabComplete
                    mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundCommandSuggestionPacket(0, "/" + "A".repeat(32000)));
                }
            }

            // ── GODMODE ──
            if (godModeOn) {
                if (godModeMode == 0) { // Vanilla
                    // Do nothing, MinecraftClient.getInstance() can't enforce godmode in vanilla without packets
                } else if (godModeMode == 1) { // Packet
                    if (p.tickCount % 10 == 0) {
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX(), p.getY() - 0.1, p.getZ(), false, false));
                    }
                } else if (godModeMode == 2) { // Vulcan
                    if (p.tickCount % 5 == 0) {
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos(p.getX(), p.getY() + 1337.0, p.getZ(), true, false));
                    }
                } else if (godModeMode == 3) { // LiquidBounce (Riding/Dismount exploit)
                    if (p.tickCount % 3 == 0) {
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket(p, net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action.START_SPRINTING));
                        mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket(p, net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action.STOP_SPRINTING));
                    }
                }
            }

            // ── DROP ALL ITEMS ──
            if (dropAllItems) {
                for (int i = 9; i < 45; i++) {
                    if (!p.inventoryMenu.getSlot(i).getItem().isEmpty()) {
                        Compat26.clickSlot(mc.gameMode, p.inventoryMenu.containerId, i, 1, 2, p);
                    }
                }
                dropAllItems = false;
            }

            // ── AUTOARMOR ──
            if (autoArmorOn && p.tickCount % 4 == 0 && Compat26.currentScreen(mc) == null && mc.gameMode != null) {
                for (int type = 0; type < 4; type++) {
                    net.minecraft.world.item.ItemStack currentArmor = Compat.armorStack(p, type);
                    int bestSlot = -1;
                    int bestScore = currentArmor.isEmpty() ? -1 : getArmorScore(currentArmor);

                    for (int i = 9; i < 36; i++) {
                        net.minecraft.world.item.ItemStack stack = p.getInventory().getItem(i);
                        if (!stack.isEmpty() && Compat.isArmor(stack)) {
                            if (Compat.armorSlot(stack) == type) {
                                int score = getArmorScore(stack);
                                if (score > bestScore) {
                                    bestScore = score;
                                    bestSlot = i;
                                }
                            }
                        }
                    }

                    if (bestSlot != -1) {
                        if (!currentArmor.isEmpty()) {
                            Compat26.clickSlot(mc.gameMode, p.inventoryMenu.containerId, 8 - type, 0, 1, p);
                        }
                        Compat26.clickSlot(mc.gameMode, p.inventoryMenu.containerId, bestSlot, 0, 1, p);
                        break;
                    }
                }
            }

            // ── FASTBOW ──
            if (fastBowOn && p.getMainHandItem().getItem() == net.minecraft.world.item.Items.BOW && mc.options.keyUse.isDown()) {
                mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundPlayerActionPacket(net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.RELEASE_USE_ITEM, net.minecraft.core.BlockPos.ZERO, net.minecraft.core.Direction.DOWN));
                mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundUseItemPacket(InteractionHand.MAIN_HAND, 0, p.getYRot(), p.getXRot()));

                if (bowJump && p.onGround()) {
                    p.jumpFromGround();
                    p.setXRot(-90);
                }
            }

            // ── AUTOCLICKER ──
            boolean isClicking = autoClickerRight ? mc.options.keyUse.isDown() : mc.options.keyAttack.isDown();
            if (autoClickerOn && isClicking && Compat26.currentScreen(mc) == null) {
                clickTimer++;
                int delay = (int) (20f / Math.max(1f, clickerCps));
                if (clickTimer >= delay) {
                    clickTimer = 0;
                    if (autoClickerRight) {
                        if (autoClickerFarm && mc.hitResult != null && mc.hitResult.getType() == HitResult.Type.BLOCK) {
                            net.minecraft.core.BlockPos pos = ((net.minecraft.world.phys.BlockHitResult) mc.hitResult).getBlockPos();
                            Block block = mc.level.getBlockState(pos).getBlock();
                            if (block == net.minecraft.world.level.block.Blocks.WHEAT || block == net.minecraft.world.level.block.Blocks.CARROTS || block == net.minecraft.world.level.block.Blocks.POTATOES) {
                                mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, (net.minecraft.world.phys.BlockHitResult) mc.hitResult);
                            }
                        } else {
                            mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
                        }
                        Compat26.swing(p);
                    } else {
                        if (mc.hitResult != null && mc.hitResult.getType() == HitResult.Type.ENTITY) {
                            mc.gameMode.attack(p, ((EntityHitResult) mc.hitResult).getEntity());
                        }
                        Compat26.swing(p);
                    }
                }
            } else {
                clickTimer = 0;
            }

            // ── TRIGGERBOT ──
            if (triggerBotOn && Compat26.currentScreen(mc) == null && mc.gameMode != null) {
                triggerFloatTimer += 1f;
                float ticksPerHit = 20f / Math.max(1f, triggerCps);
                if (triggerJitter > 0f) {
                    ticksPerHit *= 1f + (float) (Math.random() - 0.5) * 2f * (triggerJitter / 100f);
                }
                ticksPerHit = Math.max(1f, ticksPerHit);

                if (triggerFloatTimer >= ticksPerHit) {
                    triggerFloatTimer = 0f;
                    triggerTimer++;

                    Entity target = null;
                    if (mc.hitResult != null && mc.hitResult.getType() == HitResult.Type.ENTITY) {
                        Entity aimed = ((EntityHitResult) mc.hitResult).getEntity();
                        if (isValidTriggerTarget(aimed, p, mc)) target = aimed;
                    }

                    // Through-walls mode scans for the closest entity inside the configured cone.
                    if (target == null && triggerThroughWalls) {
                        double bestAngle = Double.MAX_VALUE;
                        for (Entity candidate : mc.level.entitiesForRendering()) {
                            if (!isValidTriggerTarget(candidate, p, mc)) continue;
                            double angle = getAngleDifference(p, candidate);
                            if (angle < bestAngle) {
                                bestAngle = angle;
                                target = candidate;
                            }
                        }
                        if (target != null && bestAngle > Mth.clamp(triggerFov, 1f, 180f) * 0.5f) target = null;
                    }

                    if (target != null) {
                        boolean isWeapon = Compat.isSword(p.getMainHandItem()) || Compat.isAxe(p.getMainHandItem());
                        if (!triggerWeaponOnly || isWeapon) {
                            boolean cooldownOk = !triggerSmartDelay || p.getAttackStrengthScale(0.0f) >= Mth.clamp(triggerCooldown, 0f, 1f);
                            boolean targetReady = !triggerWaitHurtTime || ((LivingEntity) target).hurtTime == 0;
                            if (cooldownOk && targetReady) {
                                if (triggerAutoWeapon) {
                                    int slot = findBestWeapon(p, Compat.isAxe(p.getMainHandItem()));
                                    if (slot >= 0) p.getInventory().setSelectedSlot(slot);
                                }
                                if (triggerCriticals && (p.onGround() || p.isInWater())) {
                                    p.push(0, 0.1, 0);
                                    p.fallDistance = 0.1f;
                                    p.setOnGround(false);
                                }
                                mc.gameMode.attack(p, target);
                                Compat26.swing(p);
                                p.resetAttackStrengthTicker();
                            }
                        }
                    }
                }
            } else {
                triggerTimer = 0;
                triggerFloatTimer = 0f;
            }

            // ── FULLBRIGHT ──
            if (fullBrightOn) {
                p.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.NIGHT_VISION, 1000, 0, false, false, false));
                wasFullBright = true;
            } else if (wasFullBright) {
                if (p.hasEffect(net.minecraft.world.effect.MobEffects.NIGHT_VISION)) {
                    p.removeEffect(net.minecraft.world.effect.MobEffects.NIGHT_VISION);
                }
                wasFullBright = false;
            }

            // ── VISUALS (ESP & SUB-FUNCTIONS) ──
            if (visualsOn) {
                mc.level.entitiesForRendering().forEach(e -> {
                    if (e instanceof LivingEntity && e != p) {
                        boolean isFriend = friends.contains(e.getName().getString());
                        boolean shouldGlow = false;
                        if (visualsTargetMode == 0) shouldGlow = true;
                        else if (visualsTargetMode == 1 && !isFriend) shouldGlow = true;
                        else if (visualsTargetMode == 2 && isFriend) shouldGlow = true;
                        e.setGlowingTag(shouldGlow);
                    }
                });
                visualsWasOn = true;

                if (noFireOn && p.isOnFire()) {
                    p.extinguishFire();
                }
                if (noNauseaOn && p.hasEffect(net.minecraft.world.effect.MobEffects.NAUSEA)) {
                    p.removeEffect(net.minecraft.world.effect.MobEffects.NAUSEA);
                }
                if (targetEspOn && currentTarget != null && currentTarget.isAlive()) {
                    double r = currentTarget.getBbWidth() * 1.2;
                    for (int i = 0; i < 5; i++) {
                        double angle = (System.currentTimeMillis() / 5.0 + i * 72) % 360;
                        double rad = Math.toRadians(angle);
                        double px = currentTarget.getX() + Math.cos(rad) * r;
                        double pz = currentTarget.getZ() + Math.sin(rad) * r;

                        // Feet circle (Soup Visuals style)
                        Compat.addParticle(mc.level, net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER, px, currentTarget.getY(), pz, 0, 0, 0);

                        // Halo above head
                        Compat.addParticle(mc.level, net.minecraft.core.particles.ParticleTypes.END_ROD, px, currentTarget.getY() + currentTarget.getBbHeight() + 0.3, pz, 0, 0, 0);
                    }

                    // Outline box around target
                    double minX = currentTarget.getX() - currentTarget.getBbWidth() / 2;
                    double minY = currentTarget.getY();
                    double minZ = currentTarget.getZ() - currentTarget.getBbWidth() / 2;
                    double maxX = currentTarget.getX() + currentTarget.getBbWidth() / 2;
                    double maxY = currentTarget.getY() + currentTarget.getBbHeight();
                    double maxZ = currentTarget.getZ() + currentTarget.getBbWidth() / 2;

                    Compat.addParticle(mc.level, net.minecraft.core.particles.ParticleTypes.FLAME, minX, minY, minZ, 0, 0, 0);
                    Compat.addParticle(mc.level, net.minecraft.core.particles.ParticleTypes.FLAME, maxX, maxY, maxZ, 0, 0, 0);
                }
            } else if (visualsWasOn) {
                mc.level.entitiesForRendering().forEach(e -> {
                    if (e instanceof LivingEntity && e != p) e.setGlowingTag(false);
                });
                visualsWasOn = false;
            }

            // ── AIM ASSIST & AIMLOCK ──
            if ((aimOn || aimLockOn) && Compat26.currentScreen(mc) == null && !auraOn) {
                var list = mc.level.getEntities(p, p.getBoundingBox().inflate(15), e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator());
                Entity target = list.stream().min(Comparator.comparingDouble(e -> ((net.minecraft.world.entity.Entity) e).distanceTo(p))).orElse(null);
                if (target != null) {
                    float[] rots = getRotations(p, target, false);
                    if (aimLockOn) {
                        p.setYRot(rots[0]);
                        p.setXRot(rots[1]);
                    } else {
                        p.setYRot(p.getYRot() + (rots[0] - p.getYRot()) * (aimSpeed / 100f));
                        p.setXRot(p.getXRot() + (rots[1] - p.getXRot()) * (aimSpeed / 100f));
                    }
                }
            }

            // ── STRAFE ──
            if (strafeOn && Compat26.currentScreen(mc) == null) {
                if (Compat.moveForward(p) != 0 || Compat.moveSideways(p) != 0) {
                    if (p.onGround()) p.jumpFromGround();
                    double yaw = Math.toRadians(p.getYRot());
                    double angle = yaw - Math.atan2(Compat.moveForward(p), Compat.moveSideways(p)) + Math.PI / 2;
                    double spd = 0.26;
                    p.setDeltaMovement(-Math.sin(angle) * spd, p.getDeltaMovement().y, Math.cos(angle) * spd);
                }
            }

            // ── SPEED ──
            if (speedOn && Compat26.currentScreen(mc) == null && !strafeOn) {
                float fw = Compat.moveForward(p);
                float st = Compat.moveSideways(p);
                if (fw != 0 || st != 0) {
                    double yaw   = Math.toRadians(p.getYRot());
                    double spd   = speedVal / 20.0;
                    double angle = yaw - Math.atan2(fw, st) + Math.PI / 2;
                    double vx = -Math.sin(angle) * spd;
                    double vz =  Math.cos(angle) * spd;

                    switch (speedBypass) {
                        case 4 -> { // NCP
                            if (p.onGround()) p.jumpFromGround();
                            else { vx *= 1.02; vz *= 1.02; p.setDeltaMovement(p.getDeltaMovement().x, p.getDeltaMovement().y - 0.02, p.getDeltaMovement().z); }
                        }
                        case 5 -> { // Matrix
                            if (p.onGround()) p.jumpFromGround();
                            vx *= 1.01; vz *= 1.01;
                        }
                        case 6 -> { // Grim
                            spd = 0.28;
                            vx = -Math.sin(angle) * spd; vz = Math.cos(angle) * spd;
                        }
                        case 7 -> { // Funtime
                            if (p.onGround()) p.jumpFromGround();
                            vx *= 1.005; vz *= 1.005;
                        }
                        case 8 -> { // ReallyWorld
                            spd = 0.26;
                            vx = -Math.sin(angle) * spd; vz = Math.cos(angle) * spd;
                        }
                        case 9 -> { // Vulcan
                            if (p.onGround()) p.jumpFromGround();
                            if (p.tickCount % 2 == 0) { vx *= 1.01; vz *= 1.01; }
                        }
                        case 10 -> { // Spartan
                            spd = 0.25;
                            vx = -Math.sin(angle) * spd; vz = Math.cos(angle) * spd;
                        }
                    }
                    p.setDeltaMovement(vx, p.getDeltaMovement().y, vz);
                }
            }

            // ── FLY ──
            if (flyOn) {
                p.getAbilities().flying = true;
                double vy = 0;
                if (mc.options.keyJump.isDown())   vy =  flySpeed / 10.0;
                if (mc.options.keyShift.isDown())   vy = -flySpeed / 10.0;

                float fw = Compat.moveForward(p);
                float st = Compat.moveSideways(p);
                double vx = p.getDeltaMovement().x;
                double vz = p.getDeltaMovement().z;

                if (fw != 0 || st != 0) {
                    double yaw   = Math.toRadians(p.getYRot());
                    double spd   = flySpeed / 20.0;
                    double angle = yaw - Math.atan2(fw, st) + Math.PI / 2;
                    vx = -Math.sin(angle) * spd;
                    vz =  Math.cos(angle) * spd;
                } else { vx = 0; vz = 0; }

                switch (flyBypass) {
                    case 4 -> vy = -0.04; // NCP
                    case 5 -> { if (p.tickCount % 10 == 0) vy = 0.1; else vy = -0.05; } // Matrix
                    case 6 -> vy = 0; // Grim
                    case 7 -> vy = -0.01; // Funtime
                    case 8 -> vy = -0.03; // ReallyWorld
                    case 9 -> { if (p.tickCount % 5 == 0) vy = 0.05; else vy = -0.05; } // Vulcan
                    case 10 -> vy = -0.02; // Spartan
                }
                p.setDeltaMovement(vx, vy, vz);
            } else {
                if (mc.player != null && !mc.player.isCreative() && !mc.player.isSpectator()) {
                    mc.player.getAbilities().flying = false;
                }
            }

            // ── KILLAURA (ROBUST 1.9+ LOGIC) ──
            if (auraOn) {
                auraTick++;

                // Smooth rotation logic
                if (isRotating && (auraRotMode == 2 || auraRotMode == 16 || auraRotMode == 17)) {
                    if (auraRotMode == 2) {
                        p.setYRot(p.getYRot() + (targetYaw - p.getYRot()) * 0.4f);
                        p.setXRot(p.getXRot() + (targetPitch - p.getXRot()) * 0.4f);
                    } else if (auraRotMode == 16) {
                        float smoothFactor = 0.01f + (auraStickiness / 100f) * 0.99f; // 0.01 to 1.0
                        float diffYaw = targetYaw - p.getYRot();
                        float diffPitch = targetPitch - p.getXRot();

                        // Apply curve
                        if (auraRotCurve > 0) {
                            float curve = (auraRotCurve / 100f) * 30.0f;
                            diffYaw += (float)(Math.sin(auraTick * 0.2) * curve);
                            diffPitch += (float)(Math.cos(auraTick * 0.2) * curve);
                        }

                        p.setYRot(p.getYRot() + diffYaw * smoothFactor);
                        p.setXRot(p.getXRot() + diffPitch * smoothFactor);
                    } else if (auraRotMode == 17) {
                        float diffYaw = targetYaw - p.getYRot();
                        float diffPitch = targetPitch - p.getXRot();

                        // Base smoothing
                        float smoothFactor = 0.05f + (auraStickiness / 100f) * 0.95f;

                        // Add looping effect (figure-8 pattern)
                        float loopSize = (auraRotCurve / 100f) * 40.0f;
                        float loopSpeed = 0.3f;

                        diffYaw += (float)(Math.sin(auraTick * loopSpeed) * loopSize);
                        diffPitch += (float)(Math.sin(auraTick * loopSpeed * 2.0) * loopSize * 0.5f);

                        p.setYRot(p.getYRot() + diffYaw * smoothFactor);
                        p.setXRot(p.getXRot() + diffPitch * smoothFactor);
                    }
                }

                if (auraHitInGuis || Compat26.currentScreen(mc) == null) {
                    var list = mc.level.getEntities(p, p.getBoundingBox().inflate(auraRange), e -> {
                        if (!(e instanceof LivingEntity) || !e.isAlive() || e == p || e.isSpectator()) return false;
                        if (friends.contains(e.getName().getString())) return false;

                        boolean isPlayer = e instanceof net.minecraft.world.entity.player.Player;
                        boolean isMob = e instanceof net.minecraft.world.entity.monster.Monster;
                        boolean isAnimal = e instanceof net.minecraft.world.entity.animal.Animal;

                        if (isPlayer && !auraTargetPlayers) return false;
                        if (isMob && !auraTargetMobs) return false;
                        if (isAnimal && !auraTargetAnimals) return false;

                        if (antiBotOn) {
                            if (e.isInvisible() || e.tickCount < 20 || e.getName().getString().isEmpty() || e.getName().getString().contains(" ")) return false;
                        }

                        // FOV Check
                        if (auraFov < 360f) {
                            float[] rots = getRotations(p, e);
                            float yawDiff = Math.abs(net.minecraft.util.Mth.wrapDegrees(p.getYRot() - rots[0]));
                            if (yawDiff > auraFov / 2f) return false;
                        }

                        return true;
                    });

                    LivingEntity target = null;
                    if (!list.isEmpty()) {
                        switch (auraTargetMode) {
                            case 0 -> target = (LivingEntity) list.stream().min(Comparator.comparingDouble(e -> ((net.minecraft.world.entity.Entity) e).distanceTo(p))).orElse(null); // Distance
                            case 1 -> target = (LivingEntity) list.stream().min(Comparator.comparingDouble(e -> ((LivingEntity)e).getHealth())).orElse(null); // Health
                            case 2 -> target = (LivingEntity) list.stream().min(Comparator.comparingDouble(e -> ((LivingEntity)e).getArmorValue())).orElse(null); // Armor
                            case 3 -> target = (LivingEntity) list.stream().min(Comparator.comparingDouble(e -> getAngleDifference(p, e))).orElse(null); // Angle
                        }
                    }

                    currentTarget = target;

                    if (target != null && p.distanceTo(target) <= auraRange) {
                        if (!auraThroughWalls && !p.hasLineOfSight(target)) target = null;

                        if (target != null) {

                            // 1. Calculate Rotations
                            float[] rots = getRotations(p, target);
                            float idealYaw = rots[0];
                            float idealPitch = rots[1];

                            // Apply auraRotSpeed limit
                            if (auraRotSpeed < 180.0f) {
                                float diffYaw = net.minecraft.util.Mth.wrapDegrees(idealYaw - p.getYRot());
                                float diffPitch = idealPitch - p.getXRot();

                                if (diffYaw > auraRotSpeed) diffYaw = auraRotSpeed;
                                if (diffYaw < -auraRotSpeed) diffYaw = -auraRotSpeed;
                                if (diffPitch > auraRotSpeed) diffPitch = auraRotSpeed;
                                if (diffPitch < -auraRotSpeed) diffPitch = -auraRotSpeed;

                                targetYaw = p.getYRot() + diffYaw;
                                targetPitch = p.getXRot() + diffPitch;
                            } else {
                                targetYaw = idealYaw;
                                targetPitch = idealPitch;
                            }
                            isRotating = true;

                            // Apply Rotations based on mode
                            switch (auraRotMode) {
                                case 1 -> { // Snap
                                    p.setYRot(targetYaw);
                                    p.setXRot(targetPitch);
                                }
                                case 2 -> { // Smooth (handled above)
                                }
                                case 3 -> { // Silent
                                    mc.getConnection().send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot(targetYaw, targetPitch, p.onGround(), false));
                                }
                                case 4 -> { // Matrix (Randomized Jitter)
                                    p.setYRot(targetYaw + (float)(Math.random() * 6 - 3));
                                    p.setXRot(targetPitch + (float)(Math.random() * 6 - 3));
                                }
                                case 5 -> { // Predict
                                    double predX = target.getX() + (target.getX() - target.xOld) * 2.0;
                                    double predZ = target.getZ() + (target.getZ() - target.zOld) * 2.0;
                                    double dx = predX - p.getX();
                                    double dz = predZ - p.getZ();
                                    double dy = (target.getY() + target.getEyeHeight(target.getPose())) - (p.getY() + p.getEyeHeight(p.getPose()));
                                    double dist = Math.sqrt(dx * dx + dz * dz);
                                    targetYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
                                    targetPitch = (float) -Math.toDegrees(Math.atan2(dy, dist));
                                    p.setYRot(p.getYRot() + (targetYaw - p.getYRot()) * 0.5f);
                                    p.setXRot(p.getXRot() + (targetPitch - p.getXRot()) * 0.5f);
                                }
                                case 6 -> { // Smart (Super smooth, free but snapping)
                                    targetYaw += (float)((Math.random() - 0.5) * 4.0);
                                    targetPitch += (float)((Math.random() - 0.5) * 4.0);
                                    p.setYRot(p.getYRot() + (targetYaw - p.getYRot()) * 0.25f);
                                    p.setXRot(p.getXRot() + (targetPitch - p.getXRot()) * 0.25f);
                                }
                                case 7 -> { // Legit (Smooth, no jitter, precise)
                                    p.setYRot(p.getYRot() + (targetYaw - p.getYRot()) * 0.15f);
                                    p.setXRot(p.getXRot() + (targetPitch - p.getXRot()) * 0.15f);
                                }
                                case 8 -> { // HvH (Instant snap, max precision)
                                    p.setYRot(targetYaw);
                                    p.setXRot(targetPitch);
                                }
                                case 9 -> { // Derp (Random crazy rotations, but hits target)
                                    targetYaw += (float)((Math.random() - 0.5) * 360.0);
                                    targetPitch += (float)((Math.random() - 0.5) * 180.0);
                                    p.setYRot(targetYaw);
                                    p.setXRot(targetPitch);
                                }
                                case 10 -> { // Cinematic (Extremely smooth)
                                    p.setYRot(p.getYRot() + (targetYaw - p.getYRot()) * 0.05f);
                                    p.setXRot(p.getXRot() + (targetPitch - p.getXRot()) * 0.05f);
                                }
                                case 11 -> { // NCP (Strict limits on rotation speed)
                                    float diffYaw = targetYaw - p.getYRot();
                                    float diffPitch = targetPitch - p.getXRot();
                                    diffYaw = Math.max(-30f, Math.min(30f, diffYaw));
                                    diffPitch = Math.max(-15f, Math.min(15f, diffPitch));
                                    p.setYRot(p.getYRot() + diffYaw);
                                    p.setXRot(p.getXRot() + diffPitch);
                                }
                                case 12 -> { // AAC (Specific jitter)
                                    p.setYRot(targetYaw + (float)(Math.sin(System.currentTimeMillis() / 100.0) * 2.0));
                                    p.setXRot(targetPitch + (float)(Math.cos(System.currentTimeMillis() / 100.0) * 2.0));
                                }
                                case 13 -> { // Sunrise (Specific RU server bypass)
                                    targetYaw += (float)((Math.random() - 0.5) * 1.5);
                                    targetPitch += (float)((Math.random() - 0.5) * 1.5);
                                    p.setYRot(p.getYRot() + (targetYaw - p.getYRot()) * 0.4f);
                                    p.setXRot(p.getXRot() + (targetPitch - p.getXRot()) * 0.4f);
                                }
                                case 14 -> { // Vulcan (Vulcan AC specific rotations)
                                    float diffYaw = targetYaw - p.getYRot();
                                    diffYaw = Math.round(diffYaw / 0.5f) * 0.5f; // Round to nearest 0.5
                                    p.setYRot(p.getYRot() + diffYaw * 0.8f);
                                    p.setXRot(targetPitch);
                                }
                                case 15 -> { // Intave (Very strict, needs to be perfectly aligned but with slight realistic jitter, and no snapping)
                                    p.setYRot(p.getYRot() + (targetYaw - p.getYRot()) * 0.1f + (float)(Math.random() - 0.5) * 0.5f);
                                    p.setXRot(p.getXRot() + (targetPitch - p.getXRot()) * 0.1f + (float)(Math.random() - 0.5) * 0.5f);
                                }
                                case 16 -> { // Legit Smooth (handled above)
                                }
                                case 17 -> { // Looping (handled above)
                                }
                                case 18 -> { // LiquidBounce
                                    float diffYaw = targetYaw - p.getYRot();
                                    float diffPitch = targetPitch - p.getXRot();

                                    // LiquidBounce uses a specific randomized step
                                    float step = 40.0f + (float)Math.random() * 10.0f;
                                    diffYaw = Math.max(-step, Math.min(step, diffYaw));
                                    diffPitch = Math.max(-step, Math.min(step, diffPitch));

                                    p.setYRot(p.getYRot() + diffYaw);
                                    p.setXRot(p.getXRot() + diffPitch);
                                }
                                case 19 -> { // Custom
                                    float diffYaw = targetYaw - p.getYRot();
                                    float diffPitch = targetPitch - p.getXRot();
                                    float smooth = 0.01f + (auraStickiness / 100f) * 0.99f;
                                    p.setYRot(p.getYRot() + diffYaw * smooth);
                                    p.setXRot(p.getXRot() + diffPitch * smooth);
                                }
                                case 20 -> { // Noise
                                    float noiseYaw = (float)(Math.sin(auraTick * 0.5) * (auraRotCurve / 100f) * 20.0f);
                                    float noisePitch = (float)(Math.cos(auraTick * 0.5) * (auraRotCurve / 100f) * 20.0f);
                                    p.setYRot(targetYaw + noiseYaw);
                                    p.setXRot(targetPitch + noisePitch);
                                }
                            }

                            // 2. Check if we can hit
                            boolean canHit = false;

                            // STRICT 1.9 COOLDOWN CHECK
                            float cooldown = p.getAttackStrengthScale(0.0f);

                            switch (auraMode) {
                                case 0 -> { // 1.9 Strict
                                    // Must be exactly 1.0f or higher to ensure full damage and no spam
                                    if (cooldown >= 1.0f) {
                                        canHit = true;
                                    }
                                }
                                case 1 -> { // 1.8 Spam
                                    canHit = auraTick % 2 == 0;
                                }
                                case 2 -> { // Adaptive (Randomized cooldown to bypass anti-cheats)
                                    if (cooldown >= (0.85f + Math.random() * 0.15f)) {
                                        canHit = true;
                                    }
                                }
                            }

                            // Timing Check (Jump Phase)
                            if (canHit) {
                                if (auraTimingMode == 1) { // Fall (Crits)
                                    if (p.getDeltaMovement().y >= 0 || p.onGround()) canHit = false;
                                } else if (auraTimingMode == 2) { // Jump (Crits)
                                    if (p.onGround() || p.getDeltaMovement().y <= 0) canHit = false;
                                }
                            }

                            // Raycast check (if enabled, ensure we are actually looking at them)
                            if (canHit && auraRayCast && auraRotMode != 3) { // If not silent
                                double dToT = p.distanceTo(target);
                                Vec3 eyePos = p.getEyePosition(1.0f);
                                Vec3 lookVec = p.getViewVector(1.0f);
                                Vec3 traceEnd = eyePos.add(lookVec.x * dToT, lookVec.y * dToT, lookVec.z * dToT);
                                HitResult hit = mc.hitResult;
                                // If we hit a block before the entity, don't hit (unless through walls is on)
                                if (!auraThroughWalls && hit.getType() == HitResult.Type.BLOCK) {
                                    canHit = false;
                                }
                            }

                            // 3. Bypasses
                            if (canHit) {
                                switch (auraBypass) {
                                    case 2 -> { if (auraTick % 3 != 0) canHit = false; }
                                    case 3 -> { // Strafe around
                                        double circleAngle = Math.toRadians(targetYaw + 90);
                                        p.setDeltaMovement(-Math.sin(circleAngle) * 0.2, p.getDeltaMovement().y, Math.cos(circleAngle) * 0.2);
                                    }
                                    case 5 -> { if (Math.random() > 0.8) canHit = false; } // Matrix
                                    case 6 -> { if (!p.hasLineOfSight(target)) canHit = false; } // Grim
                                    case 7 -> { // Funtime
                                        if (Math.random() > 0.9) canHit = false;
                                        if (!p.hasLineOfSight(target)) canHit = false;
                                    }
                                    case 8 -> { // ReallyWorld
                                        if (cooldown < 1.0f) canHit = false;
                                        if (!p.hasLineOfSight(target)) canHit = false;
                                    }
                                    case 9 -> { // Vulcan
                                        if (p.tickCount % 2 != 0) canHit = false;
                                    }
                                    case 10 -> { // Spartan
                                        if (p.distanceTo(target) > 3.5f) canHit = false;
                                    }
                                    case 11 -> { // Grim AC (Strict Raycast & Timing)
                                        if (cooldown < 1.0f) canHit = false;
                                        if (!p.hasLineOfSight(target)) canHit = false;
                                        if (Math.abs(p.getYRot() - targetYaw) > 15) canHit = false; // Must be looking precisely
                                    }
                                    case 12 -> { // Polar AC (Randomized Delays & Smooth Rots)
                                        if (cooldown < 0.95f + Math.random() * 0.05f) canHit = false;
                                        if (auraTick % (2 + (int)(Math.random() * 2)) != 0) canHit = false; // Random hits
                                    }
                                    case 13 -> { // Intave
                                        if (cooldown < 1.0f) canHit = false;
                                        if (p.distanceTo(target) > 3.0f) canHit = false; // Strict reach
                                        if (Math.abs(p.getYRot() - targetYaw) > 20) canHit = false; // Must be looking at target
                                    }
                                }
                            }

                            // 4. Attack
                            if (canHit) {
                                // Weapon selection: Shield Breaker works even with AutoWeapon off.
                                boolean blockingPlayer = shieldBreaker && target instanceof net.minecraft.world.entity.player.Player tp && tp.isBlocking();
                                if (autoWeapon || blockingPlayer) {
                                    int bestSlot = findBestWeapon(p, blockingPlayer);
                                    if (bestSlot >= 0) p.getInventory().setSelectedSlot(bestSlot);
                                }

                                // Criticals (Mini-jump)
                                if (criticals && (p.onGround() || (waterCrits && p.isInWater()))) {
                                    p.push(0, 0.1, 0);
                                    p.fallDistance = 0.1f;
                                    p.setOnGround(false);
                                }

                                // Visuals Particles
                                if (visualsOn && visualsParticles > 0) {
                                    net.minecraft.core.particles.ParticleOptions particle = net.minecraft.core.particles.ParticleTypes.CRIT;
                                    if (visualsParticles == 2) particle = net.minecraft.core.particles.ParticleTypes.FLAME;
                                    else if (visualsParticles == 3) particle = net.minecraft.core.particles.ParticleTypes.WITCH;
                                    else if (visualsParticles == 4) particle = net.minecraft.core.particles.ParticleTypes.ENCHANTED_HIT;

                                    for (int i = 0; i < 5; i++) {
                                        Compat.addParticle(mc.level, particle, target.getX() + (Math.random() - 0.5), target.getY() + Math.random() * target.getBbHeight(), target.getZ() + (Math.random() - 0.5), 0, 0, 0);
                                    }
                                }

                                if (auraJump && p.onGround()) p.jumpFromGround();

                                mc.gameMode.attack(p, target);
                                Compat26.swing(p);
                                p.resetAttackStrengthTicker(); // Reset cooldown
                            }
                        }
                    } else {
                        currentTarget = null;
                        isRotating = false;
                        if (auraSpinBot) p.setYRot(p.getYRot() + 45f);
                    }
                }
            } else {
                if (mc.hitResult != null && mc.hitResult.getType() == HitResult.Type.ENTITY) {
                    Entity e = ((EntityHitResult) mc.hitResult).getEntity();
                    if (e instanceof LivingEntity) currentTarget = (LivingEntity) e;
                } else {
                    currentTarget = null;
                }
                isRotating = false;
                if (auraSpinBot) p.setYRot(p.getYRot() + 45f);
            }

            PypsenFeatures.tick(mc);

            if (xrayOn != xrayWasOn) {
                mc.levelRenderer.resetLevelRenderData();
                xrayWasOn = xrayOn;
            }
        });
    }

    private static float[] getRotations(Entity p, Entity target) {
        return getRotations(p, target, true);
    }

    private static float[] getRotations(Entity p, Entity target, boolean applyAuraJitter) {
        double targetX = target.getX();
        double targetZ = target.getZ();
        double targetY = target.getY();

        if (auraPredict) {
            Vec3 v = target.getDeltaMovement();
            targetX += v.x * 2.0;
            targetZ += v.z * 2.0;
        }

        switch (auraTargetPart) {
            case 0 -> targetY += target.getEyeHeight(target.getPose()); // Head
            case 1 -> targetY += target.getBbHeight() * 0.6; // Chest
            case 2 -> targetY += target.getBbHeight() * 0.2; // Legs
            case 3 -> {} // Feet
        }

        if (applyAuraJitter && (auraAimJitter > 0 || auraRandomize)) {
            double jitter = auraRandomize ? Math.max(auraAimJitter, 0.1) : auraAimJitter;
            targetX += (Math.random() - 0.5) * jitter;
            targetY += (Math.random() - 0.5) * jitter;
            targetZ += (Math.random() - 0.5) * jitter;
        }

        double dx = targetX - p.getX();
        double dz = targetZ - p.getZ();
        double dy = targetY - (p.getY() + p.getEyeHeight(p.getPose()));
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        // GCD Fix
        float f = Minecraft.getInstance().options.sensitivity().get().floatValue() * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        yaw -= yaw % gcd;
        pitch -= pitch % gcd;

        return new float[]{yaw, pitch};
    }

    private static int getArmorScore(net.minecraft.world.item.ItemStack stack) { return Compat.getArmorScore(stack); }

    private static int findBestWeapon(net.minecraft.client.player.LocalPlayer p, boolean preferAxe) { return Compat.findBestWeapon(p, preferAxe); }

    private static boolean isValidTriggerTarget(Entity e, net.minecraft.client.player.LocalPlayer p, Minecraft mc) {
        if (!(e instanceof LivingEntity living) || !living.isAlive() || e == p || e.isSpectator()) return false;
        if (friends.contains(e.getName().getString())) return false;
        if (p.distanceTo(e) > triggerRange) return false;

        boolean isPlayer = e instanceof net.minecraft.world.entity.player.Player;
        boolean isMob = e instanceof net.minecraft.world.entity.monster.Monster;
        boolean isAnimal = e instanceof net.minecraft.world.entity.animal.Animal;
        if (isPlayer && !triggerTargetPlayers) return false;
        if (isMob && !triggerTargetMobs) return false;
        if (isAnimal && !triggerTargetAnimals) return false;

        if (antiBotOn && isPlayer && (e.tickCount < 20 || e.getName().getString().isEmpty() || e.getName().getString().contains(" "))) return false;
        if (!triggerThroughWalls && !p.hasLineOfSight(e)) return false;
        return true;
    }

    private static int getHealthColor(float hp, float maxHp) {
        float ratio = hp / maxHp;
        if (ratio > 0.75f) return 0xFF00FF00; // Green
        if (ratio > 0.5f) return 0xFFFFFF00;  // Yellow
        if (ratio > 0.25f) return 0xFFFF8800; // Orange
        return 0xFFFF0000;                    // Red
    }

    private static double getAngleDifference(Entity p, Entity e) {
        float[] rots = getRotations(p, e, false);
        return Math.abs(Mth.wrapDegrees(p.getYRot() - rots[0]));
    }

    private static float[] projectToScreen(Vec3 pos, Vec3 camPos, org.joml.Vector3fc right,
                                           org.joml.Vector3fc up, org.joml.Vector3fc forward,
                                           double focal, int sw, int sh) {
        double rx = pos.x - camPos.x;
        double ry = pos.y - camPos.y;
        double rz = pos.z - camPos.z;
        double cx = rx * right.x() + ry * right.y() + rz * right.z();
        double cy = rx * up.x() + ry * up.y() + rz * up.z();
        double cz = rx * forward.x() + ry * forward.y() + rz * forward.z();
        if (cz <= 0.1) return null;

        float sx = (float) (sw * 0.5 + (cx / cz) * focal);
        float sy = (float) (sh * 0.5 - (cy / cz) * focal);
        if (sx < -4096f || sx > 4096f || sy < -4096f || sy > 4096f) return null;
        return new float[]{sx, sy, (float) cz};
    }

    private static void drawEspLine(DrawContext26 ctx, int x0, int y0, int x1, int y1, int color) {
        int dx = Math.abs(x1 - x0);
        int dy = Math.abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1;
        int sy = y0 < y1 ? 1 : -1;
        int err = dx - dy;
        while (true) {
            ctx.fill(x0, y0, x0 + 1, y0 + 1, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = err * 2;
            if (e2 > -dy) { err -= dy; x0 += sx; }
            if (e2 < dx) { err += dx; y0 += sy; }
        }
    }

    private static int espColor(Entity e) {
        if (e == currentTarget) return 0xFFFFFF00;
        if (e instanceof net.minecraft.world.entity.player.Player) {
            return friends.contains(e.getName().getString()) ? 0xFF55FF55 : 0xFFFF5555;
        }
        if (e instanceof ItemEntity) return 0xFF55FFFF;
        if (e instanceof net.minecraft.world.entity.monster.Monster) return 0xFFFF8800;
        return 0xFF55FF55;
    }

    private static void drawEsp(DrawContext26 ctx, Minecraft mc, float tickDelta) {
        if (!espOn || mc.level == null || mc.player == null) return;
        Camera camera = mc.gameRenderer.mainCamera();
        if (!camera.isInitialized()) return;

        Vec3 camPos = Compat.cameraPos(camera);
        org.joml.Vector3fc right = Compat26.cameraRight(camera);
        org.joml.Vector3fc up = camera.upVector();
        org.joml.Vector3fc forward = camera.forwardVector();

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        double fov = mc.gameRenderer.mainCamera().getFov();
        double halfFov = Math.toRadians(fov) * 0.5;
        double focal = (sh * 0.5) / Math.tan(halfFov);
        if (!Double.isFinite(focal) || focal <= 0 || halfFov <= 0 || halfFov >= Math.PI * 0.5) return;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player || e.isSpectator()) continue;

            boolean isItem = e instanceof ItemEntity;
            if (!isItem && !(e instanceof LivingEntity)) continue;
            if (e instanceof LivingEntity && !((LivingEntity) e).isAlive()) continue;

            if (isItem) {
                if (!espItemsOn) continue;
            } else {
                boolean isPlayer = e instanceof net.minecraft.world.entity.player.Player;
                boolean isMob = e instanceof net.minecraft.world.entity.monster.Monster;
                boolean isAnimal = e instanceof net.minecraft.world.entity.animal.Animal;
                if (isPlayer && !espPlayersOn) continue;
                if (isMob && !espMobsOn) continue;
                if (isAnimal && !espAnimalsOn) continue;
            }

            double dist = mc.player.distanceTo(e);
            if (dist > espRange) continue;

            AABB box = e.getBoundingBox();
            double ox = Mth.lerp(tickDelta, e.xOld, e.getX()) - e.getX();
            double oy = Mth.lerp(tickDelta, e.yOld, e.getY()) - e.getY();
            double oz = Mth.lerp(tickDelta, e.zOld, e.getZ()) - e.getZ();
            double minX = box.minX + ox, minY = box.minY + oy, minZ = box.minZ + oz;
            double maxX = box.maxX + ox, maxY = box.maxY + oy, maxZ = box.maxZ + oz;

            float minSx = Float.POSITIVE_INFINITY, minSy = Float.POSITIVE_INFINITY;
            float maxSx = Float.NEGATIVE_INFINITY, maxSy = Float.NEGATIVE_INFINITY;
            boolean fullyVisible = true;

            for (int i = 0; i < 8; i++) {
                double px = (i & 1) == 0 ? minX : maxX;
                double py = (i & 2) == 0 ? minY : maxY;
                double pz = (i & 4) == 0 ? minZ : maxZ;
                float[] s = projectToScreen(new Vec3(px, py, pz), camPos, right, up, forward, focal, sw, sh);
                if (s == null) { fullyVisible = false; break; }
                minSx = Math.min(minSx, s[0]);
                minSy = Math.min(minSy, s[1]);
                maxSx = Math.max(maxSx, s[0]);
                maxSy = Math.max(maxSy, s[1]);
            }
            if (!fullyVisible || maxSx < minSx || maxSy < minSy) continue;

            int x1 = Mth.clamp((int) minSx, 0, sw);
            int y1 = Mth.clamp((int) minSy, 0, sh);
            int x2 = Mth.clamp((int) maxSx, 0, sw);
            int y2 = Mth.clamp((int) maxSy, 0, sh);
            if (x2 - x1 < 2 || y2 - y1 < 2) continue;

            int color = espColor(e);
            if (espFillOn) ctx.fill(x1, y1, x2, y2, (color & 0x00FFFFFF) | 0x22000000);

            if (espBoxesOn || isItem) {
                ctx.fill(x1, y1, x2, y1 + 1, color);
                ctx.fill(x1, y2 - 1, x2, y2, color);
                ctx.fill(x1, y1, x1 + 1, y2, color);
                ctx.fill(x2 - 1, y1, x2, y2, color);
            }

            if (espTracersOn) {
                drawEspLine(ctx, sw / 2, sh - 1, (x1 + x2) / 2, (y1 + y2) / 2, (color & 0x00FFFFFF) | 0x88000000);
            }

            String label;
            if (isItem) {
                ItemStack stack = ((ItemEntity) e).getItem();
                label = stack.getHoverName().getString() + " x" + stack.getCount();
            } else {
                label = PypsenFeatures.label(e.getName().getString(), "Entity");
            }

            int textY = Math.max(2, y1 - 11);
            if (espNamesOn) {
                ctx.drawTextWithShadow(mc.font, Component.literal(label), x1, textY, color);
                textY -= 10;
            }
            if (espDistanceOn) {
                ctx.drawTextWithShadow(mc.font, Component.literal(String.format("%.1fm", dist)), x2 + 3, y1, 0xFFAAAAAA);
            }
            if (espHealthOn && e instanceof LivingEntity living) {
                float ratio = living.getMaxHealth() > 0 ? living.getHealth() / living.getMaxHealth() : 0f;
                ratio = Mth.clamp(ratio, 0f, 1f);
                int barW = Math.max(1, x2 - x1);
                ctx.fill(x1, y2 + 2, x1 + barW, y2 + 5, 0xFF333333);
                ctx.fill(x1, y2 + 2, x1 + (int) (barW * ratio), y2 + 5, getHealthColor(living.getHealth(), living.getMaxHealth()));
            }
        }
    }

    private static final Set<Integer> pressedKeys = new HashSet<>();
    private static boolean wasPressed(long handle, int key) {
        if (key == GlfwCompat.GLFW_KEY_UNKNOWN) return false;
        boolean down = GlfwCompat.glfwGetKey(handle, key) == GlfwCompat.GLFW_PRESS;
        if (down && pressedKeys.add(key)) return true;
        if (!down) pressedKeys.remove(key);
        return false;
    }

    public static String keyName(int key) {
        if (key == GlfwCompat.GLFW_KEY_UNKNOWN) return "NONE";
        String name = GlfwCompat.glfwGetKeyName(key, 0);
        if (name != null) return name.toUpperCase();
        return switch (key) {
            case GlfwCompat.GLFW_KEY_MINUS       -> "MINUS";
            case GlfwCompat.GLFW_KEY_LEFT_SHIFT  -> "LSHIFT";
            case GlfwCompat.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GlfwCompat.GLFW_KEY_LEFT_CONTROL-> "LCTRL";
            case GlfwCompat.GLFW_KEY_SPACE       -> "SPACE";
            case GlfwCompat.GLFW_KEY_TAB         -> "TAB";
            default -> "KEY_" + key;
        };
    }

    // ══════════ CONFIG SYSTEM ══════════
    public static void saveConfig() {
        try {
            File file = new File(Minecraft.getInstance().gameDirectory, "pypsen_config.txt");
            FileWriter writer = new FileWriter(file);
            writer.write("speedVal=" + speedVal + "\n");
            writer.write("auraRange=" + auraRange + "\n");
            writer.write("hitboxVal=" + hitboxVal + "\n");
            writer.write("flySpeed=" + flySpeed + "\n");
            writer.write("clickerCps=" + clickerCps + "\n");
            writer.write("triggerCps=" + triggerCps + "\n");
            writer.write("auraMode=" + auraMode + "\n");
            writer.write("auraBypass=" + auraBypass + "\n");
            writer.write("speedBypass=" + speedBypass + "\n");
            writer.write("flyBypass=" + flyBypass + "\n");
            writer.write("auraRotMode=" + auraRotMode + "\n");
            writer.write("auraTargetMode=" + auraTargetMode + "\n");
            writer.write("auraTimingMode=" + auraTimingMode + "\n");
            writer.write("auraTargetPart=" + auraTargetPart + "\n");
            writer.write("visualsTargetMode=" + visualsTargetMode + "\n");
            writer.write("auraAimJitter=" + auraAimJitter + "\n");
            writer.write("auraStickiness=" + auraStickiness + "\n");
            writer.write("auraRotCurve=" + auraRotCurve + "\n");
            writer.write("auraRotSpeed=" + auraRotSpeed + "\n");
            writer.write("auraFov=" + auraFov + "\n");
            writer.write("triggerRange=" + triggerRange + "\n");
            writer.write("auraTargetPlayers=" + auraTargetPlayers + "\n");
            writer.write("auraTargetMobs=" + auraTargetMobs + "\n");
            writer.write("auraTargetAnimals=" + auraTargetAnimals + "\n");
            writer.write("autoWeapon=" + autoWeapon + "\n");
            writer.write("criticals=" + criticals + "\n");
            writer.write("auraThroughWalls=" + auraThroughWalls + "\n");
            writer.write("auraHitInGuis=" + auraHitInGuis + "\n");
            writer.write("auraSpinBot=" + auraSpinBot + "\n");
            writer.write("triggerWeaponOnly=" + triggerWeaponOnly + "\n");
            writer.write("autoTotemOn=" + autoTotemOn + "\n");
            writer.write("autoTotemHealth=" + autoTotemHealth + "\n");
            writer.write("autoTotemMode=" + autoTotemMode + "\n");
            writer.write("aimLockOn=" + aimLockOn + "\n");
            writer.write("aimOn=" + aimOn + "\n");
            writer.write("aimSpeed=" + aimSpeed + "\n");
            writer.write("antiBotOn=" + antiBotOn + "\n");
            writer.write("fullBrightOn=" + fullBrightOn + "\n");
            writer.write("nameHiderOn=" + nameHiderOn + "\n");
            writer.write("spiderOn=" + spiderOn + "\n");
            writer.write("spiderMode=" + spiderMode + "\n");
            writer.write("noWebOn=" + noWebOn + "\n");
            writer.write("noWebMode=" + noWebMode + "\n");
            writer.write("noclipOn=" + noclipOn + "\n");
            writer.write("noclipBypass=" + noclipBypass + "\n");
            writer.write("freezeOn=" + freezeOn + "\n");
            writer.write("freezeMode=" + freezeMode + "\n");
            writer.write("airJumpOn=" + airJumpOn + "\n");
            writer.write("airJumpMode=" + airJumpMode + "\n");
            writer.write("noFallOn=" + noFallOn + "\n");
            writer.write("noFallMode=" + noFallMode + "\n");
            writer.write("velocityMode=" + velocityMode + "\n");
            writer.write("jesusOn=" + jesusOn + "\n");
            writer.write("jesusMode=" + jesusMode + "\n");
            writer.write("visualsParticles=" + visualsParticles + "\n");
            writer.write("waterCrits=" + waterCrits + "\n");
            writer.write("crasherTimerMode=" + crasherTimerMode + "\n");
            writer.write("godModeMode=" + godModeMode + "\n");
            writer.write("seeInvisOn=" + seeInvisOn + "\n");
            writer.write("noFireOn=" + noFireOn + "\n");
            writer.write("noNauseaOn=" + noNauseaOn + "\n");
            writer.write("targetEspOn=" + targetEspOn + "\n");
            writer.write("noHurtCamOn=" + noHurtCamOn + "\n");
            writer.write("playerEspOn=" + playerEspOn + "\n");
            writer.write("shieldBreaker=" + shieldBreaker + "\n");
            writer.write("keyEsp=" + keyEsp + "\n");
            writer.write("hudOn=" + hudOn + "\n");
            writer.write("targetHudOn=" + targetHudOn + "\n");
            writer.write("fakeName=" + fakeName + "\n");
            writer.write("useModernGui=" + useModernGui + "\n");
            writer.write("espOn=" + espOn + "\n");
            writer.write("espBoxesOn=" + espBoxesOn + "\n");
            writer.write("espNamesOn=" + espNamesOn + "\n");
            writer.write("espHealthOn=" + espHealthOn + "\n");
            writer.write("espDistanceOn=" + espDistanceOn + "\n");
            writer.write("espItemsOn=" + espItemsOn + "\n");
            writer.write("espTracersOn=" + espTracersOn + "\n");
            writer.write("espFillOn=" + espFillOn + "\n");
            writer.write("espPlayersOn=" + espPlayersOn + "\n");
            writer.write("espMobsOn=" + espMobsOn + "\n");
            writer.write("espAnimalsOn=" + espAnimalsOn + "\n");
            writer.write("espRange=" + espRange + "\n");
            writer.write("triggerThroughWalls=" + triggerThroughWalls + "\n");
            writer.write("triggerSmartDelay=" + triggerSmartDelay + "\n");
            writer.write("triggerTargetPlayers=" + triggerTargetPlayers + "\n");
            writer.write("triggerTargetMobs=" + triggerTargetMobs + "\n");
            writer.write("triggerTargetAnimals=" + triggerTargetAnimals + "\n");
            writer.write("triggerAutoWeapon=" + triggerAutoWeapon + "\n");
            writer.write("triggerCriticals=" + triggerCriticals + "\n");
            writer.write("triggerWaitHurtTime=" + triggerWaitHurtTime + "\n");
            writer.write("triggerCooldown=" + triggerCooldown + "\n");
            writer.write("triggerJitter=" + triggerJitter + "\n");
            writer.write("triggerFov=" + triggerFov + "\n");
            writer.write("friends=" + String.join(",", friends) + "\n");
            PypsenFeatures.save(writer);
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void loadConfig() {
        try {
            File file = new File(Minecraft.getInstance().gameDirectory, "pypsen_config.txt");
            if (!file.exists()) return;
            List<String> lines = Files.readAllLines(file.toPath());
            for (String line : lines) {
                String[] parts = line.split("=", 2);
                if (parts.length < 2) continue;
                String key = parts[0];
                String val = parts[1];
                switch (key) {
                    case "speedVal" -> speedVal = Float.parseFloat(val);
                    case "auraRange" -> auraRange = Float.parseFloat(val);
                    case "hitboxVal" -> hitboxVal = Float.parseFloat(val);
                    case "flySpeed" -> flySpeed = Float.parseFloat(val);
                    case "clickerCps" -> clickerCps = Float.parseFloat(val);
                    case "triggerCps" -> triggerCps = Float.parseFloat(val);
                    case "auraMode" -> auraMode = Integer.parseInt(val);
                    case "auraBypass" -> auraBypass = Integer.parseInt(val);
                    case "speedBypass" -> speedBypass = Integer.parseInt(val);
                    case "flyBypass" -> flyBypass = Integer.parseInt(val);
                    case "auraRotMode" -> auraRotMode = Integer.parseInt(val);
                    case "auraTargetMode" -> auraTargetMode = Integer.parseInt(val);
                    case "auraTimingMode" -> auraTimingMode = Integer.parseInt(val);
                    case "auraTargetPart" -> auraTargetPart = Integer.parseInt(val);
                    case "visualsTargetMode" -> visualsTargetMode = Integer.parseInt(val);
                    case "auraAimJitter" -> auraAimJitter = Float.parseFloat(val);
                    case "auraStickiness" -> auraStickiness = Float.parseFloat(val);
                    case "auraRotCurve" -> auraRotCurve = Float.parseFloat(val);
                    case "auraRotSpeed" -> auraRotSpeed = Float.parseFloat(val);
                    case "auraFov" -> auraFov = Float.parseFloat(val);
                    case "triggerRange" -> triggerRange = Float.parseFloat(val);
                    case "auraTargetPlayers" -> auraTargetPlayers = Boolean.parseBoolean(val);
                    case "auraTargetMobs" -> auraTargetMobs = Boolean.parseBoolean(val);
                    case "auraTargetAnimals" -> auraTargetAnimals = Boolean.parseBoolean(val);
                    case "autoWeapon" -> autoWeapon = Boolean.parseBoolean(val);
                    case "criticals" -> criticals = Boolean.parseBoolean(val);
                    case "auraThroughWalls" -> auraThroughWalls = Boolean.parseBoolean(val);
                    case "auraHitInGuis" -> auraHitInGuis = Boolean.parseBoolean(val);
                    case "auraSpinBot" -> auraSpinBot = Boolean.parseBoolean(val);
                    case "triggerWeaponOnly" -> triggerWeaponOnly = Boolean.parseBoolean(val);
                    case "autoTotemOn" -> autoTotemOn = Boolean.parseBoolean(val);
                    case "autoTotemHealth" -> autoTotemHealth = Float.parseFloat(val);
                    case "autoTotemMode" -> autoTotemMode = Integer.parseInt(val);
                    case "aimLockOn" -> aimLockOn = Boolean.parseBoolean(val);
                    case "aimOn" -> aimOn = Boolean.parseBoolean(val);
                    case "aimSpeed" -> aimSpeed = Float.parseFloat(val);
                    case "antiBotOn" -> antiBotOn = Boolean.parseBoolean(val);
                    case "fullBrightOn" -> fullBrightOn = Boolean.parseBoolean(val);
                    case "nameHiderOn" -> nameHiderOn = Boolean.parseBoolean(val);
                    case "spiderOn" -> spiderOn = Boolean.parseBoolean(val);
                    case "spiderMode" -> spiderMode = Integer.parseInt(val);
                    case "noWebOn" -> noWebOn = Boolean.parseBoolean(val);
                    case "noWebMode" -> noWebMode = Integer.parseInt(val);
                    case "noclipOn" -> noclipOn = Boolean.parseBoolean(val);
                    case "noclipBypass" -> noclipBypass = Integer.parseInt(val);
                    case "freezeOn" -> freezeOn = Boolean.parseBoolean(val);
                    case "freezeMode" -> freezeMode = Integer.parseInt(val);
                    case "airJumpOn" -> airJumpOn = Boolean.parseBoolean(val);
                    case "airJumpMode" -> airJumpMode = Integer.parseInt(val);
                    case "noFallOn" -> noFallOn = Boolean.parseBoolean(val);
                    case "noFallMode" -> noFallMode = Integer.parseInt(val);
                    case "velocityMode" -> velocityMode = Integer.parseInt(val);
                    case "jesusOn" -> jesusOn = Boolean.parseBoolean(val);
                    case "jesusMode" -> jesusMode = Integer.parseInt(val);
                    case "visualsParticles" -> visualsParticles = Integer.parseInt(val);
                    case "waterCrits" -> waterCrits = Boolean.parseBoolean(val);
                    case "crasherTimerMode" -> crasherTimerMode = Integer.parseInt(val);
                    case "godModeMode" -> godModeMode = Integer.parseInt(val);
                    case "seeInvisOn" -> seeInvisOn = Boolean.parseBoolean(val);
                    case "noFireOn" -> noFireOn = Boolean.parseBoolean(val);
                    case "noNauseaOn" -> noNauseaOn = Boolean.parseBoolean(val);
                    case "targetEspOn" -> targetEspOn = Boolean.parseBoolean(val);
                    case "noHurtCamOn" -> noHurtCamOn = Boolean.parseBoolean(val);
                    case "playerEspOn" -> playerEspOn = Boolean.parseBoolean(val);
                    case "shieldBreaker" -> shieldBreaker = Boolean.parseBoolean(val);
                    case "keyEsp" -> keyEsp = Integer.parseInt(val);
                    case "hudOn" -> hudOn = Boolean.parseBoolean(val);
                    case "targetHudOn" -> targetHudOn = Boolean.parseBoolean(val);
                    case "fakeName" -> fakeName = val;
                    case "useModernGui" -> useModernGui = Boolean.parseBoolean(val);
                    case "espOn" -> espOn = Boolean.parseBoolean(val);
                    case "espBoxesOn" -> espBoxesOn = Boolean.parseBoolean(val);
                    case "espNamesOn" -> espNamesOn = Boolean.parseBoolean(val);
                    case "espHealthOn" -> espHealthOn = Boolean.parseBoolean(val);
                    case "espDistanceOn" -> espDistanceOn = Boolean.parseBoolean(val);
                    case "espItemsOn" -> espItemsOn = Boolean.parseBoolean(val);
                    case "espTracersOn" -> espTracersOn = Boolean.parseBoolean(val);
                    case "espFillOn" -> espFillOn = Boolean.parseBoolean(val);
                    case "espPlayersOn" -> espPlayersOn = Boolean.parseBoolean(val);
                    case "espMobsOn" -> espMobsOn = Boolean.parseBoolean(val);
                    case "espAnimalsOn" -> espAnimalsOn = Boolean.parseBoolean(val);
                    case "espRange" -> espRange = Float.parseFloat(val);
                    case "triggerThroughWalls" -> triggerThroughWalls = Boolean.parseBoolean(val);
                    case "triggerSmartDelay" -> triggerSmartDelay = Boolean.parseBoolean(val);
                    case "triggerTargetPlayers" -> triggerTargetPlayers = Boolean.parseBoolean(val);
                    case "triggerTargetMobs" -> triggerTargetMobs = Boolean.parseBoolean(val);
                    case "triggerTargetAnimals" -> triggerTargetAnimals = Boolean.parseBoolean(val);
                    case "triggerAutoWeapon" -> triggerAutoWeapon = Boolean.parseBoolean(val);
                    case "triggerCriticals" -> triggerCriticals = Boolean.parseBoolean(val);
                    case "triggerWaitHurtTime" -> triggerWaitHurtTime = Boolean.parseBoolean(val);
                    case "triggerCooldown" -> triggerCooldown = Float.parseFloat(val);
                    case "triggerJitter" -> triggerJitter = Float.parseFloat(val);
                    case "triggerFov" -> triggerFov = Float.parseFloat(val);
                    case "friends" -> {
                        friends.clear();
                        if (!val.isEmpty()) friends.addAll(Arrays.asList(val.split(",")));
                    }
                    default -> PypsenFeatures.load(key, val);
                }
            }

            // Keep every parsed value inside the range the GUI and modes expect.
            espRange = Mth.clamp(espRange, 5f, 256f);
            triggerRange = Mth.clamp(triggerRange, 1f, 12f);
            triggerCps = Mth.clamp(triggerCps, 1f, 50f);
            triggerCooldown = Mth.clamp(triggerCooldown, 0f, 1f);
            triggerJitter = Mth.clamp(triggerJitter, 0f, 100f);
            triggerFov = Mth.clamp(triggerFov, 1f, 180f);
            auraMode = Mth.clamp(auraMode, 0, AURA_MODES.length - 1);
            auraRotMode = Mth.clamp(auraRotMode, 0, AURA_ROTS.length - 1);
            auraTimingMode = Mth.clamp(auraTimingMode, 0, AURA_TIMINGS.length - 1);
            auraTargetPart = Mth.clamp(auraTargetPart, 0, AURA_PARTS.length - 1);
            auraTargetMode = Mth.clamp(auraTargetMode, 0, AURA_TARGETS.length - 1);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ══════════ XRAY SCREEN ══════════
    public static class XrayScreen extends Screen {
        private final Screen parent;
        private net.minecraft.client.gui.components.EditBox searchField;
        private int scroll = 0;
        private final List<Block> allBlocks = new ArrayList<>();
        private final List<Block> filteredBlocks = new ArrayList<>();

        public XrayScreen(Screen parent) {
            super(Component.literal("XRay Blocks"));
            this.parent = parent;
            BuiltInRegistries.BLOCK.forEach(b -> {
                if (b != Blocks.AIR && b != Blocks.CAVE_AIR && b != Blocks.VOID_AIR) {
                    allBlocks.add(b);
                }
            });
            allBlocks.sort(Comparator.comparing(b -> b.getName().getString()));
            filteredBlocks.addAll(allBlocks);
        }

        @Override
        protected void init() {
            GuiCompat26.add(this, Button.builder(Component.literal("<- Back"), b -> {
                Minecraft.getInstance().setScreenAndShow(parent);
                Minecraft.getInstance().levelRenderer.resetLevelRenderData();
            }).bounds(10, 10, 60, 20).build());

            searchField = new net.minecraft.client.gui.components.EditBox(font, width / 2 - 100, 10, 200, 20, Component.literal("Search"));
            searchField.setResponder(text -> {
                filteredBlocks.clear();
                String q = text.toLowerCase();
                for (Block b : allBlocks) {
                    if (b.getName().getString().toLowerCase().contains(q)) {
                        filteredBlocks.add(b);
                    }
                }
                scroll = 0;
            });
            GuiCompat26.add(this, searchField);
        }

        @Override
        public void extractRenderState(GuiGraphicsExtractor rawCtx, int mx, int my, float d) {
            DrawContext26 ctx = new DrawContext26(rawCtx);
            super.extractRenderState(rawCtx, mx, my, d);

            int y = 40 + scroll;
            int x = width / 2 - 100;

            for (int i = 0; i < filteredBlocks.size(); i++) {
                if (y > 30 && y < height - 20) {
                    Block b = filteredBlocks.get(i);
                    boolean on = XRAY_BLOCKS.contains(b);
                    String name = b.getName().getString();
                    if (name.length() > 25) name = name.substring(0, 25) + "..";

                    boolean hovered = mx >= x && mx <= x + 200 && my >= y && my <= y + 20;
                    ctx.fill(x, y, x + 200, y + 20, on ? 0x7700FF00 : (hovered ? 0x77555555 : 0x77000000));
                    ctx.drawTextWithShadow(font, name, x + 5, y + 6, 0xFFFFFF);
                    ctx.drawTextWithShadow(font, on ? "ON" : "OFF", x + 175, y + 6, on ? 0x55FF55 : 0xFF5555);
                }
                y += 22;
            }
        }

        @Override
        public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent click, boolean doubled) {
            double mx = click.x(); double my = click.y(); int button = click.button();
            if (super.mouseClicked(click, doubled)) return true;
            int y = 40 + scroll;
            int x = width / 2 - 100;
            for (int i = 0; i < filteredBlocks.size(); i++) {
                if (y > 30 && y < height - 20) {
                    if (mx >= x && mx <= x + 200 && my >= y && my <= y + 20) {
                        Block b = filteredBlocks.get(i);
                        if (XRAY_BLOCKS.contains(b)) XRAY_BLOCKS.remove(b);
                        else XRAY_BLOCKS.add(b);
                        return true;
                    }
                }
                y += 22;
            }
            return false;
        }

        @Override
        public boolean mouseScrolled(double mx, double my, double dx, double amount) {
            scroll += (int)(amount * 22);
            if (scroll > 0) scroll = 0;
            int maxScroll = -(filteredBlocks.size() * 22 - (height - 60));
            if (maxScroll > 0) maxScroll = 0;
            if (scroll < maxScroll) scroll = maxScroll;
            return true;
        }
    }

    // ══════════ MAIN MENU SCREEN ══════════
    public static class MenuScreen extends Screen {
        private int scroll = 0;
        private int bindingTarget = -1;

        public MenuScreen() { super(Component.literal("Pypsen v2")); }

        @Override
        protected void init() { buildWidgets(); }

        private void applyPreset(String preset) {
            switch (preset) {
                case "Funtime" -> {
                    auraRange = 3.0f; auraMode = 0; auraRotMode = 2; auraBypass = 7;
                    hitboxVal = 0.1f; velocityOn = true; antiFlagOn = true; auraThroughWalls = false;
                    speedBypass = 7; flyBypass = 7; auraHitInGuis = false; autoWeapon = true; criticals = true;
                }
                case "ReallyWorld" -> {
                    auraRange = 3.0f; auraMode = 0; auraRotMode = 1; auraBypass = 8;
                    hitboxVal = 0.1f; velocityOn = true; antiFlagOn = true; auraThroughWalls = false;
                    speedBypass = 8; flyBypass = 8; auraHitInGuis = false; autoWeapon = true; criticals = true;
                }
                case "Test" -> {
                    auraRange = 3.5f; auraMode = 0; auraRotMode = 2; auraBypass = 4;
                    hitboxVal = 0.5f; velocityOn = false; antiFlagOn = true; auraThroughWalls = false;
                    speedBypass = 4; flyBypass = 4; auraHitInGuis = true; autoWeapon = false; criticals = false;
                }
                case "HvH" -> {
                    auraRange = 6.0f; auraMode = 1; auraRotMode = 3; auraBypass = 0;
                    hitboxVal = 2.0f; velocityOn = true; antiFlagOn = false; auraThroughWalls = true;
                    speedBypass = 0; flyBypass = 0; auraHitInGuis = true; autoWeapon = true; criticals = true;
                }
            }
            rebuild();
        }

        private void buildWidgets() {
            GuiCompat26.clear(this);
            int x = width / 2 - 105;
            int y = 30 + scroll;
            int w = 210;

            // Save Config Button
            GuiCompat26.add(this, Button.builder(Component.literal("\u00a7b\u25BC Save Config to Documents \u25BC"), b -> {
                saveConfig();
            }).bounds(x, y, w, 20).build()); y += 26;

            GuiCompat26.add(this, Button.builder(Component.literal("\u00a7d\u2728 Switch to Modern GUI \u2728"), b -> {
                useModernGui = true;
                if (Minecraft.getInstance() != null) Minecraft.getInstance().setScreenAndShow(new ModernGuiScreen());
            }).bounds(x, y, w, 20).build()); y += 26;

            GuiCompat26.add(this, Button.builder(Component.literal("\u00a7e--- PRESETS ---"), b -> {}).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Funtime"), b -> applyPreset("Funtime")).bounds(x, y, w/2 - 2, 20).build());
            GuiCompat26.add(this, Button.builder(Component.literal("ReallyWorld"), b -> applyPreset("ReallyWorld")).bounds(x + w/2 + 4, y, w/2 - 4, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Test"), b -> applyPreset("Test")).bounds(x, y, w/2 - 2, 20).build());
            GuiCompat26.add(this, Button.builder(Component.literal("HvH"), b -> applyPreset("HvH")).bounds(x + w/2 + 4, y, w/2 - 4, 20).build()); y += 26;

            y = section(x, y, w, "KillAura", auraOn, b -> { auraOn = !auraOn; rebuild(); }, keyAura, 1);
            GuiCompat26.add(this, slider(x, y, w, "Range", 1f, 20f, auraRange, v -> auraRange = v)); y += 22;
            GuiCompat26.add(this, cycleBtn(x, y, w, "Mode", AURA_MODES, auraMode, v -> { auraMode = v; rebuild(); })); y += 22;
            GuiCompat26.add(this, cycleBtn(x, y, w, "Target", AURA_TARGETS, auraTargetMode, v -> { auraTargetMode = v; rebuild(); })); y += 22;
            GuiCompat26.add(this, cycleBtn(x, y, w, "Rotation", AURA_ROTS, auraRotMode, v -> { auraRotMode = v; rebuild(); })); y += 22;
            GuiCompat26.add(this, cycleBtn(x, y, w, "Timing", AURA_TIMINGS, auraTimingMode, v -> { auraTimingMode = v; rebuild(); })); y += 22;
            GuiCompat26.add(this, cycleBtn(x, y, w, "Aim Part", AURA_PARTS, auraTargetPart, v -> { auraTargetPart = v; rebuild(); })); y += 22;
            GuiCompat26.add(this, slider(x, y, w, "Aim Jitter", 0f, 1f, auraAimJitter, v -> auraAimJitter = v)); y += 22;
            GuiCompat26.add(this, slider(x, y, w, "Stickiness", 0f, 100f, auraStickiness, v -> auraStickiness = v)); y += 22;
            GuiCompat26.add(this, slider(x, y, w, "Rot Curve", 0f, 100f, auraRotCurve, v -> auraRotCurve = v)); y += 22;
            GuiCompat26.add(this, slider(x, y, w, "Rot Speed", 1f, 180f, auraRotSpeed, v -> auraRotSpeed = v)); y += 22;
            GuiCompat26.add(this, slider(x, y, w, "FOV", 10f, 360f, auraFov, v -> auraFov = v)); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Predict: " + (auraPredict ? "§aON" : "§cOFF")), b -> { auraPredict = !auraPredict; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Randomize: " + (auraRandomize ? "§aON" : "§cOFF")), b -> { auraRandomize = !auraRandomize; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, cycleBtn(x, y, w, "Bypass", BYPASS_NAMES, auraBypass, v -> { auraBypass = v; rebuild(); })); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Target Players: " + (auraTargetPlayers ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraTargetPlayers = !auraTargetPlayers; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Target Mobs: " + (auraTargetMobs ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraTargetMobs = !auraTargetMobs; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Target Animals: " + (auraTargetAnimals ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraTargetAnimals = !auraTargetAnimals; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("AutoWeapon: " + (autoWeapon ? "\u00a7aON" : "\u00a7cOFF")), b -> { autoWeapon = !autoWeapon; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Criticals: " + (criticals ? "\u00a7aON" : "\u00a7cOFF")), b -> { criticals = !criticals; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Shield Breaker: " + (shieldBreaker ? "\u00a7aON" : "\u00a7cOFF")), b -> { shieldBreaker = !shieldBreaker; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Water Crits: " + (waterCrits ? "\u00a7aON" : "\u00a7cOFF")), b -> { waterCrits = !waterCrits; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Jump & Attack: " + (auraJump ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraJump = !auraJump; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Through Walls: " + (auraThroughWalls ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraThroughWalls = !auraThroughWalls; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Hit in GUIs: " + (auraHitInGuis ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraHitInGuis = !auraHitInGuis; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("AntiBot: " + (antiBotOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { antiBotOn = !antiBotOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("SpinBot (Idle): " + (auraSpinBot ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraSpinBot = !auraSpinBot; rebuild(); }).bounds(x, y, w, 20).build()); y += 26;

            y = section(x, y, w, "Visuals (ESP)", visualsOn, b -> { visualsOn = !visualsOn; rebuild(); }, keyVisuals, 8);
            GuiCompat26.add(this, cycleBtn(x, y, w, "Target", VISUALS_TARGETS, visualsTargetMode, v -> { visualsTargetMode = v; rebuild(); })); y += 22;
            GuiCompat26.add(this, cycleBtn(x, y, w, "Particles", PARTICLES_MODES, visualsParticles, v -> { visualsParticles = v; rebuild(); })); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Player ESP (Tags): " + (playerEspOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { playerEspOn = !playerEspOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("FullBright: " + (fullBrightOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { fullBrightOn = !fullBrightOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("NameHider (Record): " + (nameHiderOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { nameHiderOn = !nameHiderOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("See Invisibles: " + (seeInvisOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { seeInvisOn = !seeInvisOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("No Fire: " + (noFireOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { noFireOn = !noFireOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("No Nausea: " + (noNauseaOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { noNauseaOn = !noNauseaOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Target ESP: " + (targetEspOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { targetEspOn = !targetEspOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("NoHurtCam: " + (noHurtCamOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { noHurtCamOn = !noHurtCamOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 26;

            y = section(x, y, w, "2D ESP", espOn, b -> { espOn = !espOn; rebuild(); }, keyEsp, 28);
            GuiCompat26.add(this, slider(x, y, w, "Range", 5f, 256f, espRange, v -> espRange = v)); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Boxes: " + (espBoxesOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espBoxesOn = !espBoxesOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Names: " + (espNamesOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espNamesOn = !espNamesOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Health: " + (espHealthOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espHealthOn = !espHealthOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Distance: " + (espDistanceOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espDistanceOn = !espDistanceOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Fill: " + (espFillOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espFillOn = !espFillOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Tracers: " + (espTracersOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espTracersOn = !espTracersOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Players: " + (espPlayersOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espPlayersOn = !espPlayersOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Mobs: " + (espMobsOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espMobsOn = !espMobsOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Animals: " + (espAnimalsOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espAnimalsOn = !espAnimalsOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Items: " + (espItemsOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espItemsOn = !espItemsOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 26;

            y = section(x, y, w, "TriggerBot", triggerBotOn, b -> { triggerBotOn = !triggerBotOn; rebuild(); }, keyTriggerBot, 13);
            GuiCompat26.add(this, slider(x, y, w, "CPS", 1f, 50f, triggerCps, v -> triggerCps = v)); y += 22;
            GuiCompat26.add(this, slider(x, y, w, "Range", 1f, 12f, triggerRange, v -> triggerRange = v)); y += 22;
            GuiCompat26.add(this, slider(x, y, w, "Cooldown", 0f, 1f, triggerCooldown, v -> triggerCooldown = v)); y += 22;
            GuiCompat26.add(this, slider(x, y, w, "Jitter %", 0f, 100f, triggerJitter, v -> triggerJitter = v)); y += 22;
            GuiCompat26.add(this, slider(x, y, w, "Scan FOV", 1f, 180f, triggerFov, v -> triggerFov = v)); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Weapon Only: " + (triggerWeaponOnly ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerWeaponOnly = !triggerWeaponOnly; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Smart Delay: " + (triggerSmartDelay ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerSmartDelay = !triggerSmartDelay; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Wait Hurt Time: " + (triggerWaitHurtTime ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerWaitHurtTime = !triggerWaitHurtTime; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Through Walls: " + (triggerThroughWalls ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerThroughWalls = !triggerThroughWalls; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Auto Weapon: " + (triggerAutoWeapon ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerAutoWeapon = !triggerAutoWeapon; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Criticals: " + (triggerCriticals ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerCriticals = !triggerCriticals; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Target Players: " + (triggerTargetPlayers ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerTargetPlayers = !triggerTargetPlayers; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Target Mobs: " + (triggerTargetMobs ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerTargetMobs = !triggerTargetMobs; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Target Animals: " + (triggerTargetAnimals ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerTargetAnimals = !triggerTargetAnimals; rebuild(); }).bounds(x, y, w, 20).build()); y += 26;

            y = section(x, y, w, "AutoTotem", autoTotemOn, b -> { autoTotemOn = !autoTotemOn; rebuild(); }, keyAutoTotem, 16);
            GuiCompat26.add(this, slider(x, y, w, "Health", 1f, 20f, autoTotemHealth, v -> autoTotemHealth = v)); y += 22;
            GuiCompat26.add(this, cycleBtn(x, y, w, "Mode", TOTEM_MODES, autoTotemMode, v -> { autoTotemMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "AutoClicker", autoClickerOn, b -> { autoClickerOn = !autoClickerOn; rebuild(); }, keyAutoClicker, 10);
            GuiCompat26.add(this, slider(x, y, w, "CPS", 1f, 50f, clickerCps, v -> clickerCps = v)); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Right Click: " + (autoClickerRight ? "§aON" : "§cOFF")), b -> { autoClickerRight = !autoClickerRight; rebuild(); }).bounds(x, y, w, 20).build()); y += 22;
            GuiCompat26.add(this, Button.builder(Component.literal("Farm Mode: " + (autoClickerFarm ? "§aON" : "§cOFF")), b -> { autoClickerFarm = !autoClickerFarm; rebuild(); }).bounds(x, y, w, 20).build()); y += 26;

            y = section(x, y, w, "FreeCam", freecamOn, b -> {
                freecamOn = !freecamOn;
                if (freecamOn && Minecraft.getInstance().player != null) {
                    freecamPos = Compat.entityPos(Minecraft.getInstance().player);
                    freecamYaw = Minecraft.getInstance().player.getYRot();
                    freecamPitch = Minecraft.getInstance().player.getXRot();
                } else if (!freecamOn && Minecraft.getInstance().player != null) {
                    Minecraft.getInstance().player.noPhysics = false;
                    Minecraft.getInstance().player.getAbilities().flying = false;
                    if (freecamPos != null) {
                        Minecraft.getInstance().player.setPos(freecamPos);
                        Minecraft.getInstance().player.setYRot(freecamYaw);
                        Minecraft.getInstance().player.setXRot(freecamPitch);
                        Minecraft.getInstance().player.setDeltaMovement(0, 0, 0);
                    }
                }
                rebuild();
            }, keyFreecam, 15); y += 26;

            y = section(x, y, w, "AimAssist", aimOn, b -> { aimOn = !aimOn; rebuild(); }, keyAim, 6);
            GuiCompat26.add(this, slider(x, y, w, "Smooth Speed", 1f, 100f, aimSpeed, v -> aimSpeed = v)); y += 26;

            y = section(x, y, w, "\u00a75AimLock (Hard Lock)", aimLockOn, b -> { aimLockOn = !aimLockOn; rebuild(); }, keyAimLock, 17); y += 4;

            y = section(x, y, w, "Hitbox", hitboxOn, b -> { hitboxOn = !hitboxOn; rebuild(); }, keyHitbox, 2);
            GuiCompat26.add(this, slider(x, y, w, "Size (Cube)", 0.1f, 1000f, hitboxVal, v -> hitboxVal = v)); y += 26;

            y = section(x, y, w, "Velocity (Anti-KB)", velocityOn, b -> { velocityOn = !velocityOn; rebuild(); }, keyVelocity, 5);
            GuiCompat26.add(this, cycleBtn(x, y, w, "Mode", VELOCITY_MODES, velocityMode, v -> { velocityMode = v; rebuild(); })); y += 26;
            y = section(x, y, w, "Strafe", strafeOn, b -> { strafeOn = !strafeOn; rebuild(); }, keyStrafe, 7); y += 4;
            y = section(x, y, w, "Noclip", noclipOn, b -> { noclipOn = !noclipOn; rebuild(); }, keyNoclip, 11);
            GuiCompat26.add(this, cycleBtn(x, y, w, "Mode", NOCLIP_MODES, noclipBypass, v -> { noclipBypass = v; rebuild(); })); y += 26;
            y = section(x, y, w, "Anti-Flag", antiFlagOn, b -> { antiFlagOn = !antiFlagOn; rebuild(); }, keyAntiFlag, 12); y += 4;

            y = section(x, y, w, "Spider", spiderOn, b -> { spiderOn = !spiderOn; rebuild(); }, keySpider, 18);
            GuiCompat26.add(this, cycleBtn(x, y, w, "Mode", SPIDER_MODES, spiderMode, v -> { spiderMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "NoWeb", noWebOn, b -> { noWebOn = !noWebOn; rebuild(); }, keyNoWeb, 19);
            GuiCompat26.add(this, cycleBtn(x, y, w, "Mode", NOWEB_MODES, noWebMode, v -> { noWebMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "Freeze", freezeOn, b -> { freezeOn = !freezeOn; rebuild(); }, keyFreeze, 20);
            GuiCompat26.add(this, cycleBtn(x, y, w, "Mode", FREEZE_MODES, freezeMode, v -> { freezeMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "AirJump", airJumpOn, b -> { airJumpOn = !airJumpOn; rebuild(); }, keyAirJump, 25);
            GuiCompat26.add(this, cycleBtn(x, y, w, "Mode", AIRJUMP_MODES, airJumpMode, v -> { airJumpMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "NoFall", noFallOn, b -> { noFallOn = !noFallOn; rebuild(); }, keyNoFall, 26);
            GuiCompat26.add(this, cycleBtn(x, y, w, "Mode", NOFALL_MODES, noFallMode, v -> { noFallMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "Jesus", jesusOn, b -> { jesusOn = !jesusOn; rebuild(); }, keyJesus, 27);
            GuiCompat26.add(this, cycleBtn(x, y, w, "Mode", JESUS_MODES, jesusMode, v -> { jesusMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "Speed", speedOn, b -> { speedOn = !speedOn; rebuild(); }, keySpeed, 0);
            GuiCompat26.add(this, slider(x, y, w, "Speed", 0.1f, 100f, speedVal, v -> speedVal = v)); y += 22;
            GuiCompat26.add(this, cycleBtn(x, y, w, "Bypass", BYPASS_NAMES, speedBypass, v -> { speedBypass = v; rebuild(); })); y += 26;

            y = section(x, y, w, "Fly", flyOn, b -> { flyOn = !flyOn; rebuild(); }, keyFly, 3);
            GuiCompat26.add(this, slider(x, y, w, "Fly Speed", 0.1f, 50f, flySpeed, v -> flySpeed = v)); y += 22;
            GuiCompat26.add(this, cycleBtn(x, y, w, "Bypass", BYPASS_NAMES, flyBypass, v -> { flyBypass = v; rebuild(); })); y += 26;

            y = section(x, y, w, "XRay", xrayOn, b -> { xrayOn = !xrayOn; Minecraft.getInstance().levelRenderer.resetLevelRenderData(); rebuild(); }, keyXray, 4);
            GuiCompat26.add(this, Button.builder(Component.literal("Select XRay Blocks..."), b -> {
                Minecraft.getInstance().setScreenAndShow(new XrayScreen(this));
            }).bounds(x, y, w, 20).build()); y += 26;

            y = section(x, y, w, "HUD Settings", hudOn, b -> { hudOn = !hudOn; rebuild(); }, GlfwCompat.GLFW_KEY_UNKNOWN, -1);
            GuiCompat26.add(this, Button.builder(Component.literal("Target HUD: " + (targetHudOn ? "§aON" : "§cOFF")), b -> { targetHudOn = !targetHudOn; rebuild(); }).bounds(x, y, w, 20).build()); y += 26;
            GuiCompat26.add(this, Button.builder(Component.literal("\u00a5 Advanced Features (AI / Crystal / FakeLag / Food)"), b -> {
                Minecraft.getInstance().setScreenAndShow(new PypsenFeatures.FeaturesScreen(this));
            }).bounds(x, y, w, 20).build()); y += 26;

            y = section(x, y, w, "Server Crasher", serverCrasherOn, b -> { serverCrasherOn = !serverCrasherOn; rebuild(); }, keyCrasher, 21);
            GuiCompat26.add(this, cycleBtn(x, y, w, "Mode", CRASHER_MODES, crasherMode, v -> { crasherMode = v; rebuild(); })); y += 22;
            GuiCompat26.add(this, cycleBtn(x, y, w, "Timer", CRASHER_TIMERS, crasherTimerMode, v -> { crasherTimerMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "GodMode", godModeOn, b -> { godModeOn = !godModeOn; rebuild(); }, keyGodMode, 22);
            GuiCompat26.add(this, cycleBtn(x, y, w, "Mode", GODMODE_MODES, godModeMode, v -> { godModeMode = v; rebuild(); })); y += 26;
            y = section(x, y, w, "AutoArmor", autoArmorOn, b -> { autoArmorOn = !autoArmorOn; rebuild(); }, keyAutoArmor, 23); y += 4;

            y = section(x, y, w, "FastBow", fastBowOn, b -> { fastBowOn = !fastBowOn; rebuild(); }, keyFastBow, 24);
            GuiCompat26.add(this, Button.builder(Component.literal("BowJump: " + (bowJump ? "§aON" : "§cOFF")), b -> { bowJump = !bowJump; rebuild(); }).bounds(x, y, w, 20).build()); y += 26;

            GuiCompat26.add(this, Button.builder(Component.literal("Drop All Items"), b -> { dropAllItems = true; }).bounds(x, y, w, 20).build()); y += 26;

            GuiCompat26.add(this, bindBtn(x, y, w, "Panic Key", keyPanic, 14)); y += 22;
            GuiCompat26.add(this, bindBtn(x, y, w, "Menu Key", keyMenu, 9));
        }

        private int section(int x, int y, int w, String name, boolean on, java.util.function.Consumer<Button> toggle, int key, int bindId) {
            int halfW = w / 2 - 2;
            GuiCompat26.add(this, Button.builder(Component.literal(name + ": " + (on ? "\u00a7aON" : "\u00a7cOFF")), b -> toggle.accept(b)).bounds(x, y, halfW, 20).build());
            if (bindId != -1) {
                GuiCompat26.add(this, bindBtn(x + halfW + 4, y, halfW, "Key", key, bindId));
            }
            return y + 22;
        }

        private Button bindBtn(int x, int y, int w, String label, int key, int id) {
            String text = (bindingTarget == id) ? label + ": \u00a7e[...]" : label + ": \u00a7f" + keyName(key);
            return Button.builder(Component.literal(text), b -> { bindingTarget = id; rebuild(); }).bounds(x, y, w, 20).build();
        }

        private Button cycleBtn(int x, int y, int w, String label, String[] options, int current, java.util.function.Consumer<Integer> setter) {
            return Button.builder(Component.literal(label + ": \u00a7b" + options[current]), b -> setter.accept((current + 1) % options.length)).bounds(x, y, w, 20).build();
        }

        @Override
        public boolean keyPressed(net.minecraft.client.input.KeyEvent input) {
            int keyCode = input.key(); int scanCode = 0; int modifiers = input.modifiers();
            if (bindingTarget >= 0 && keyCode != GlfwCompat.GLFW_KEY_ESCAPE) {
                switch (bindingTarget) {
                    case 0 -> keySpeed       = keyCode;
                    case 1 -> keyAura        = keyCode;
                    case 2 -> keyHitbox      = keyCode;
                    case 3 -> keyFly         = keyCode;
                    case 4 -> keyXray        = keyCode;
                    case 5 -> keyVelocity    = keyCode;
                    case 6 -> keyAim         = keyCode;
                    case 7 -> keyStrafe      = keyCode;
                    case 8 -> keyVisuals     = keyCode;
                    case 9 -> keyMenu        = keyCode;
                    case 10 -> keyAutoClicker= keyCode;
                    case 11 -> keyNoclip     = keyCode;
                    case 12 -> keyAntiFlag   = keyCode;
                    case 13 -> keyTriggerBot = keyCode;
                    case 14 -> keyPanic      = keyCode;
                    case 15 -> keyFreecam    = keyCode;
                    case 16 -> keyAutoTotem  = keyCode;
                    case 17 -> keyAimLock    = keyCode;
                    case 18 -> keySpider     = keyCode;
                    case 19 -> keyNoWeb      = keyCode;
                    case 20 -> keyFreeze     = keyCode;
                    case 21 -> keyCrasher    = keyCode;
                    case 22 -> keyGodMode    = keyCode;
                    case 23 -> keyAutoArmor  = keyCode;
                    case 24 -> keyFastBow    = keyCode;
                    case 25 -> keyAirJump    = keyCode;
                    case 26 -> keyNoFall     = keyCode;
                    case 27 -> keyJesus      = keyCode;
                    case 28 -> keyEsp        = keyCode;
                }
                bindingTarget = -1;
                rebuild();
                return true;
            }
            if (keyCode == GlfwCompat.GLFW_KEY_ESCAPE && bindingTarget >= 0) {
                bindingTarget = -1;
                rebuild();
                return true;
            }
            return super.keyPressed(input);
        }

        @Override
        public boolean mouseScrolled(double mouseX, double mouseY, double dx, double amount) {
            if (bindingTarget >= 0) {
                switch (bindingTarget) {
                    case 0 -> keySpeed       = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 1 -> keyAura        = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 2 -> keyHitbox      = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 3 -> keyFly         = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 4 -> keyXray        = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 5 -> keyVelocity    = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 6 -> keyAim         = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 7 -> keyStrafe      = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 8 -> keyVisuals     = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 9 -> keyMenu        = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 10 -> keyAutoClicker= GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 11 -> keyNoclip     = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 12 -> keyAntiFlag   = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 13 -> keyTriggerBot = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 14 -> keyPanic      = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 15 -> keyFreecam    = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 16 -> keyAutoTotem  = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 17 -> keyAimLock    = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 18 -> keySpider     = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 19 -> keyNoWeb      = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 20 -> keyFreeze     = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 21 -> keyCrasher    = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 22 -> keyGodMode    = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 23 -> keyAutoArmor  = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 24 -> keyFastBow    = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 25 -> keyAirJump    = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 26 -> keyNoFall     = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 27 -> keyJesus      = GlfwCompat.GLFW_KEY_UNKNOWN;
                    case 28 -> keyEsp        = GlfwCompat.GLFW_KEY_UNKNOWN;
                }
                bindingTarget = -1;
                rebuild();
                return true;
            }

            scroll += (int)(amount * 25);
            if (scroll > 0) scroll = 0;
            rebuild();
            return true;
        }

        @Override
        public void extractRenderState(GuiGraphicsExtractor rawCtx, int mx, int my, float d) {
            DrawContext26 ctx = new DrawContext26(rawCtx);
            ctx.drawCenteredTextWithShadow(font, "\u00a7a\u00a7l\u2588 Pypsen v2 \u2588", width / 2, 10, 0x55FF55);
            super.extractRenderState(rawCtx, mx, my, d);
        }

        @Override public boolean isPauseScreen() { return false; }

        private void rebuild() {
            buildWidgets();
        }
    }

    // ══════════ MODERN GUI SCREEN ══════════
    public static class ModernGuiScreen extends Screen {
        public static int[] cX = {20, 180, 340, 500};
        public static int[] cY = {40, 40, 40, 40};
        public static Set<String> expanded = new HashSet<>();
        private int[] curY = new int[4];
        private int dragging = -1;
        private int dragX, dragY;
        private int bindingTarget = -1;

        public ModernGuiScreen() { super(Component.literal("Modern GUI")); }

        @Override
        protected void init() {
            GuiCompat26.add(this, Button.builder(Component.literal("§c◀ Back to Classic GUI"), b -> {
                useModernGui = false;
                if (Minecraft.getInstance() != null) Minecraft.getInstance().setScreenAndShow(new MenuScreen());
            }).bounds(5, 5, 150, 20).build());

            curY = new int[]{20, 20, 20, 20};

            // Combat
            addMod(0, "KillAura", auraOn, v->auraOn=v, () -> {
                addS(0, "Range", 1f, 20f, auraRange, v->auraRange=v);
                addC(0, "Mode", AURA_MODES, auraMode, v->auraMode=v);
                addC(0, "Target", AURA_TARGETS, auraTargetMode, v->auraTargetMode=v);
                addC(0, "Rotation", AURA_ROTS, auraRotMode, v->auraRotMode=v);
                addC(0, "Timing", AURA_TIMINGS, auraTimingMode, v->auraTimingMode=v);
                addC(0, "Aim Part", AURA_PARTS, auraTargetPart, v->auraTargetPart=v);
                addS(0, "Aim Jitter", 0f, 1f, auraAimJitter, v->auraAimJitter=v);
                addS(0, "Stickiness", 0f, 100f, auraStickiness, v->auraStickiness=v);
                addS(0, "Rot Curve", 0f, 100f, auraRotCurve, v->auraRotCurve=v);
                addS(0, "Rot Speed", 1f, 180f, auraRotSpeed, v->auraRotSpeed=v);
                addS(0, "FOV", 10f, 360f, auraFov, v->auraFov=v);
                addB(0, "Predict", auraPredict, v->auraPredict=v);
                addB(0, "Randomize", auraRandomize, v->auraRandomize=v);
                addC(0, "Bypass", BYPASS_NAMES, auraBypass, v->auraBypass=v);
                addB(0, "Target Players", auraTargetPlayers, v->auraTargetPlayers=v);
                addB(0, "Target Mobs", auraTargetMobs, v->auraTargetMobs=v);
                addB(0, "Target Animals", auraTargetAnimals, v->auraTargetAnimals=v);
                addB(0, "AutoWeapon", autoWeapon, v->autoWeapon=v);
                addB(0, "Criticals", criticals, v->criticals=v);
                addB(0, "Shield Breaker", shieldBreaker, v->shieldBreaker=v);
                addB(0, "Water Crits", waterCrits, v->waterCrits=v);
                addB(0, "Jump & Attack", auraJump, v->auraJump=v);
                addB(0, "Through Walls", auraThroughWalls, v->auraThroughWalls=v);
                addB(0, "Hit in GUIs", auraHitInGuis, v->auraHitInGuis=v);
                addB(0, "AntiBot", antiBotOn, v->antiBotOn=v);
                addB(0, "SpinBot (Idle)", auraSpinBot, v->auraSpinBot=v);
                addBind(0, "Bind", 1);
            });
            addMod(0, "AutoClicker", autoClickerOn, v->autoClickerOn=v, () -> {
                addS(0, "CPS", 1f, 50f, clickerCps, v->clickerCps=v);
                addB(0, "Right Click", autoClickerRight, v->autoClickerRight=v);
                addB(0, "Farm Mode", autoClickerFarm, v->autoClickerFarm=v);
            });
            addMod(0, "TriggerBot", triggerBotOn, v->triggerBotOn=v, () -> {
                addS(0, "CPS", 1f, 50f, triggerCps, v->triggerCps=v);
                addS(0, "Range", 1f, 12f, triggerRange, v->triggerRange=v);
                addS(0, "Cooldown", 0f, 1f, triggerCooldown, v->triggerCooldown=v);
                addS(0, "Jitter %", 0f, 100f, triggerJitter, v->triggerJitter=v);
                addS(0, "Scan FOV", 1f, 180f, triggerFov, v->triggerFov=v);
                addB(0, "Weapon Only", triggerWeaponOnly, v->triggerWeaponOnly=v);
                addB(0, "Smart Delay", triggerSmartDelay, v->triggerSmartDelay=v);
                addB(0, "Wait Hurt Time", triggerWaitHurtTime, v->triggerWaitHurtTime=v);
                addB(0, "Through Walls", triggerThroughWalls, v->triggerThroughWalls=v);
                addB(0, "Auto Weapon", triggerAutoWeapon, v->triggerAutoWeapon=v);
                addB(0, "Criticals", triggerCriticals, v->triggerCriticals=v);
                addB(0, "Target Players", triggerTargetPlayers, v->triggerTargetPlayers=v);
                addB(0, "Target Mobs", triggerTargetMobs, v->triggerTargetMobs=v);
                addB(0, "Target Animals", triggerTargetAnimals, v->triggerTargetAnimals=v);
            });
            addMod(0, "AutoTotem", autoTotemOn, v->autoTotemOn=v, () -> {
                addS(0, "Health", 1f, 20f, autoTotemHealth, v->autoTotemHealth=v);
                addC(0, "Mode", TOTEM_MODES, autoTotemMode, v->autoTotemMode=v);
            });
            addMod(0, "AutoArmor", autoArmorOn, v->autoArmorOn=v, null);
            addMod(0, "FastBow", fastBowOn, v->fastBowOn=v, () -> {
                addB(0, "BowJump", bowJump, v->bowJump=v);
            });
            addMod(0, "AimAssist", aimOn, v->aimOn=v, () -> {
                addS(0, "Smooth Speed", 1f, 100f, aimSpeed, v->aimSpeed=v);
            });
            addMod(0, "AimLock", aimLockOn, v->aimLockOn=v, null);
            addMod(0, "Hitbox", hitboxOn, v->hitboxOn=v, () -> {
                addS(0, "Size", 0.1f, 1000f, hitboxVal, v->hitboxVal=v);
            });
            addMod(0, "AntiBot", antiBotOn, v->antiBotOn=v, null);

            // Movement
            addMod(1, "Speed", speedOn, v->speedOn=v, () -> {
                addS(1, "Speed", 0.1f, 100f, speedVal, v->speedVal=v);
                addC(1, "Bypass", BYPASS_NAMES, speedBypass, v->speedBypass=v);
            });
            addMod(1, "Fly", flyOn, v->flyOn=v, () -> {
                addS(1, "Speed", 0.1f, 50f, flySpeed, v->flySpeed=v);
                addC(1, "Bypass", BYPASS_NAMES, flyBypass, v->flyBypass=v);
            });
            addMod(1, "Spider", spiderOn, v->spiderOn=v, () -> {
                addC(1, "Mode", SPIDER_MODES, spiderMode, v->spiderMode=v);
            });
            addMod(1, "NoWeb", noWebOn, v->noWebOn=v, () -> {
                addC(1, "Mode", NOWEB_MODES, noWebMode, v->noWebMode=v);
            });
            addMod(1, "Freeze", freezeOn, v->freezeOn=v, () -> {
                addC(1, "Mode", FREEZE_MODES, freezeMode, v->freezeMode=v);
                addBind(1, "Bind", 20);
            });
            addMod(1, "AirJump", airJumpOn, v->airJumpOn=v, () -> {
                addC(1, "Mode", AIRJUMP_MODES, airJumpMode, v->airJumpMode=v);
                addBind(1, "Bind", 25);
            });
            addMod(1, "NoFall", noFallOn, v->noFallOn=v, () -> {
                addC(1, "Mode", NOFALL_MODES, noFallMode, v->noFallMode=v);
                addBind(1, "Bind", 26);
            });
            addMod(1, "Jesus", jesusOn, v->jesusOn=v, () -> {
                addC(1, "Mode", JESUS_MODES, jesusMode, v->jesusMode=v);
                addBind(1, "Bind", 27);
            });
            addMod(1, "Noclip", noclipOn, v->noclipOn=v, () -> {
                addC(1, "Mode", NOCLIP_MODES, noclipBypass, v->noclipBypass=v);
                addBind(1, "Bind", 11);
            });
            addMod(1, "Velocity", velocityOn, v->velocityOn=v, () -> {
                addC(1, "Mode", VELOCITY_MODES, velocityMode, v->velocityMode=v);
            });
            addMod(1, "Strafe", strafeOn, v->strafeOn=v, null);
            addMod(1, "Anti-Flag", antiFlagOn, v->antiFlagOn=v, null);

            // Visuals
            addMod(2, "XRay", xrayOn, v->{xrayOn=v; if(Minecraft.getInstance()!=null)Minecraft.getInstance().levelRenderer.resetLevelRenderData();}, () -> {
                GuiCompat26.add(this, Button.builder(Component.literal("Select Blocks..."), b -> {
                    if(Minecraft.getInstance()!=null) Minecraft.getInstance().setScreenAndShow(new XrayScreen(this));
                }).bounds(cX[2] + 5, cY[2] + curY[2], 140, 20).build());
                curY[2] += 22;
            });
            addMod(2, "Glowing ESP", visualsOn, v->visualsOn=v, () -> {
                addC(2, "Target", VISUALS_TARGETS, visualsTargetMode, v->visualsTargetMode=v);
                addBind(2, "Bind", 8);
            });
            addMod(2, "2D ESP", espOn, v->espOn=v, () -> {
                addS(2, "Range", 5f, 256f, espRange, v->espRange=v);
                addB(2, "Boxes", espBoxesOn, v->espBoxesOn=v);
                addB(2, "Names", espNamesOn, v->espNamesOn=v);
                addB(2, "Health", espHealthOn, v->espHealthOn=v);
                addB(2, "Distance", espDistanceOn, v->espDistanceOn=v);
                addB(2, "Fill", espFillOn, v->espFillOn=v);
                addB(2, "Tracers", espTracersOn, v->espTracersOn=v);
                addB(2, "Players", espPlayersOn, v->espPlayersOn=v);
                addB(2, "Mobs", espMobsOn, v->espMobsOn=v);
                addB(2, "Animals", espAnimalsOn, v->espAnimalsOn=v);
                addB(2, "Items", espItemsOn, v->espItemsOn=v);
                addBind(2, "Bind", 28);
            });
            addMod(2, "Target HUD", targetHudOn, v->targetHudOn=v, null);
            addMod(2, "Player ESP", playerEspOn, v->playerEspOn=v, null);
            addMod(2, "FullBright", fullBrightOn, v->fullBrightOn=v, null);
            addMod(2, "NameHider", nameHiderOn, v->nameHiderOn=v, null);
            addMod(2, "See Invis", seeInvisOn, v->seeInvisOn=v, null);
            addMod(2, "Target ESP", targetEspOn, v->targetEspOn=v, null);
            addMod(2, "No Fire", noFireOn, v->noFireOn=v, null);
            addMod(2, "No Nausea", noNauseaOn, v->noNauseaOn=v, null);
            addMod(2, "NoHurtCam", noHurtCamOn, v->noHurtCamOn=v, null);

            // Misc
            addMod(3, "Freecam", freecamOn, v->{
                freecamOn=v;
                if (Minecraft.getInstance() != null && Minecraft.getInstance().player != null) {
                    if (freecamOn) {
                        freecamPos = Compat.entityPos(Minecraft.getInstance().player);
                        freecamYaw = Minecraft.getInstance().player.getYRot();
                        freecamPitch = Minecraft.getInstance().player.getXRot();
                    } else {
                        Minecraft.getInstance().player.noPhysics = false;
                        Minecraft.getInstance().player.getAbilities().flying = false;
                        if (freecamPos != null) {
                            Minecraft.getInstance().player.setPos(freecamPos);
                            Minecraft.getInstance().player.setYRot(freecamYaw);
                            Minecraft.getInstance().player.setXRot(freecamPitch);
                            Minecraft.getInstance().player.setDeltaMovement(0, 0, 0);
                        }
                    }
                }
            }, null);
            addMod(3, "GodMode", godModeOn, v->godModeOn=v, () -> {
                addC(3, "Mode", GODMODE_MODES, godModeMode, v->godModeMode=v);
                addBind(3, "Bind", 22);
            });
            addMod(3, "Server Crasher", serverCrasherOn, v->serverCrasherOn=v, () -> {
                addC(3, "Mode", CRASHER_MODES, crasherMode, v->crasherMode=v);
                addC(3, "Timer", CRASHER_TIMERS, crasherTimerMode, v->crasherTimerMode=v);
            });
            GuiCompat26.add(this, Button.builder(Component.literal("Drop All Items"), b -> { dropAllItems = true; }).bounds(cX[3], cY[3] + curY[3], 150, 20).build()); curY[3]+=22;
            addMod(3, "Panic", panicOn, v->panicOn=v, null);
            GuiCompat26.add(this, Button.builder(Component.literal("\u00a5 Advanced Features"), b -> {
                Minecraft.getInstance().setScreenAndShow(new PypsenFeatures.FeaturesScreen(this));
            }).bounds(cX[3], cY[3] + curY[3], 150, 20).build()); curY[3] += 22;
        }

        private void addMod(int col, String name, boolean val, java.util.function.Consumer<Boolean> act, Runnable settings) {
            int x = cX[col];
            int y = cY[col] + curY[col];
            int w = settings != null ? 130 : 150;
            GuiCompat26.add(this, Button.builder(Component.literal(name + ": " + (val?"§aON":"§cOFF")), b -> { act.accept(!val); rebuild(); }).bounds(x, y, w, 20).build());
            if (settings != null) {
                boolean isExp = expanded.contains(name);
                GuiCompat26.add(this, Button.builder(Component.literal(isExp ? "-" : "+"), b -> {
                    if (isExp) expanded.remove(name); else expanded.add(name);
                    rebuild();
                }).bounds(x + 130, y, 20, 20).build());
                curY[col] += 22;
                if (isExp) {
                    settings.run();
                }
            } else {
                curY[col] += 22;
            }
        }

        private void addS(int col, String label, float min, float max, float val, java.util.function.Consumer<Float> setter) {
            GuiCompat26.add(this, slider(cX[col] + 5, cY[col] + curY[col], 140, label, min, max, val, v -> setter.accept(v)));
            curY[col] += 22;
        }

        private void addC(int col, String label, String[] options, int current, java.util.function.Consumer<Integer> setter) {
            GuiCompat26.add(this, Button.builder(Component.literal(label + ": §b" + options[current]), b -> { setter.accept((current + 1) % options.length); rebuild(); }).bounds(cX[col] + 5, cY[col] + curY[col], 140, 20).build());
            curY[col] += 22;
        }

        private void addB(int col, String label, boolean val, java.util.function.Consumer<Boolean> act) {
            GuiCompat26.add(this, Button.builder(Component.literal(label + ": " + (val?"§aON":"§cOFF")), b -> { act.accept(!val); rebuild(); }).bounds(cX[col] + 5, cY[col] + curY[col], 140, 20).build());
            curY[col] += 22;
        }

        private int getKeyCode(int id) {
            return switch(id) {
                case 0 -> keySpeed; case 1 -> keyAura; case 2 -> keyHitbox; case 3 -> keyFly;
                case 4 -> keyXray; case 5 -> keyVelocity; case 6 -> keyAim; case 7 -> keyStrafe;
                case 8 -> keyVisuals; case 9 -> keyMenu; case 10 -> keyAutoClicker; case 11 -> keyNoclip;
                case 12 -> keyAntiFlag; case 13 -> keyTriggerBot; case 14 -> keyPanic; case 15 -> keyFreecam;
                case 16 -> keyAutoTotem; case 17 -> keyAimLock; case 18 -> keySpider; case 19 -> keyNoWeb;
                case 20 -> keyFreeze; case 21 -> keyCrasher; case 22 -> keyGodMode; case 23 -> keyAutoArmor;
                case 24 -> keyFastBow; case 25 -> keyAirJump; case 26 -> keyNoFall; case 27 -> keyJesus;
                case 28 -> keyEsp;
                default -> GlfwCompat.GLFW_KEY_UNKNOWN;
            };
        }

        private void addBind(int col, String label, int keyId) {
            int currentKey = getKeyCode(keyId);
            String text = (bindingTarget == keyId) ? label + ": §e[...]" : label + ": §f" + keyName(currentKey);
            GuiCompat26.add(this, Button.builder(Component.literal(text), b -> { bindingTarget = keyId; rebuild(); }).bounds(cX[col] + 5, cY[col] + curY[col], 140, 20).build());
            curY[col] += 22;
        }

        @Override
        public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent click, boolean doubled) {
            double mx = click.x(); double my = click.y(); int button = click.button();
            if (bindingTarget != -1) {
                if (button == 2) { // Middle click to unbind
                    switch (bindingTarget) {
                        case 0 -> keySpeed = GlfwCompat.GLFW_KEY_UNKNOWN; case 1 -> keyAura = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 2 -> keyHitbox = GlfwCompat.GLFW_KEY_UNKNOWN; case 3 -> keyFly = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 4 -> keyXray = GlfwCompat.GLFW_KEY_UNKNOWN; case 5 -> keyVelocity = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 6 -> keyAim = GlfwCompat.GLFW_KEY_UNKNOWN; case 7 -> keyStrafe = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 8 -> keyVisuals = GlfwCompat.GLFW_KEY_UNKNOWN; case 9 -> keyMenu = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 10 -> keyAutoClicker = GlfwCompat.GLFW_KEY_UNKNOWN; case 11 -> keyNoclip = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 12 -> keyAntiFlag = GlfwCompat.GLFW_KEY_UNKNOWN; case 13 -> keyTriggerBot = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 14 -> keyPanic = GlfwCompat.GLFW_KEY_UNKNOWN; case 15 -> keyFreecam = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 16 -> keyAutoTotem = GlfwCompat.GLFW_KEY_UNKNOWN; case 17 -> keyAimLock = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 18 -> keySpider = GlfwCompat.GLFW_KEY_UNKNOWN; case 19 -> keyNoWeb = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 20 -> keyFreeze = GlfwCompat.GLFW_KEY_UNKNOWN; case 21 -> keyCrasher = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 22 -> keyGodMode = GlfwCompat.GLFW_KEY_UNKNOWN; case 23 -> keyAutoArmor = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 24 -> keyFastBow = GlfwCompat.GLFW_KEY_UNKNOWN; case 25 -> keyAirJump = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 26 -> keyNoFall = GlfwCompat.GLFW_KEY_UNKNOWN; case 27 -> keyJesus = GlfwCompat.GLFW_KEY_UNKNOWN;
                        case 28 -> keyEsp = GlfwCompat.GLFW_KEY_UNKNOWN;
                    }
                    bindingTarget = -1;
                    rebuild();
                    return true;
                }
            }
            for (int i = 0; i < 4; i++) {
                if (mx >= cX[i] && mx <= cX[i] + 150 && my >= cY[i] && my <= cY[i] + 20) {
                    dragging = i;
                    dragX = (int)mx - cX[i];
                    dragY = (int)my - cY[i];
                    return true;
                }
            }
            return super.mouseClicked(click, doubled);
        }

        @Override
        public boolean mouseDragged(net.minecraft.client.input.MouseButtonEvent click, double dx, double dy) {
            double mx = click.x(); double my = click.y(); int button = click.button();
            if (dragging >= 0) {
                cX[dragging] = (int)mx - dragX;
                cY[dragging] = (int)my - dragY;
                rebuild();
                return true;
            }
            return super.mouseDragged(click, dx, dy);
        }

        @Override
        public boolean mouseReleased(net.minecraft.client.input.MouseButtonEvent click) {
            double mx = click.x(); double my = click.y(); int button = click.button();
            dragging = -1;
            return super.mouseReleased(click);
        }

        @Override
        public boolean keyPressed(net.minecraft.client.input.KeyEvent input) {
            int keyCode = input.key(); int scanCode = 0; int modifiers = input.modifiers();
            if (bindingTarget != -1) {
                if (keyCode == GlfwCompat.GLFW_KEY_ESCAPE) {
                    bindingTarget = -1;
                    rebuild();
                    return true;
                }
                switch (bindingTarget) {
                    case 0 -> keySpeed = keyCode; case 1 -> keyAura = keyCode;
                    case 2 -> keyHitbox = keyCode; case 3 -> keyFly = keyCode;
                    case 4 -> keyXray = keyCode; case 5 -> keyVelocity = keyCode;
                    case 6 -> keyAim = keyCode; case 7 -> keyStrafe = keyCode;
                    case 8 -> keyVisuals = keyCode; case 9 -> keyMenu = keyCode;
                    case 10 -> keyAutoClicker = keyCode; case 11 -> keyNoclip = keyCode;
                    case 12 -> keyAntiFlag = keyCode; case 13 -> keyTriggerBot = keyCode;
                    case 14 -> keyPanic = keyCode; case 15 -> keyFreecam = keyCode;
                    case 16 -> keyAutoTotem = keyCode; case 17 -> keyAimLock = keyCode;
                    case 18 -> keySpider = keyCode; case 19 -> keyNoWeb = keyCode;
                    case 20 -> keyFreeze = keyCode; case 21 -> keyCrasher = keyCode;
                    case 22 -> keyGodMode = keyCode; case 23 -> keyAutoArmor = keyCode;
                    case 24 -> keyFastBow = keyCode; case 25 -> keyAirJump = keyCode;
                    case 26 -> keyNoFall = keyCode; case 27 -> keyJesus = keyCode;
                    case 28 -> keyEsp = keyCode;
                }
                bindingTarget = -1;
                rebuild();
                return true;
            }
            return super.keyPressed(input);
        }

        @Override
        public void extractRenderState(GuiGraphicsExtractor rawCtx, int mx, int my, float d) {
            DrawContext26 ctx = new DrawContext26(rawCtx);
            String[] titles = {"§c⚔ Combat", "§b✈ Movement", "§d✨ Visuals", "§7⚙ Misc"};
            for (int i = 0; i < 4; i++) {
                ctx.fill(cX[i], cY[i], cX[i] + 150, cY[i] + 20, 0xFF222222); // Header
                ctx.fill(cX[i], cY[i] + 20, cX[i] + 150, cY[i] + curY[i] + 4, 0xAA000000); // Body
                ctx.drawTextWithShadow(font, Component.literal(titles[i]), cX[i] + 5, cY[i] + 6, 0xFFFFFF);
            }
            super.extractRenderState(rawCtx, mx, my, d);
        }

        @Override public boolean isPauseScreen() { return false; }
        private void rebuild() { GuiCompat26.clear(this); init(); }
    }

    private static AbstractSliderButton slider(int x, int y, int w, String label, float min, float max, float cur, java.util.function.Consumer<Float> cb) {
        return new AbstractSliderButton(x, y, w, 20, Component.literal(String.format("%s: %.1f", label, cur)), (cur - min) / (max - min)) {
            @Override protected void updateMessage() { setMessage(Component.literal(String.format("%s: %.1f", label, min + value * (max - min)))); }
            @Override protected void applyValue() { cb.accept((float)(min + value * (max - min))); }
        };
    }
}
