package pypsen.client.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import pypsen.client.PypsenClient;

@Mixin(ChatComponent.class)
public class ChatHudMixin {
    @ModifyVariable(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/multiplayer/chat/GuiMessageSource;Lnet/minecraft/client/multiplayer/chat/GuiMessageTag;)V", at = @At("HEAD"), ordinal = 0, argsOnly = true)
    private Component modifyChatMessage(Component message) {
        if (PypsenClient.nameHiderOn && message != null && Minecraft.getInstance().getUser() != null) {
            String myName = Minecraft.getInstance().getUser().getName();
            String str = message.getString();
            if (str.contains(myName)) {
                return Component.literal(str.replace(myName, PypsenClient.fakeName));
            }
        }
        return message;
    }
}
