package pypsen.client.mixin;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pypsen.client.PypsenClient;

@Mixin(Entity.class)
public class EntityMixin {

    @Inject(method = "getPickRadius", at = @At("RETURN"), cancellable = true)
    private void pypsen$hitbox(CallbackInfoReturnable<Float> cir) {
        if (PypsenClient.hitboxOn && (Object) this instanceof LivingEntity && !((Object) this instanceof LocalPlayer)) {
            cir.setReturnValue(PypsenClient.hitboxVal);
        }
    }

    @Inject(method = "getDimensions", at = @At("RETURN"), cancellable = true)
    private void pypsen$getDimensions(Pose pose, CallbackInfoReturnable<EntityDimensions> cir) {
        if (PypsenClient.hitboxOn && (Object) this instanceof LivingEntity && !((Object) this instanceof LocalPlayer)) {
            cir.setReturnValue(cir.getReturnValue().scale(PypsenClient.hitboxVal));
        }
    }

    @Inject(method = "push", at = @At("HEAD"), cancellable = true)
    private void pypsen$pushAwayFrom(Entity entity, CallbackInfo ci) {
        if (PypsenClient.velocityOn && (Object) this instanceof LocalPlayer) {
            ci.cancel();
        }
    }

    @Inject(method = "isInvisibleTo", at = @At("HEAD"), cancellable = true)
    private void pypsen$isInvisibleTo(Player player, CallbackInfoReturnable<Boolean> cir) {
        if (PypsenClient.seeInvisOn) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "makeStuckInBlock", at = @At("HEAD"), cancellable = true)
    private void pypsen$slowMovement(net.minecraft.world.level.block.state.BlockState state, net.minecraft.world.phys.Vec3 multiplier, CallbackInfo ci) {
        if (PypsenClient.noWebOn && (Object) this instanceof LocalPlayer) {
            if (PypsenClient.noWebMode == 0 || PypsenClient.noWebMode == 1) {
                ci.cancel();
            } else if (PypsenClient.noWebMode == 2) {
                // Grim: just reduce the effect slightly, handled in tick if needed, or just cancel here
                ci.cancel();
            }
        }
    }
}

