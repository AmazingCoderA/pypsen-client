package pypsen.client.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundExplodePacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pypsen.client.PypsenClient;

@Mixin(ClientPacketListener.class)
public class NetworkMixin {

    @Inject(method = "handleSetEntityMotion", at = @At("HEAD"), cancellable = true)
    private void pypsen$onVelocity(ClientboundSetEntityMotionPacket packet, CallbackInfo ci) {
        if (PypsenClient.velocityOn && Minecraft.getInstance().player != null) {
            if (packet.id() == Minecraft.getInstance().player.getId()) {
                ci.cancel();
            }
        }
    }

    @Inject(method = "handleExplosion", at = @At("HEAD"), cancellable = true)
    private void pypsen$onExplosion(ClientboundExplodePacket packet, CallbackInfo ci) {
        if (PypsenClient.velocityOn) {
            // Отменяем отталкивание от взрывов
            ci.cancel();
        }
    }
}
