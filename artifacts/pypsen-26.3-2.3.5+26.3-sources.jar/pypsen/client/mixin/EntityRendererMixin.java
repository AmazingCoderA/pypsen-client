package pypsen.client.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pypsen.client.PypsenClient;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin<T extends Entity> {
    @Inject(method = "getNameTag", at = @At("HEAD"), cancellable = true)
    private void onHasLabel(T entity, CallbackInfoReturnable<Component> cir) {
        if (PypsenClient.playerEspOn && entity instanceof Player) {
            cir.setReturnValue(Component.literal(""));
        }
    }

    @Inject(method = "getNameTag", at = @At("RETURN"), cancellable = true)
    private void modifyLabel(T entity, CallbackInfoReturnable<Component> cir) {
        Component text = cir.getReturnValue();
        if (PypsenClient.nameHiderOn && text != null && Minecraft.getInstance().getUser() != null) {
            String myName = Minecraft.getInstance().getUser().getName();
            String str = text.getString();
            if (str.contains(myName)) {
                cir.setReturnValue(Component.literal(str.replace(myName, PypsenClient.fakeName)));
                return;
            }
        }
        if (PypsenClient.playerEspOn && entity instanceof Player && text == null) {
            cir.setReturnValue(Component.literal(""));
        }
    }
}
