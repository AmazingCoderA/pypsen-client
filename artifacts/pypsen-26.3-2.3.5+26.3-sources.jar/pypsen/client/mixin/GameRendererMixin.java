package pypsen.client.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pypsen.client.PypsenClient;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "bobHurt", at = @At("HEAD"), cancellable = true)
    private void onTiltViewWhenHurt(net.minecraft.client.renderer.state.level.CameraRenderState state, PoseStack matrices, CallbackInfo ci) {
        if (PypsenClient.noHurtCamOn) {
            ci.cancel();
        }
    }
}
