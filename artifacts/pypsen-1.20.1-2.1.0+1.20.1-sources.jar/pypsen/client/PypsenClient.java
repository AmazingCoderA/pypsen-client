package pypsen.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_357;
import net.minecraft.class_3959;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7923;
import org.lwjgl.glfw.GLFW;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.util.*;

public class PypsenClient implements ClientModInitializer {

    // ══════════ TOGGLES ══════════
    public static boolean speedOn = false, auraOn = false, hitboxOn = false, flyOn = false;
    public static boolean xrayOn = false, velocityOn = false, aimOn = false, visualsOn = false;
    public static boolean strafeOn = false, noclipOn = false, antiFlagOn = false, autoClickerOn = false;
    public static boolean hudOn = true, triggerBotOn = false, targetHudOn = true, panicOn = false;
    public static boolean freecamOn = false, playerEspOn = false, auraSpinBot = false;
    public static boolean triggerWeaponOnly = false, autoTotemOn = false, aimLockOn = false;
    public static boolean antiBotOn = true, fullBrightOn = false, nameHiderOn = false;
    public static boolean spiderOn = false, noWebOn = false, freezeOn = false, useModernGui = false;
    public static boolean serverCrasherOn = false, godModeOn = false, autoArmorOn = false, fastBowOn = false;
    public static boolean bowJump = false, auraPredict = true, auraRandomize = true, dropAllItems = false;
    public static boolean jesusOn = false;

    // ══════════ VISUALS SUB-TOGGLES ══════════
    public static boolean seeInvisOn = false, noFireOn = false, noNauseaOn = false;
    public static boolean targetEspOn = false, noHurtCamOn = false;

    // ══════════ 2D ESP OVERLAY ══════════
    public static boolean espOn = false, espBoxesOn = true, espNamesOn = true, espHealthOn = true;
    public static boolean espDistanceOn = true, espItemsOn = false, espTracersOn = false, espFillOn = false;
    public static boolean espPlayersOn = true, espMobsOn = true, espAnimalsOn = false;
    public static float espRange = 64f;

    // ══════════ KILLAURA ADVANCED ══════════
    public static boolean auraJump = false, auraThroughWalls = true, auraHitInGuis = true;
    public static boolean autoWeapon = false, criticals = false, shieldBreaker = false, waterCrits = false;
    public static boolean auraRayCast = true;
    public static boolean auraTargetPlayers = true, auraTargetMobs = false, auraTargetAnimals = false;

    // ══════════ TRIGGERBOT ADVANCED ══════════
    public static boolean triggerThroughWalls = false, triggerSmartDelay = true;
    public static boolean triggerTargetPlayers = true, triggerTargetMobs = false, triggerTargetAnimals = false;
    public static boolean triggerAutoWeapon = false, triggerCriticals = false, triggerWaitHurtTime = true;
    public static float triggerCooldown = 0.95f, triggerJitter = 10f, triggerFov = 30f;

    // ══════════ VALUES ══════════
    public static float speedVal = 5f, auraRange = 6f, hitboxVal = 1f, flySpeed = 2f;
    public static float aimSpeed = 50f, clickerCps = 12f, triggerCps = 10f;
    public static float auraAimJitter = 0.0f, triggerRange = 3.0f;
    public static float auraStickiness = 0.0f, auraRotCurve = 0.0f, auraFov = 360f, auraRotSpeed = 180f;
    public static float autoTotemHealth = 20f;
    public static String fakeName = "Protected";

    // ══════════ MODES ══════════
    public static int auraMode = 0, auraTargetMode = 0, auraRotMode = 0;
    public static int auraTimingMode = 0, auraTargetPart = 1, visualsTargetMode = 0;
    public static int autoTotemMode = 0;
    public static int spiderMode = 0, noWebMode = 0, freezeMode = 0, crasherMode = 0, crasherTimerMode = 0;
    public static boolean airJumpOn = false, noFallOn = false;
    public static int airJumpMode = 0, noFallMode = 0, velocityMode = 0, jesusMode = 0, visualsParticles = 0;
    public static final String[] AIRJUMP_MODES = {"Vanilla", "GhostBlock", "Packet"};
    public static final String[] NOFALL_MODES = {"Packet", "WaterBucket", "Web", "Vulcan", "Grim", "LiquidBounce", "Matrix", "NCP"};
    public static final String[] VELOCITY_MODES = {"Cancel", "Matrix", "Grim", "LiquidBounce", "AAC"};
    public static final String[] JESUS_MODES = {"Solid", "Bounce", "LiquidBounce", "Matrix"};
    public static final String[] PARTICLES_MODES = {"None", "Heart", "Flame", "Magic", "LiquidBounce"};
    public static final String[] AURA_MODES = {"1.9 (Strict Cooldown)", "1.8 (Spam)", "Adaptive"};
    public static final String[] AURA_TARGETS = {"Distance", "Health", "Armor", "Angle"};
    public static final String[] AURA_ROTS = {"None", "Snap", "Smooth", "Silent", "Matrix", "Predict", "Smart", "Legit", "HvH", "Derp", "Cinematic", "NCP", "AAC", "Sunrise", "Vulcan", "Intave", "Legit Smooth", "Looping", "LiquidBounce", "Custom", "Noise"};
    public static final String[] AURA_TIMINGS = {"All", "Fall (Crits)", "Jump (Crits)"};
    public static final String[] AURA_PARTS = {"Head", "Chest", "Legs", "Feet"};
    public static final String[] VISUALS_TARGETS = {"All", "Enemies", "Friends"};
    public static final String[] TOTEM_MODES = {"Instant", "Legit"};
    public static final String[] SPIDER_MODES = {"Vanilla", "Jump", "Grim", "GhostBlock"};
    public static final String[] NOWEB_MODES = {"Vanilla", "Fast", "Grim", "Intave", "EdgeTP"};
    public static final String[] FREEZE_MODES = {"Vanilla", "Packet", "Intave", "GhostBlock", "LiquidBounce"};
    public static final String[] CRASHER_MODES = {"Position", "Swing", "Interact", "MathBreaker", "BrandPayload", "SettingsExploit", "TabComplete"};
    public static final String[] CRASHER_TIMERS = {"Infinite", "5s", "10s", "Auto-Disable"};
    public static final String[] GODMODE_MODES = {"Vanilla", "Packet", "Vulcan", "LiquidBounce"};
    public static int godModeMode = 0;

    public static int speedBypass = 0, auraBypass = 0, flyBypass = 0, noclipBypass = 0;
    public static final String[] BYPASS_NAMES = {"None", "Vanilla", "Timer", "Strafe", "NCP", "Matrix", "Grim", "Funtime", "ReallyWorld", "Vulcan", "Spartan", "Grim AC", "Polar AC", "Intave"};
    public static final String[] NOCLIP_MODES = {"Vanilla", "VClip", "HClip", "Packet"};

    // ══════════ KEYBINDS ══════════
    public static int keyMenu = GLFW.GLFW_KEY_MINUS, keySpeed = GLFW.GLFW_KEY_V, keyAura = GLFW.GLFW_KEY_R;
    public static int keyFly = GLFW.GLFW_KEY_G, keyXray = GLFW.GLFW_KEY_X, keyHitbox = GLFW.GLFW_KEY_H;
    public static int keyVelocity = GLFW.GLFW_KEY_UNKNOWN, keyAim = GLFW.GLFW_KEY_UNKNOWN;
    public static int keyVisuals = GLFW.GLFW_KEY_UNKNOWN, keyStrafe = GLFW.GLFW_KEY_UNKNOWN;
    public static int keyNoclip = GLFW.GLFW_KEY_UNKNOWN, keyAntiFlag = GLFW.GLFW_KEY_UNKNOWN;
    public static int keyAutoClicker = GLFW.GLFW_KEY_UNKNOWN, keyTriggerBot = GLFW.GLFW_KEY_UNKNOWN;
    public static int keyPanic = GLFW.GLFW_KEY_UNKNOWN, keyFreecam = GLFW.GLFW_KEY_UNKNOWN;
    public static int keyAutoTotem = GLFW.GLFW_KEY_UNKNOWN, keyAimLock = GLFW.GLFW_KEY_UNKNOWN;
    public static boolean autoClickerRight = false, autoClickerFarm = false;
    public static int keySpider = GLFW.GLFW_KEY_UNKNOWN, keyNoWeb = GLFW.GLFW_KEY_UNKNOWN, keyFreeze = GLFW.GLFW_KEY_UNKNOWN;
    public static int keyCrasher = GLFW.GLFW_KEY_UNKNOWN, keyGodMode = GLFW.GLFW_KEY_UNKNOWN, keyAutoArmor = GLFW.GLFW_KEY_UNKNOWN, keyFastBow = GLFW.GLFW_KEY_UNKNOWN;
    public static int keyAirJump = GLFW.GLFW_KEY_UNKNOWN, keyNoFall = GLFW.GLFW_KEY_UNKNOWN, keyJesus = GLFW.GLFW_KEY_UNKNOWN;
    public static int keyEsp = GLFW.GLFW_KEY_UNKNOWN;

    public static final Set<String> friends = new HashSet<>();
    private static boolean middleClickWasDown = false;
    private static boolean wasFullBright = false;
    private static class_243 freecamPos = null;
    private static float freecamYaw = 0, freecamPitch = 0;
    private static int totemTimer = 0, totemStep = 0, totemTargetSlot = -1;
    private static long lastTimeUpdate = 0;
    private static long crasherStartTime = 0;
    private static float currentTps = 20.0f;

    public static final Set<class_2248> XRAY_BLOCKS = new HashSet<>(Arrays.asList(
            class_2246.field_10442, class_2246.field_29029, class_2246.field_10212, class_2246.field_29027,
            class_2246.field_10571, class_2246.field_29026, class_2246.field_10013, class_2246.field_29220,
            class_2246.field_10090, class_2246.field_29028, class_2246.field_10080, class_2246.field_29030,
            class_2246.field_10418, class_2246.field_29219, class_2246.field_27120, class_2246.field_29221,
            class_2246.field_22109, class_2246.field_23077, class_2246.field_10034, class_2246.field_10443, class_2246.field_10260
    ));

    private static int auraTick = 0, clickTimer = 0, triggerTimer = 0;
    private static float triggerFloatTimer = 0f;
    private static boolean xrayWasOn = false, visualsWasOn = false;
    private static class_1309 currentTarget = null;

    public static class_1309 getAuraTarget() {
        return currentTarget;
    }

    // Smooth rotation targets
    private static float targetYaw = 0f;
    private static float targetPitch = 0f;
    private static boolean isRotating = false;

    @Override
    public void onInitializeClient() {
        loadConfig();
        PypsenFeatures.clamp();
        PypsenFeatures.init(class_310.method_1551());

        HudRenderCallback.EVENT.register((ctx, tickDelta) -> {
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 == null || panicOn) return;

            // ── MAIN HUD ──
            if (hudOn && PypsenFeatures.hudVisible()) {
                List<String> lines = new ArrayList<>();
                lines.add("\u00a7a\u00a7lPypsen v2 \u00a77[PRO]");
                if (speedOn)       lines.add("\u00a7bSpeed \u00a77" + String.format("%.1f", speedVal) + " [" + BYPASS_NAMES[speedBypass] + "]");
                if (auraOn)        lines.add("\u00a7cKillAura \u00a77" + String.format("%.1f", auraRange) + " [" + BYPASS_NAMES[auraBypass] + "]");
                if (hitboxOn)      lines.add("\u00a7eHitbox \u00a77" + String.format("%.1f", hitboxVal));
                if (flyOn)         lines.add("\u00a7dFly \u00a77" + String.format("%.1f", flySpeed) + " [" + BYPASS_NAMES[flyBypass] + "]");
                if (xrayOn)        lines.add("\u00a76XRay");
                if (velocityOn)    lines.add("\u00a79Velocity");
                if (aimOn)         lines.add("\u00a75AimAssist");
                if (visualsOn)     lines.add("\u00a7aVisuals");
                if (strafeOn)      lines.add("\u00a73Strafe");
                if (noclipOn)      lines.add("\u00a78Noclip");
                if (antiFlagOn)    lines.add("\u00a7eAnti-Flag");
                if (freecamOn)     lines.add("\u00a7bFreeCam");
                if (autoTotemOn)   lines.add("\u00a76AutoTotem");
                if (aimLockOn)     lines.add("\u00a75AimLock");
                if (antiBotOn)     lines.add("\u00a7aAntiBot");
                if (spiderOn)      lines.add("\u00a72Spider");
                if (noWebOn)       lines.add("\u00a7fNoWeb");
                if (freezeOn)      lines.add("\u00a7bFreeze");
                if (airJumpOn)     lines.add("\u00a7bAirJump");
                if (noFallOn)      lines.add("\u00a7aNoFall");
                if (jesusOn)       lines.add("\u00a7bJesus");
                if (serverCrasherOn)lines.add("\u00a7cServer Crasher");
                if (godModeOn)     lines.add("\u00a7eGodMode");
                if (autoArmorOn)   lines.add("\u00a7bAutoArmor");
                if (fastBowOn)     lines.add("\u00a7aFastBow");
                if (fullBrightOn)  lines.add("\u00a7eFullBright");
                if (nameHiderOn)   lines.add("\u00a7dNameHider");
                if (autoClickerOn) lines.add("\u00a7cAutoClicker \u00a77" + String.format("%.1f", clickerCps) + (autoClickerRight ? " [RMB]" : " [LMB]"));
                if (triggerBotOn)  lines.add("\u00a7cTriggerBot \u00a77" + String.format("%.1f", triggerCps) + " \u00a78[" + String.format("%.0f", triggerJitter) + "% jit]");
                if (espOn)         lines.add("\u00a7b2D ESP \u00a77" + String.format("%.0fm", espRange));
                if (PypsenFeatures.aiAuraOn) lines.add("\u00a75AI Aura \u00a77" + String.format("%.0fm", PypsenFeatures.aiRange)
                    + " [" + PypsenFeatures.AI_PRESETS[class_3532.method_15340(PypsenFeatures.aiPreset, 0, PypsenFeatures.AI_PRESETS.length - 1)]
                    + "/" + PypsenFeatures.AI_TARGET_MODES[class_3532.method_15340(PypsenFeatures.aiTargetMode, 0, PypsenFeatures.AI_TARGET_MODES.length - 1)]
                    + "] \u00a78" + String.format("%.0f%%", PypsenFeatures.aiConfidence * 100f)
                    + " \u00a77s" + PypsenFeatures.sampleCount());
                if (PypsenFeatures.crystalAuraOn) lines.add("\u00a7cCrystal Aura \u00a77" + String.format("%.0fm", PypsenFeatures.crystalRange)
                    + " [" + PypsenFeatures.CRYSTAL_MODES[class_3532.method_15340(PypsenFeatures.crystalMode, 0, PypsenFeatures.CRYSTAL_MODES.length - 1)]
                    + "/" + PypsenFeatures.CRYSTAL_PLACE_MODES[class_3532.method_15340(PypsenFeatures.crystalPlaceMode, 0, PypsenFeatures.CRYSTAL_PLACE_MODES.length - 1)] + "]");
                if (PypsenFeatures.fakeLagOn) lines.add("\u00a78FakeLag \u00a77" + String.format("%.0fms", PypsenFeatures.fakeLagDelay));
                if (PypsenFeatures.autoEatOn) lines.add("\u00a7aAutoEat \u00a77" + String.format("%.0fHP", PypsenFeatures.autoEatHealth));
                if (PypsenFeatures.spiderProOn) lines.add("\u00a72Spider Pro");
                if (PypsenFeatures.noclipProOn) lines.add("\u00a78Noclip Pro");
                if (PypsenFeatures.stealthOn) lines.add("\u00a78Stealth \u00a77" + PypsenFeatures.STEALTH_MODES[class_3532.method_15340(PypsenFeatures.stealthMode, 0, PypsenFeatures.STEALTH_MODES.length - 1)]);
                if (PypsenFeatures.comboCounterOn && PypsenFeatures.comboCount() > 1) lines.add("\u00a7eCombo x" + PypsenFeatures.comboCount());
                if (PypsenFeatures.killFeedOn && PypsenFeatures.killCount() > 0) lines.add("\u00a7cKills \u00a77" + PypsenFeatures.killCount());

                // TPS & Ping
                lines.add("");
                lines.add("§7TPS: §f" + String.format("%.1f", currentTps));
                if (mc.method_1562() != null && mc.method_1562().method_2871(mc.field_1724.method_5667()) != null) {
                    lines.add("§7Ping: §f" + mc.method_1562().method_2871(mc.field_1724.method_5667()).method_2959() + "ms");
                }

                int y = 4;
                for (String s : lines) {
                    ctx.method_27535(mc.field_1772, class_2561.method_43470(s), 4, y, 0xFFFFFF);
                    y += 11;
                }
            }

            // ── TARGET HUD ──
            if (targetHudOn && PypsenFeatures.hudVisible() && currentTarget != null && currentTarget.method_5805() && mc.field_1724.method_5739(currentTarget) <= auraRange * 1.5) {
                int sw = mc.method_22683().method_4486();
                int sh = mc.method_22683().method_4502();
                int tx = sw / 2 + 20;
                int ty = sh / 2 + 20;

                ctx.method_25294(tx, ty, tx + 140, ty + 50, 0x90000000); // Background
                ctx.method_25294(tx, ty, tx + 140, ty + 2, 0xFF55FF55);  // Top border

                String name = PypsenFeatures.label(currentTarget.method_5477().getString(), "Player");
                float hp = currentTarget.method_6032();
                float maxHp = currentTarget.method_6063();
                int armor = currentTarget.method_6096();
                float dist = mc.field_1724.method_5739(currentTarget);

                ctx.method_27535(mc.field_1772, class_2561.method_43470("\u00a7l" + name), tx + 5, ty + 6, 0xFFFFFF);
                ctx.method_27535(mc.field_1772, class_2561.method_43470("\u00a7c\u2764 " + String.format("%.1f", hp)), tx + 5, ty + 18, 0xFFFFFF);
                ctx.method_27535(mc.field_1772, class_2561.method_43470("\u00a7b\u25A0 " + armor), tx + 50, ty + 18, 0xFFFFFF);
                ctx.method_27535(mc.field_1772, class_2561.method_43470("\u00a77" + String.format("%.1fm", dist)), tx + 95, ty + 18, 0xFFFFFF);

                int hpBarWidth = (int) ((hp / maxHp) * 130);
                ctx.method_25294(tx + 5, ty + 35, tx + 5 + 130, ty + 42, 0xFF333333);
                ctx.method_25294(tx + 5, ty + 35, tx + 5 + hpBarWidth, ty + 42, getHealthColor(hp, maxHp));
            }

            // ── 2D ESP OVERLAY ──
            drawEsp(ctx, mc, tickDelta);

            // ── ADVANCED TARGET VISUALS ──
            PypsenFeatures.render(ctx, mc);
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.field_1724 == null || mc.field_1687 == null) return;
            var p = mc.field_1724;
            long handle = mc.method_22683().method_4490();

            // ── NAMEHIDER (TAB & SCOREBOARD) ──
            if (nameHiderOn && mc.method_1562() != null) {
                for (net.minecraft.class_640 entry : mc.method_1562().method_2880()) {
                    if (entry.method_2966().getId().equals(p.method_5667())) {
                        entry.method_2962(class_2561.method_43470(fakeName));
                    }
                }
            }

            // ── TPS CALCULATION ──
            long now = System.currentTimeMillis();
            if (now - lastTimeUpdate > 1000) {
                if (mc.method_1562() != null && mc.method_1562().method_2871(p.method_5667()) != null) {
                    int ping = mc.method_1562().method_2871(p.method_5667()).method_2959();
                    // Simple approximation based on ping for visual effect if real TPS is unavailable
                    currentTps = 20.0f - (ping > 100 ? (ping / 1000.0f) : 0);
                    if (currentTps < 0) currentTps = 0;
                }
                lastTimeUpdate = now;
            }

            // ── PANIC KEY ──
            if (wasPressed(handle, keyPanic)) {
                panicOn = !panicOn;
                if (panicOn) {
                    speedOn = auraOn = hitboxOn = flyOn = xrayOn = velocityOn = aimOn = visualsOn = false;
                    strafeOn = noclipOn = antiFlagOn = autoClickerOn = triggerBotOn = freecamOn = playerEspOn = false;
                    autoTotemOn = aimLockOn = fullBrightOn = nameHiderOn = spiderOn = noWebOn = freezeOn = false;
                    jesusOn = false;
                    PypsenFeatures.panic();
                    mc.field_1769.method_3279();
                }
            }

            if (panicOn) return;

            // ── FRIENDS (MIDDLE CLICK) ──
            boolean middleClickDown = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
            if (middleClickDown && !middleClickWasDown && mc.field_1755 == null) {
                if (mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1331) {
                    class_1297 e = ((class_3966) mc.field_1765).method_17782();
                    if (e instanceof net.minecraft.class_1657) {
                        String name = e.method_5477().getString();
                        if (friends.contains(name)) {
                            friends.remove(name);
                            p.method_7353(class_2561.method_43470("\u00a7cRemoved friend: " + name), true);
                        } else {
                            friends.add(name);
                            p.method_7353(class_2561.method_43470("\u00a7aAdded friend: " + name), true);
                        }
                    }
                }
            }
            middleClickWasDown = middleClickDown;

            // ── KEYBINDS ──
            if (mc.field_1755 == null) {
                if (wasPressed(handle, keyMenu)) mc.method_1507(useModernGui ? new ModernGuiScreen() : new MenuScreen());
                if (wasPressed(handle, keySpeed))       speedOn       = !speedOn;
                if (wasPressed(handle, keyAura))        auraOn        = !auraOn;
                if (wasPressed(handle, keyFly))         flyOn         = !flyOn;
                if (wasPressed(handle, keyHitbox))      hitboxOn      = !hitboxOn;
                if (wasPressed(handle, keyVelocity))    velocityOn    = !velocityOn;
                if (wasPressed(handle, keyAim))         aimOn         = !aimOn;
                if (wasPressed(handle, keyStrafe))      strafeOn      = !strafeOn;
                if (wasPressed(handle, keyVisuals))     visualsOn     = !visualsOn;
                if (wasPressed(handle, keyNoclip))      noclipOn      = !noclipOn;
                if (wasPressed(handle, keyAntiFlag))    antiFlagOn    = !antiFlagOn;
                if (wasPressed(handle, keyAutoClicker)) autoClickerOn = !autoClickerOn;
                if (wasPressed(handle, keyTriggerBot))  triggerBotOn  = !triggerBotOn;
                if (wasPressed(handle, keyEsp))         espOn         = !espOn;
                if (wasPressed(handle, keyAutoTotem))   autoTotemOn   = !autoTotemOn;
                if (wasPressed(handle, keyAimLock))     aimLockOn     = !aimLockOn;
                if (wasPressed(handle, keySpider))      spiderOn      = !spiderOn;
                if (wasPressed(handle, keyNoWeb))       noWebOn       = !noWebOn;
                if (wasPressed(handle, keyFreeze))      freezeOn      = !freezeOn;
                if (wasPressed(handle, keyAirJump))     airJumpOn     = !airJumpOn;
                if (wasPressed(handle, keyNoFall))      noFallOn      = !noFallOn;
                if (wasPressed(handle, keyJesus))       jesusOn       = !jesusOn;
                if (wasPressed(handle, keyFreecam)) {
                    freecamOn = !freecamOn;
                    if (freecamOn) {
                        freecamPos = p.method_19538();
                        freecamYaw = p.method_36454();
                        freecamPitch = p.method_36455();
                    } else {
                        p.field_5960 = false;
                        p.method_31549().field_7479 = false;
                        if (freecamPos != null) {
                            p.method_33574(freecamPos);
                            p.method_36456(freecamYaw);
                            p.method_36457(freecamPitch);
                            p.method_18800(0, 0, 0);
                        }
                    }
                }
                if (wasPressed(handle, keyXray)) {
                    xrayOn = !xrayOn;
                    mc.field_1769.method_3279();
                }
                PypsenFeatures.handleKey(handle);
            }

            mc.method_1561().method_3955(hitboxOn);

            // ── ANTI-FLAG ──
            if (antiFlagOn) {
                if (speedVal > 2.0f) speedVal = 2.0f;
                if (flySpeed > 1.5f) flySpeed = 1.5f;
                if (auraRange > 4.5f) auraRange = 4.5f;
                if (clickerCps > 15f) clickerCps = 15f;
                if (triggerCps > 15f) triggerCps = 15f;
            }

            // ── AIRJUMP ──
            if (airJumpOn && mc.field_1690.field_1903.method_1434() && !p.method_24828() && p.field_6017 > 0.1f) {
                if (p.field_6012 % 5 == 0) {
                    if (airJumpMode == 0) { // Vanilla
                        p.method_6043();
                    } else if (airJumpMode == 1) { // GhostBlock
                        mc.method_1562().method_2883(new net.minecraft.class_2846(net.minecraft.class_2846.class_2847.field_12969, net.minecraft.class_2338.field_10980, net.minecraft.class_2350.field_11033));
                        p.method_6043();
                    } else if (airJumpMode == 2) { // Packet
                        mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317(), p.method_23318(), p.method_23321(), true));
                        p.method_6043();
                    }
                }
            }

            // ── NOFALL ──
            if (noFallOn && p.field_6017 > 2.5f) {
                if (noFallMode == 0) { // Packet
                    mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317(), p.method_23318(), p.method_23321(), true));
                    p.field_6017 = 0;
                } else if (noFallMode == 1) { // WaterBucket
                    int slot = -1;
                    for (int i = 0; i < 9; i++) if (p.method_31548().method_5438(i).method_7909() == net.minecraft.class_1802.field_8705) slot = i;
                    if (slot != -1) {
                        int oldSlot = p.method_31548().field_7545;
                        p.method_31548().field_7545 = slot;
                        mc.method_1562().method_2883(new net.minecraft.class_2828.class_2831(p.method_36454(), 90, p.method_24828()));
                        mc.field_1761.method_2919(p, net.minecraft.class_1268.field_5808);
                        p.method_31548().field_7545 = oldSlot;
                        p.field_6017 = 0;
                    }
                } else if (noFallMode == 2) { // Web
                    int slot = -1;
                    for (int i = 0; i < 9; i++) if (p.method_31548().method_5438(i).method_7909() == net.minecraft.class_1802.field_8786) slot = i;
                    if (slot != -1) {
                        int oldSlot = p.method_31548().field_7545;
                        p.method_31548().field_7545 = slot;
                        mc.method_1562().method_2883(new net.minecraft.class_2828.class_2831(p.method_36454(), 90, p.method_24828()));
                        mc.field_1761.method_2919(p, net.minecraft.class_1268.field_5808);
                        p.method_31548().field_7545 = oldSlot;
                        p.field_6017 = 0;
                    }
                } else if (noFallMode == 3) { // Vulcan
                    mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317(), p.method_23318() - 0.1, p.method_23321(), true));
                    p.field_6017 = 0;
                } else if (noFallMode == 4) { // Grim
                    mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317(), p.method_23318() + 1E-9, p.method_23321(), false));
                    mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317(), p.method_23318(), p.method_23321(), true));
                    p.field_6017 = 0;
                } else if (noFallMode == 5) { // LiquidBounce
                    mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317(), p.method_23318() - 1000, p.method_23321(), true));
                    p.field_6017 = 0;
                } else if (noFallMode == 6) { // Matrix
                    if (p.field_6017 > 3f) {
                        p.method_18800(p.method_18798().field_1352, -0.05, p.method_18798().field_1350);
                        mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317(), p.method_23318(), p.method_23321(), true));
                        p.field_6017 = 0;
                    }
                } else if (noFallMode == 7) { // NCP
                    mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317(), p.method_23318() - 0.01, p.method_23321(), true));
                    p.field_6017 = 0;
                }
            }

            // ── JESUS ──
            if (jesusOn && p.method_5799()) {
                if (jesusMode == 0) { // Solid
                    p.method_18800(p.method_18798().field_1352, 0, p.method_18798().field_1350);
                    p.method_24830(true);
                } else if (jesusMode == 1) { // Bounce
                    p.method_18800(p.method_18798().field_1352, 0.2, p.method_18798().field_1350);
                } else if (jesusMode == 2) { // LiquidBounce
                    if (p.field_6012 % 2 == 0) p.method_18800(p.method_18798().field_1352, 0.05, p.method_18798().field_1350);
                    else p.method_18800(p.method_18798().field_1352, -0.05, p.method_18798().field_1350);
                } else if (jesusMode == 3) { // Matrix
                    if (p.method_5799()) {
                        p.method_18800(p.method_18798().field_1352, 0.1, p.method_18798().field_1350);
                        p.method_5728(false);
                    }
                }
            }

            // ── FREEZE ──
            if (freezeOn) {
                if (freezeMode == 0) { // Vanilla
                    p.method_18800(0, 0, 0);
                    p.field_6017 = 0; // Prevent fall damage accumulation
                } else if (freezeMode == 1) { // Packet
                    p.method_18800(0, 0, 0);
                    mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317(), p.method_23318(), p.method_23321(), true));
                } else if (freezeMode == 2) { // Intave
                    // Micro-falling to bypass fly checks
                    p.method_18800(0, -0.01, 0);
                    p.field_6017 = 0;
                } else if (freezeMode == 3) { // GhostBlock
                    if (p.field_6012 % 4 == 0) {
                        mc.method_1562().method_2883(new net.minecraft.class_2846(net.minecraft.class_2846.class_2847.field_12969, net.minecraft.class_2338.field_10980, net.minecraft.class_2350.field_11033));
                        mc.method_1562().method_2883(new net.minecraft.class_2846(net.minecraft.class_2846.class_2847.field_12975, net.minecraft.class_2338.field_10980, net.minecraft.class_2350.field_11033));
                        p.method_18800(p.method_18798().field_1352, 0.2, p.method_18798().field_1350);
                    } else {
                        p.method_18800(p.method_18798().field_1352, 0, p.method_18798().field_1350); // Hover between jumps
                    }
                    p.field_6017 = 0;
                } else if (freezeMode == 4) { // LiquidBounce
                    p.method_18800(0, 0, 0);
                    if (p.field_6012 % 2 == 0) {
                        mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317(), p.method_23318() + 1E-5, p.method_23321(), p.method_24828()));
                    }
                }
            }

            // ── SPIDER ──
            if (spiderOn && p.field_5976) {
                if (spiderMode == 0) { // Vanilla
                    class_243 v = p.method_18798();
                    p.method_18800(v.field_1352, 0.2, v.field_1350);
                } else if (spiderMode == 1) { // Jump
                    if (p.method_24828()) p.method_6043();
                } else if (spiderMode == 2) { // Grim
                    if (p.field_6012 % 4 == 0) {
                        class_243 v = p.method_18798();
                        p.method_18800(v.field_1352, 0.4, v.field_1350);
                    }
                } else if (spiderMode == 3) { // GhostBlock (F+Q Exploit)
                    if (p.field_6012 % 4 == 0) {
                        mc.method_1562().method_2883(new net.minecraft.class_2846(net.minecraft.class_2846.class_2847.field_12969, net.minecraft.class_2338.field_10980, net.minecraft.class_2350.field_11033));
                        mc.method_1562().method_2883(new net.minecraft.class_2846(net.minecraft.class_2846.class_2847.field_12975, net.minecraft.class_2338.field_10980, net.minecraft.class_2350.field_11033));
                        p.method_6043();
                    }
                }
            }

            // ── NOWEB (Fast mode logic) ──
            if (noWebOn) {
                class_2248 block = mc.field_1687.method_8320(p.method_24515()).method_26204();
                boolean isWeb = block == net.minecraft.class_2246.field_10343 || block == net.minecraft.class_2246.field_16999;

                if (isWeb) {
                    if (noWebMode == 1) { // Fast
                        p.method_18800(p.method_18798().field_1352, -0.1, p.method_18798().field_1350);
                    } else if (noWebMode == 3) { // Intave
                        // Shift sideways slightly to desync web collision on server, and fall fast
                        p.method_18800(0.05, -0.4, 0.05);
                    } else if (noWebMode == 4) { // EdgeTP
                        boolean foundEdge = false;
                        for (int x = -3; x <= 3 && !foundEdge; x++) {
                            for (int z = -3; z <= 3 && !foundEdge; z++) {
                                if (x == 0 && z == 0) continue;
                                net.minecraft.class_2338 checkPos = p.method_24515().method_10069(x, 0, z);
                                class_2248 checkBlock = mc.field_1687.method_8320(checkPos).method_26204();
                                if (checkBlock != net.minecraft.class_2246.field_10343 && checkBlock != net.minecraft.class_2246.field_16999) {
                                    class_243 target = new class_243(checkPos.method_10263() + 0.5, checkPos.method_10264(), checkPos.method_10260() + 0.5);
                                    mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(target.field_1352, target.field_1351, target.field_1350, p.method_24828()));
                                    p.method_33574(target);
                                    p.method_18800(0, p.method_18798().field_1351, 0);
                                    foundEdge = true;
                                }
                            }
                        }
                        if (!foundEdge) {
                            p.method_18800(0, -0.4, 0); // Fallback if no edge found
                        }
                    }
                }
            }

            // ── AUTOTOTEM ──
            if (autoTotemOn && mc.field_1755 == null) {
                float hp = p.method_6032() + p.method_6067();
                if (hp <= autoTotemHealth && p.method_6079().method_7909() != net.minecraft.class_1802.field_8288) {
                    if (autoTotemMode == 0) { // Instant
                        int slot = -1;
                        for (int i = 9; i < 45; i++) {
                            if (p.field_7498.method_7611(i).method_7677().method_7909() == net.minecraft.class_1802.field_8288) {
                                slot = i;
                                break;
                            }
                        }
                        if (slot != -1) {
                            mc.field_1761.method_2906(0, slot, 0, net.minecraft.class_1713.field_7790, p);
                            mc.field_1761.method_2906(0, 45, 0, net.minecraft.class_1713.field_7790, p);
                            mc.field_1761.method_2906(0, slot, 0, net.minecraft.class_1713.field_7790, p);
                        }
                    } else { // Legit (Step-by-step)
                        if (totemTimer > 0) {
                            totemTimer--;
                        } else {
                            if (totemStep == 0) {
                                totemTargetSlot = -1;
                                for (int i = 9; i < 45; i++) {
                                    if (p.field_7498.method_7611(i).method_7677().method_7909() == net.minecraft.class_1802.field_8288) {
                                        totemTargetSlot = i;
                                        break;
                                    }
                                }
                                if (totemTargetSlot != -1) {
                                    mc.field_1761.method_2906(0, totemTargetSlot, 0, net.minecraft.class_1713.field_7790, p);
                                    totemStep = 1;
                                    totemTimer = 2; // 2 ticks delay
                                }
                            } else if (totemStep == 1) {
                                mc.field_1761.method_2906(0, 45, 0, net.minecraft.class_1713.field_7790, p);
                                totemStep = 2;
                                totemTimer = 2;
                            } else if (totemStep == 2) {
                                mc.field_1761.method_2906(0, totemTargetSlot, 0, net.minecraft.class_1713.field_7790, p);
                                totemStep = 0;
                                totemTimer = 10; // Cooldown
                            }
                        }
                    }
                } else {
                    totemStep = 0; // Reset if we have a totem or health is high
                }
            }

            // ── NOCLIP ──
            if (noclipOn) {
                if (noclipBypass == 0) { // Vanilla
                    p.field_5960 = true;
                    p.field_6017 = 0;
                } else if (noclipBypass == 1) { // VClip (Vertical teleport)
                    if (mc.field_1690.field_1903.method_1434()) p.method_5814(p.method_23317(), p.method_23318() + 0.5, p.method_23321());
                    if (mc.field_1690.field_1832.method_1434()) p.method_5814(p.method_23317(), p.method_23318() - 0.5, p.method_23321());
                } else if (noclipBypass == 2) { // HClip (Horizontal teleport)
                    class_243 forward = p.method_5828(1.0f).method_1021(0.5);
                    p.method_5814(p.method_23317() + forward.field_1352, p.method_23318(), p.method_23321() + forward.field_1350);
                } else if (noclipBypass == 3) { // Packet (Desync)
                    p.field_5960 = true;
                    if (p.field_6012 % 2 == 0) {
                        mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317(), p.method_23318() - 0.01, p.method_23321(), false));
                    }
                }
                p.field_6017 = 0;
            } else if (!freecamOn) {
                p.field_5960 = false;
            }

            // ── FREECAM ──
            if (freecamOn) {
                p.field_5960 = true;
                p.method_31549().field_7479 = true;
                double vy = 0;
                if (mc.field_1690.field_1903.method_1434()) vy = 0.5;
                if (mc.field_1690.field_1832.method_1434()) vy = -0.5;
                float fw = p.field_3913.field_3905;
                float st = p.field_3913.field_3907;
                double vx = 0, vz = 0;
                if (fw != 0 || st != 0) {
                    double yaw = Math.toRadians(p.method_36454());
                    double angle = yaw - Math.atan2(fw, st) + Math.PI / 2;
                    vx = -Math.sin(angle) * 0.5;
                    vz = Math.cos(angle) * 0.5;
                }
                p.method_18800(vx, vy, vz);
            }

            // ── SERVER CRASHER ──
            if (serverCrasherOn) {
                if (crasherStartTime == 0) crasherStartTime = System.currentTimeMillis();
                long elapsed = System.currentTimeMillis() - crasherStartTime;

                if ((crasherTimerMode == 1 && elapsed > 5000) || (crasherTimerMode == 2 && elapsed > 10000)) {
                    serverCrasherOn = false;
                    crasherStartTime = 0;
                } else if (mc.method_1562() == null && crasherTimerMode == 3) {
                    serverCrasherOn = false;
                    crasherStartTime = 0;
                }
            } else {
                crasherStartTime = 0;
            }

            if (serverCrasherOn && mc.method_1562() != null) {
                if (crasherMode == 0) { // Position
                    for (int i = 0; i < 1000; i++) {
                        mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317() + 9999999, p.method_23318() + 9999999, p.method_23321() + 9999999, true));
                    }
                } else if (crasherMode == 1) { // Swing
                    for (int i = 0; i < 5000; i++) {
                        mc.method_1562().method_2883(new net.minecraft.class_2879(class_1268.field_5808));
                    }
                } else if (crasherMode == 2) { // Interact
                    for (int i = 0; i < 1000; i++) {
                        mc.method_1562().method_2883(new net.minecraft.class_2846(net.minecraft.class_2846.class_2847.field_12969, net.minecraft.class_2338.field_10980, net.minecraft.class_2350.field_11033));
                    }
                } else if (crasherMode == 3) { // MathBreaker (NaN/Infinity)
                    for (int i = 0; i < 100; i++) {
                        mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(Double.NaN, Double.POSITIVE_INFINITY, Double.NaN, true));
                    }
                } else if (crasherMode == 4) { // BrandPayload
                    net.minecraft.class_2540 buf = new net.minecraft.class_2540(io.netty.buffer.Unpooled.buffer());
                    buf.method_10814("A".repeat(32000));
                    mc.method_1562().method_2883(new net.minecraft.class_2817(new net.minecraft.class_2960("minecraft:brand"), buf));
                } else if (crasherMode == 5) { // SettingsExploit
                    mc.method_1562().method_2883(new net.minecraft.class_2803("A".repeat(32000), mc.field_1690.method_42503().method_41753(), net.minecraft.class_1659.field_7538, true, 0, net.minecraft.class_1306.field_6182, true, true));
                } else if (crasherMode == 6) { // TabComplete
                    mc.method_1562().method_2883(new net.minecraft.class_2805(0, "/" + "A".repeat(32000)));
                }
            }

            // ── GODMODE ──
            if (godModeOn) {
                if (godModeMode == 0) { // Vanilla
                    // Do nothing, client can't enforce godmode in vanilla without packets
                } else if (godModeMode == 1) { // Packet
                    if (p.field_6012 % 10 == 0) {
                        mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317(), p.method_23318() - 0.1, p.method_23321(), false));
                    }
                } else if (godModeMode == 2) { // Vulcan
                    if (p.field_6012 % 5 == 0) {
                        mc.method_1562().method_2883(new net.minecraft.class_2828.class_2829(p.method_23317(), p.method_23318() + 1337.0, p.method_23321(), true));
                    }
                } else if (godModeMode == 3) { // LiquidBounce (Riding/Dismount exploit)
                    if (p.field_6012 % 3 == 0) {
                        mc.method_1562().method_2883(new net.minecraft.class_2848(p, net.minecraft.class_2848.class_2849.field_12979));
                        mc.method_1562().method_2883(new net.minecraft.class_2848(p, net.minecraft.class_2848.class_2849.field_12984));
                    }
                }
            }

            // ── DROP ALL ITEMS ──
            if (dropAllItems) {
                for (int i = 9; i < 45; i++) {
                    if (!p.field_7498.method_7611(i).method_7677().method_7960()) {
                        mc.field_1761.method_2906(p.field_7498.field_7763, i, 1, net.minecraft.class_1713.field_7795, p);
                    }
                }
                dropAllItems = false;
            }

            // ── AUTOARMOR ──
            if (autoArmorOn && p.field_6012 % 4 == 0 && mc.field_1755 == null && mc.field_1761 != null) {
                for (int type = 0; type < 4; type++) {
                    net.minecraft.class_1799 currentArmor = p.method_31548().method_7372(type);
                    int bestSlot = -1;
                    int bestScore = currentArmor.method_7960() ? -1 : getArmorScore(currentArmor);

                    for (int i = 9; i < 36; i++) {
                        net.minecraft.class_1799 stack = p.method_31548().method_5438(i);
                        if (!stack.method_7960() && stack.method_7909() instanceof net.minecraft.class_1738 armorItem) {
                            if (armorItem.method_7685().method_5927() == type) {
                                int score = getArmorScore(stack);
                                if (score > bestScore) {
                                    bestScore = score;
                                    bestSlot = i;
                                }
                            }
                        }
                    }

                    if (bestSlot != -1) {
                        if (!currentArmor.method_7960()) {
                            mc.field_1761.method_2906(p.field_7498.field_7763, 8 - type, 0, net.minecraft.class_1713.field_7794, p);
                        }
                        mc.field_1761.method_2906(p.field_7498.field_7763, bestSlot, 0, net.minecraft.class_1713.field_7794, p);
                        break;
                    }
                }
            }

            // ── FASTBOW ──
            if (fastBowOn && p.method_6047().method_7909() == net.minecraft.class_1802.field_8102 && mc.field_1690.field_1904.method_1434()) {
                mc.method_1562().method_2883(new net.minecraft.class_2846(net.minecraft.class_2846.class_2847.field_12974, net.minecraft.class_2338.field_10980, net.minecraft.class_2350.field_11033));
                mc.method_1562().method_2883(new net.minecraft.class_2886(class_1268.field_5808, 0));

                if (bowJump && p.method_24828()) {
                    p.method_6043();
                    p.method_36457(-90);
                }
            }

            // ── AUTOCLICKER ──
            boolean isClicking = autoClickerRight ? mc.field_1690.field_1904.method_1434() : mc.field_1690.field_1886.method_1434();
            if (autoClickerOn && isClicking && mc.field_1755 == null) {
                clickTimer++;
                int delay = (int) (20f / Math.max(1f, clickerCps));
                if (clickTimer >= delay) {
                    clickTimer = 0;
                    if (autoClickerRight) {
                        if (autoClickerFarm && mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1332) {
                            net.minecraft.class_2338 pos = ((net.minecraft.class_3965) mc.field_1765).method_17777();
                            class_2248 block = mc.field_1687.method_8320(pos).method_26204();
                            if (block == net.minecraft.class_2246.field_10293 || block == net.minecraft.class_2246.field_10609 || block == net.minecraft.class_2246.field_10247) {
                                mc.field_1761.method_2896(p, class_1268.field_5808, (net.minecraft.class_3965) mc.field_1765);
                            }
                        } else {
                            mc.field_1761.method_2919(p, class_1268.field_5808);
                        }
                        p.method_6104(class_1268.field_5808);
                    } else {
                        if (mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1331) {
                            mc.field_1761.method_2918(p, ((class_3966) mc.field_1765).method_17782());
                        }
                        p.method_6104(class_1268.field_5808);
                    }
                }
            } else {
                clickTimer = 0;
            }

            // ── TRIGGERBOT ──
            if (triggerBotOn && mc.field_1755 == null && mc.field_1761 != null) {
                triggerFloatTimer += 1f;
                float ticksPerHit = 20f / Math.max(1f, triggerCps);
                if (triggerJitter > 0f) {
                    ticksPerHit *= 1f + (float) (Math.random() - 0.5) * 2f * (triggerJitter / 100f);
                }
                ticksPerHit = Math.max(1f, ticksPerHit);

                if (triggerFloatTimer >= ticksPerHit) {
                    triggerFloatTimer = 0f;
                    triggerTimer++;

                    class_1297 target = null;
                    if (mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1331) {
                        class_1297 aimed = ((class_3966) mc.field_1765).method_17782();
                        if (isValidTriggerTarget(aimed, p, mc)) target = aimed;
                    }

                    // Through-walls mode scans for the closest entity inside the configured cone.
                    if (target == null && triggerThroughWalls) {
                        double bestAngle = Double.MAX_VALUE;
                        for (class_1297 candidate : mc.field_1687.method_18112()) {
                            if (!isValidTriggerTarget(candidate, p, mc)) continue;
                            double angle = getAngleDifference(p, candidate);
                            if (angle < bestAngle) {
                                bestAngle = angle;
                                target = candidate;
                            }
                        }
                        if (target != null && bestAngle > class_3532.method_15363(triggerFov, 1f, 180f) * 0.5f) target = null;
                    }

                    if (target != null) {
                        boolean isWeapon = p.method_6047().method_7909() instanceof class_1829 || p.method_6047().method_7909() instanceof class_1743;
                        if (!triggerWeaponOnly || isWeapon) {
                            boolean cooldownOk = !triggerSmartDelay || p.method_7261(0.0f) >= class_3532.method_15363(triggerCooldown, 0f, 1f);
                            boolean targetReady = !triggerWaitHurtTime || ((class_1309) target).field_6235 == 0;
                            if (cooldownOk && targetReady) {
                                if (triggerAutoWeapon) {
                                    int slot = findBestWeapon(p, p.method_6047().method_7909() instanceof class_1743);
                                    if (slot >= 0) p.method_31548().field_7545 = slot;
                                }
                                if (triggerCriticals && (p.method_24828() || p.method_5799())) {
                                    p.method_5762(0, 0.1, 0);
                                    p.field_6017 = 0.1f;
                                    p.method_24830(false);
                                }
                                mc.field_1761.method_2918(p, target);
                                p.method_6104(class_1268.field_5808);
                                p.method_7350();
                            }
                        }
                    }
                }
            } else {
                triggerTimer = 0;
                triggerFloatTimer = 0f;
            }

            // ── FULLBRIGHT ──
            if (fullBrightOn) {
                p.method_6092(new net.minecraft.class_1293(net.minecraft.class_1294.field_5925, 1000, 0, false, false, false));
                wasFullBright = true;
            } else if (wasFullBright) {
                if (p.method_6059(net.minecraft.class_1294.field_5925)) {
                    p.method_6016(net.minecraft.class_1294.field_5925);
                }
                wasFullBright = false;
            }

            // ── VISUALS (ESP & SUB-FUNCTIONS) ──
            if (visualsOn) {
                mc.field_1687.method_18112().forEach(e -> {
                    if (e instanceof class_1309 && e != p) {
                        boolean isFriend = friends.contains(e.method_5477().getString());
                        boolean shouldGlow = false;
                        if (visualsTargetMode == 0) shouldGlow = true;
                        else if (visualsTargetMode == 1 && !isFriend) shouldGlow = true;
                        else if (visualsTargetMode == 2 && isFriend) shouldGlow = true;
                        e.method_5834(shouldGlow);
                    }
                });
                visualsWasOn = true;

                if (noFireOn && p.method_5809()) {
                    p.method_20803(0);
                }
                if (noNauseaOn && p.method_6059(net.minecraft.class_1294.field_5916)) {
                    p.method_6016(net.minecraft.class_1294.field_5916);
                }
                if (targetEspOn && currentTarget != null && currentTarget.method_5805()) {
                    double r = currentTarget.method_17681() * 1.2;
                    for (int i = 0; i < 5; i++) {
                        double angle = (System.currentTimeMillis() / 5.0 + i * 72) % 360;
                        double rad = Math.toRadians(angle);
                        double px = currentTarget.method_23317() + Math.cos(rad) * r;
                        double pz = currentTarget.method_23321() + Math.sin(rad) * r;

                        // Feet circle (Soup Visuals style)
                        mc.field_1687.method_8406(net.minecraft.class_2398.field_11211, px, currentTarget.method_23318(), pz, 0, 0, 0);

                        // Halo above head
                        mc.field_1687.method_8406(net.minecraft.class_2398.field_11207, px, currentTarget.method_23318() + currentTarget.method_17682() + 0.3, pz, 0, 0, 0);
                    }

                    // Outline box around target
                    double minX = currentTarget.method_23317() - currentTarget.method_17681() / 2;
                    double minY = currentTarget.method_23318();
                    double minZ = currentTarget.method_23321() - currentTarget.method_17681() / 2;
                    double maxX = currentTarget.method_23317() + currentTarget.method_17681() / 2;
                    double maxY = currentTarget.method_23318() + currentTarget.method_17682();
                    double maxZ = currentTarget.method_23321() + currentTarget.method_17681() / 2;

                    mc.field_1687.method_8406(net.minecraft.class_2398.field_11240, minX, minY, minZ, 0, 0, 0);
                    mc.field_1687.method_8406(net.minecraft.class_2398.field_11240, maxX, maxY, maxZ, 0, 0, 0);
                }
            } else if (visualsWasOn) {
                mc.field_1687.method_18112().forEach(e -> {
                    if (e instanceof class_1309 && e != p) e.method_5834(false);
                });
                visualsWasOn = false;
            }

            // ── AIM ASSIST & AIMLOCK ──
            if ((aimOn || aimLockOn) && mc.field_1755 == null && !auraOn) {
                var list = mc.field_1687.method_8333(p, p.method_5829().method_1014(15), e -> e instanceof class_1309 && e.method_5805() && !e.method_7325());
                class_1297 target = list.stream().min(Comparator.comparingDouble(e -> e.method_5739(p))).orElse(null);
                if (target != null) {
                    float[] rots = getRotations(p, target, false);
                    if (aimLockOn) {
                        p.method_36456(rots[0]);
                        p.method_36457(rots[1]);
                    } else {
                        p.method_36456(p.method_36454() + (rots[0] - p.method_36454()) * (aimSpeed / 100f));
                        p.method_36457(p.method_36455() + (rots[1] - p.method_36455()) * (aimSpeed / 100f));
                    }
                }
            }

            // ── STRAFE ──
            if (strafeOn && mc.field_1755 == null) {
                if (p.field_3913.field_3905 != 0 || p.field_3913.field_3907 != 0) {
                    if (p.method_24828()) p.method_6043();
                    double yaw = Math.toRadians(p.method_36454());
                    double angle = yaw - Math.atan2(p.field_3913.field_3905, p.field_3913.field_3907) + Math.PI / 2;
                    double spd = 0.26;
                    p.method_18800(-Math.sin(angle) * spd, p.method_18798().field_1351, Math.cos(angle) * spd);
                }
            }

            // ── SPEED ──
            if (speedOn && mc.field_1755 == null && !strafeOn) {
                float fw = p.field_3913.field_3905;
                float st = p.field_3913.field_3907;
                if (fw != 0 || st != 0) {
                    double yaw   = Math.toRadians(p.method_36454());
                    double spd   = speedVal / 20.0;
                    double angle = yaw - Math.atan2(fw, st) + Math.PI / 2;
                    double vx = -Math.sin(angle) * spd;
                    double vz =  Math.cos(angle) * spd;

                    switch (speedBypass) {
                        case 4 -> { // NCP
                            if (p.method_24828()) p.method_6043();
                            else { vx *= 1.02; vz *= 1.02; p.method_18800(p.method_18798().field_1352, p.method_18798().field_1351 - 0.02, p.method_18798().field_1350); }
                        }
                        case 5 -> { // Matrix
                            if (p.method_24828()) p.method_6043();
                            vx *= 1.01; vz *= 1.01;
                        }
                        case 6 -> { // Grim
                            spd = 0.28;
                            vx = -Math.sin(angle) * spd; vz = Math.cos(angle) * spd;
                        }
                        case 7 -> { // Funtime
                            if (p.method_24828()) p.method_6043();
                            vx *= 1.005; vz *= 1.005;
                        }
                        case 8 -> { // ReallyWorld
                            spd = 0.26;
                            vx = -Math.sin(angle) * spd; vz = Math.cos(angle) * spd;
                        }
                        case 9 -> { // Vulcan
                            if (p.method_24828()) p.method_6043();
                            if (p.field_6012 % 2 == 0) { vx *= 1.01; vz *= 1.01; }
                        }
                        case 10 -> { // Spartan
                            spd = 0.25;
                            vx = -Math.sin(angle) * spd; vz = Math.cos(angle) * spd;
                        }
                    }
                    p.method_18800(vx, p.method_18798().field_1351, vz);
                }
            }

            // ── FLY ──
            if (flyOn) {
                p.method_31549().field_7479 = true;
                double vy = 0;
                if (mc.field_1690.field_1903.method_1434())   vy =  flySpeed / 10.0;
                if (mc.field_1690.field_1832.method_1434())   vy = -flySpeed / 10.0;

                float fw = p.field_3913.field_3905;
                float st = p.field_3913.field_3907;
                double vx = p.method_18798().field_1352;
                double vz = p.method_18798().field_1350;

                if (fw != 0 || st != 0) {
                    double yaw   = Math.toRadians(p.method_36454());
                    double spd   = flySpeed / 20.0;
                    double angle = yaw - Math.atan2(fw, st) + Math.PI / 2;
                    vx = -Math.sin(angle) * spd;
                    vz =  Math.cos(angle) * spd;
                } else { vx = 0; vz = 0; }

                switch (flyBypass) {
                    case 4 -> vy = -0.04; // NCP
                    case 5 -> { if (p.field_6012 % 10 == 0) vy = 0.1; else vy = -0.05; } // Matrix
                    case 6 -> vy = 0; // Grim
                    case 7 -> vy = -0.01; // Funtime
                    case 8 -> vy = -0.03; // ReallyWorld
                    case 9 -> { if (p.field_6012 % 5 == 0) vy = 0.05; else vy = -0.05; } // Vulcan
                    case 10 -> vy = -0.02; // Spartan
                }
                p.method_18800(vx, vy, vz);
            } else {
                if (mc.field_1724 != null && !mc.field_1724.method_7337() && !mc.field_1724.method_7325()) {
                    mc.field_1724.method_31549().field_7479 = false;
                }
            }

            // ── KILLAURA (ROBUST 1.9+ LOGIC) ──
            if (auraOn) {
                auraTick++;

                // Smooth rotation logic
                if (isRotating && (auraRotMode == 2 || auraRotMode == 16 || auraRotMode == 17)) {
                    if (auraRotMode == 2) {
                        p.method_36456(p.method_36454() + (targetYaw - p.method_36454()) * 0.4f);
                        p.method_36457(p.method_36455() + (targetPitch - p.method_36455()) * 0.4f);
                    } else if (auraRotMode == 16) {
                        float smoothFactor = 0.01f + (auraStickiness / 100f) * 0.99f; // 0.01 to 1.0
                        float diffYaw = targetYaw - p.method_36454();
                        float diffPitch = targetPitch - p.method_36455();

                        // Apply curve
                        if (auraRotCurve > 0) {
                            float curve = (auraRotCurve / 100f) * 30.0f;
                            diffYaw += (float)(Math.sin(auraTick * 0.2) * curve);
                            diffPitch += (float)(Math.cos(auraTick * 0.2) * curve);
                        }

                        p.method_36456(p.method_36454() + diffYaw * smoothFactor);
                        p.method_36457(p.method_36455() + diffPitch * smoothFactor);
                    } else if (auraRotMode == 17) {
                        float diffYaw = targetYaw - p.method_36454();
                        float diffPitch = targetPitch - p.method_36455();

                        // Base smoothing
                        float smoothFactor = 0.05f + (auraStickiness / 100f) * 0.95f;

                        // Add looping effect (figure-8 pattern)
                        float loopSize = (auraRotCurve / 100f) * 40.0f;
                        float loopSpeed = 0.3f;

                        diffYaw += (float)(Math.sin(auraTick * loopSpeed) * loopSize);
                        diffPitch += (float)(Math.sin(auraTick * loopSpeed * 2.0) * loopSize * 0.5f);

                        p.method_36456(p.method_36454() + diffYaw * smoothFactor);
                        p.method_36457(p.method_36455() + diffPitch * smoothFactor);
                    }
                }

                if (auraHitInGuis || mc.field_1755 == null) {
                    var list = mc.field_1687.method_8333(p, p.method_5829().method_1014(auraRange), e -> {
                        if (!(e instanceof class_1309) || !e.method_5805() || e == p || e.method_7325()) return false;
                        if (friends.contains(e.method_5477().getString())) return false;

                        boolean isPlayer = e instanceof net.minecraft.class_1657;
                        boolean isMob = e instanceof net.minecraft.class_1588;
                        boolean isAnimal = e instanceof net.minecraft.class_1429;

                        if (isPlayer && !auraTargetPlayers) return false;
                        if (isMob && !auraTargetMobs) return false;
                        if (isAnimal && !auraTargetAnimals) return false;

                        if (antiBotOn) {
                            if (e.method_5767() || e.field_6012 < 20 || e.method_5477().getString().isEmpty() || e.method_5477().getString().contains(" ")) return false;
                        }

                        // FOV Check
                        if (auraFov < 360f) {
                            float[] rots = getRotations(p, e);
                            float yawDiff = Math.abs(net.minecraft.class_3532.method_15393(p.method_36454() - rots[0]));
                            if (yawDiff > auraFov / 2f) return false;
                        }

                        return true;
                    });

                    class_1309 target = null;
                    if (!list.isEmpty()) {
                        switch (auraTargetMode) {
                            case 0 -> target = (class_1309) list.stream().min(Comparator.comparingDouble(e -> e.method_5739(p))).orElse(null); // Distance
                            case 1 -> target = (class_1309) list.stream().min(Comparator.comparingDouble(e -> ((class_1309)e).method_6032())).orElse(null); // Health
                            case 2 -> target = (class_1309) list.stream().min(Comparator.comparingDouble(e -> ((class_1309)e).method_6096())).orElse(null); // Armor
                            case 3 -> target = (class_1309) list.stream().min(Comparator.comparingDouble(e -> getAngleDifference(p, e))).orElse(null); // Angle
                        }
                    }

                    currentTarget = target;

                    if (target != null && p.method_5739(target) <= auraRange) {
                        if (!auraThroughWalls && !p.method_6057(target)) target = null;

                        if (target != null) {

                            // 1. Calculate Rotations
                            float[] rots = getRotations(p, target);
                            float idealYaw = rots[0];
                            float idealPitch = rots[1];

                            // Apply auraRotSpeed limit
                            if (auraRotSpeed < 180.0f) {
                                float diffYaw = net.minecraft.class_3532.method_15393(idealYaw - p.method_36454());
                                float diffPitch = idealPitch - p.method_36455();

                                if (diffYaw > auraRotSpeed) diffYaw = auraRotSpeed;
                                if (diffYaw < -auraRotSpeed) diffYaw = -auraRotSpeed;
                                if (diffPitch > auraRotSpeed) diffPitch = auraRotSpeed;
                                if (diffPitch < -auraRotSpeed) diffPitch = -auraRotSpeed;

                                targetYaw = p.method_36454() + diffYaw;
                                targetPitch = p.method_36455() + diffPitch;
                            } else {
                                targetYaw = idealYaw;
                                targetPitch = idealPitch;
                            }
                            isRotating = true;

                            // Apply Rotations based on mode
                            switch (auraRotMode) {
                                case 1 -> { // Snap
                                    p.method_36456(targetYaw);
                                    p.method_36457(targetPitch);
                                }
                                case 2 -> { // Smooth (handled above)
                                }
                                case 3 -> { // Silent
                                    mc.method_1562().method_2883(new net.minecraft.class_2828.class_2831(targetYaw, targetPitch, p.method_24828()));
                                }
                                case 4 -> { // Matrix (Randomized Jitter)
                                    p.method_36456(targetYaw + (float)(Math.random() * 6 - 3));
                                    p.method_36457(targetPitch + (float)(Math.random() * 6 - 3));
                                }
                                case 5 -> { // Predict
                                    double predX = target.method_23317() + (target.method_23317() - target.field_6014) * 2.0;
                                    double predZ = target.method_23321() + (target.method_23321() - target.field_5969) * 2.0;
                                    double dx = predX - p.method_23317();
                                    double dz = predZ - p.method_23321();
                                    double dy = (target.method_23318() + target.method_18381(target.method_18376())) - (p.method_23318() + p.method_18381(p.method_18376()));
                                    double dist = Math.sqrt(dx * dx + dz * dz);
                                    targetYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
                                    targetPitch = (float) -Math.toDegrees(Math.atan2(dy, dist));
                                    p.method_36456(p.method_36454() + (targetYaw - p.method_36454()) * 0.5f);
                                    p.method_36457(p.method_36455() + (targetPitch - p.method_36455()) * 0.5f);
                                }
                                case 6 -> { // Smart (Super smooth, free but snapping)
                                    targetYaw += (float)((Math.random() - 0.5) * 4.0);
                                    targetPitch += (float)((Math.random() - 0.5) * 4.0);
                                    p.method_36456(p.method_36454() + (targetYaw - p.method_36454()) * 0.25f);
                                    p.method_36457(p.method_36455() + (targetPitch - p.method_36455()) * 0.25f);
                                }
                                case 7 -> { // Legit (Smooth, no jitter, precise)
                                    p.method_36456(p.method_36454() + (targetYaw - p.method_36454()) * 0.15f);
                                    p.method_36457(p.method_36455() + (targetPitch - p.method_36455()) * 0.15f);
                                }
                                case 8 -> { // HvH (Instant snap, max precision)
                                    p.method_36456(targetYaw);
                                    p.method_36457(targetPitch);
                                }
                                case 9 -> { // Derp (Random crazy rotations, but hits target)
                                    targetYaw += (float)((Math.random() - 0.5) * 360.0);
                                    targetPitch += (float)((Math.random() - 0.5) * 180.0);
                                    p.method_36456(targetYaw);
                                    p.method_36457(targetPitch);
                                }
                                case 10 -> { // Cinematic (Extremely smooth)
                                    p.method_36456(p.method_36454() + (targetYaw - p.method_36454()) * 0.05f);
                                    p.method_36457(p.method_36455() + (targetPitch - p.method_36455()) * 0.05f);
                                }
                                case 11 -> { // NCP (Strict limits on rotation speed)
                                    float diffYaw = targetYaw - p.method_36454();
                                    float diffPitch = targetPitch - p.method_36455();
                                    diffYaw = Math.max(-30f, Math.min(30f, diffYaw));
                                    diffPitch = Math.max(-15f, Math.min(15f, diffPitch));
                                    p.method_36456(p.method_36454() + diffYaw);
                                    p.method_36457(p.method_36455() + diffPitch);
                                }
                                case 12 -> { // AAC (Specific jitter)
                                    p.method_36456(targetYaw + (float)(Math.sin(System.currentTimeMillis() / 100.0) * 2.0));
                                    p.method_36457(targetPitch + (float)(Math.cos(System.currentTimeMillis() / 100.0) * 2.0));
                                }
                                case 13 -> { // Sunrise (Specific RU server bypass)
                                    targetYaw += (float)((Math.random() - 0.5) * 1.5);
                                    targetPitch += (float)((Math.random() - 0.5) * 1.5);
                                    p.method_36456(p.method_36454() + (targetYaw - p.method_36454()) * 0.4f);
                                    p.method_36457(p.method_36455() + (targetPitch - p.method_36455()) * 0.4f);
                                }
                                case 14 -> { // Vulcan (Vulcan AC specific rotations)
                                    float diffYaw = targetYaw - p.method_36454();
                                    diffYaw = Math.round(diffYaw / 0.5f) * 0.5f; // Round to nearest 0.5
                                    p.method_36456(p.method_36454() + diffYaw * 0.8f);
                                    p.method_36457(targetPitch);
                                }
                                case 15 -> { // Intave (Very strict, needs to be perfectly aligned but with slight realistic jitter, and no snapping)
                                    p.method_36456(p.method_36454() + (targetYaw - p.method_36454()) * 0.1f + (float)(Math.random() - 0.5) * 0.5f);
                                    p.method_36457(p.method_36455() + (targetPitch - p.method_36455()) * 0.1f + (float)(Math.random() - 0.5) * 0.5f);
                                }
                                case 16 -> { // Legit Smooth (handled above)
                                }
                                case 17 -> { // Looping (handled above)
                                }
                                case 18 -> { // LiquidBounce
                                    float diffYaw = targetYaw - p.method_36454();
                                    float diffPitch = targetPitch - p.method_36455();

                                    // LiquidBounce uses a specific randomized step
                                    float step = 40.0f + (float)Math.random() * 10.0f;
                                    diffYaw = Math.max(-step, Math.min(step, diffYaw));
                                    diffPitch = Math.max(-step, Math.min(step, diffPitch));

                                    p.method_36456(p.method_36454() + diffYaw);
                                    p.method_36457(p.method_36455() + diffPitch);
                                }
                                case 19 -> { // Custom
                                    float diffYaw = targetYaw - p.method_36454();
                                    float diffPitch = targetPitch - p.method_36455();
                                    float smooth = 0.01f + (auraStickiness / 100f) * 0.99f;
                                    p.method_36456(p.method_36454() + diffYaw * smooth);
                                    p.method_36457(p.method_36455() + diffPitch * smooth);
                                }
                                case 20 -> { // Noise
                                    float noiseYaw = (float)(Math.sin(auraTick * 0.5) * (auraRotCurve / 100f) * 20.0f);
                                    float noisePitch = (float)(Math.cos(auraTick * 0.5) * (auraRotCurve / 100f) * 20.0f);
                                    p.method_36456(targetYaw + noiseYaw);
                                    p.method_36457(targetPitch + noisePitch);
                                }
                            }

                            // 2. Check if we can hit
                            boolean canHit = false;

                            // STRICT 1.9 COOLDOWN CHECK
                            float cooldown = p.method_7261(0.0f);

                            switch (auraMode) {
                                case 0 -> { // 1.9 Strict
                                    // Must be exactly 1.0f or higher to ensure full damage and no spam
                                    if (cooldown >= 1.0f) {
                                        canHit = true;
                                    }
                                }
                                case 1 -> { // 1.8 Spam
                                    canHit = auraTick % 2 == 0;
                                }
                                case 2 -> { // Adaptive (Randomized cooldown to bypass anti-cheats)
                                    if (cooldown >= (0.85f + Math.random() * 0.15f)) {
                                        canHit = true;
                                    }
                                }
                            }

                            // Timing Check (Jump Phase)
                            if (canHit) {
                                if (auraTimingMode == 1) { // Fall (Crits)
                                    if (p.method_18798().field_1351 >= 0 || p.method_24828()) canHit = false;
                                } else if (auraTimingMode == 2) { // Jump (Crits)
                                    if (p.method_24828() || p.method_18798().field_1351 <= 0) canHit = false;
                                }
                            }

                            // Raycast check (if enabled, ensure we are actually looking at them)
                            if (canHit && auraRayCast && auraRotMode != 3) { // If not silent
                                double dToT = p.method_5739(target);
                                class_243 eyePos = p.method_5836(1.0f);
                                class_243 lookVec = p.method_5828(1.0f);
                                class_243 traceEnd = eyePos.method_1031(lookVec.field_1352 * dToT, lookVec.field_1351 * dToT, lookVec.field_1350 * dToT);
                                class_239 hit = mc.field_1687.method_17742(new class_3959(eyePos, traceEnd, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, p));
                                // If we hit a block before the entity, don't hit (unless through walls is on)
                                if (!auraThroughWalls && hit.method_17783() == class_239.class_240.field_1332) {
                                    canHit = false;
                                }
                            }

                            // 3. Bypasses
                            if (canHit) {
                                switch (auraBypass) {
                                    case 2 -> { if (auraTick % 3 != 0) canHit = false; }
                                    case 3 -> { // Strafe around
                                        double circleAngle = Math.toRadians(targetYaw + 90);
                                        p.method_18800(-Math.sin(circleAngle) * 0.2, p.method_18798().field_1351, Math.cos(circleAngle) * 0.2);
                                    }
                                    case 5 -> { if (Math.random() > 0.8) canHit = false; } // Matrix
                                    case 6 -> { if (!p.method_6057(target)) canHit = false; } // Grim
                                    case 7 -> { // Funtime
                                        if (Math.random() > 0.9) canHit = false;
                                        if (!p.method_6057(target)) canHit = false;
                                    }
                                    case 8 -> { // ReallyWorld
                                        if (cooldown < 1.0f) canHit = false;
                                        if (!p.method_6057(target)) canHit = false;
                                    }
                                    case 9 -> { // Vulcan
                                        if (p.field_6012 % 2 != 0) canHit = false;
                                    }
                                    case 10 -> { // Spartan
                                        if (p.method_5739(target) > 3.5f) canHit = false;
                                    }
                                    case 11 -> { // Grim AC (Strict Raycast & Timing)
                                        if (cooldown < 1.0f) canHit = false;
                                        if (!p.method_6057(target)) canHit = false;
                                        if (Math.abs(p.method_36454() - targetYaw) > 15) canHit = false; // Must be looking precisely
                                    }
                                    case 12 -> { // Polar AC (Randomized Delays & Smooth Rots)
                                        if (cooldown < 0.95f + Math.random() * 0.05f) canHit = false;
                                        if (auraTick % (2 + (int)(Math.random() * 2)) != 0) canHit = false; // Random hits
                                    }
                                    case 13 -> { // Intave
                                        if (cooldown < 1.0f) canHit = false;
                                        if (p.method_5739(target) > 3.0f) canHit = false; // Strict reach
                                        if (Math.abs(p.method_36454() - targetYaw) > 20) canHit = false; // Must be looking at target
                                    }
                                }
                            }

                            // 4. Attack
                            if (canHit) {
                                // Weapon selection: Shield Breaker works even with AutoWeapon off.
                                boolean blockingPlayer = shieldBreaker && target instanceof net.minecraft.class_1657 tp && tp.method_6039();
                                if (autoWeapon || blockingPlayer) {
                                    int bestSlot = findBestWeapon(p, blockingPlayer);
                                    if (bestSlot >= 0) p.method_31548().field_7545 = bestSlot;
                                }

                                // Criticals (Mini-jump)
                                if (criticals && (p.method_24828() || (waterCrits && p.method_5799()))) {
                                    p.method_5762(0, 0.1, 0);
                                    p.field_6017 = 0.1f;
                                    p.method_24830(false);
                                }

                                // Visuals Particles
                                if (visualsOn && visualsParticles > 0) {
                                    net.minecraft.class_2394 particle = net.minecraft.class_2398.field_11205;
                                    if (visualsParticles == 2) particle = net.minecraft.class_2398.field_11240;
                                    else if (visualsParticles == 3) particle = net.minecraft.class_2398.field_11249;
                                    else if (visualsParticles == 4) particle = net.minecraft.class_2398.field_11208;

                                    for (int i = 0; i < 5; i++) {
                                        mc.field_1687.method_8406(particle, target.method_23317() + (Math.random() - 0.5), target.method_23318() + Math.random() * target.method_17682(), target.method_23321() + (Math.random() - 0.5), 0, 0, 0);
                                    }
                                }

                                if (auraJump && p.method_24828()) p.method_6043();

                                mc.field_1761.method_2918(p, target);
                                p.method_6104(class_1268.field_5808);
                                p.method_7350(); // Reset cooldown
                            }
                        }
                    } else {
                        currentTarget = null;
                        isRotating = false;
                        if (auraSpinBot) p.method_36456(p.method_36454() + 45f);
                    }
                }
            } else {
                if (mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1331) {
                    class_1297 e = ((class_3966) mc.field_1765).method_17782();
                    if (e instanceof class_1309) currentTarget = (class_1309) e;
                } else {
                    currentTarget = null;
                }
                isRotating = false;
                if (auraSpinBot) p.method_36456(p.method_36454() + 45f);
            }

            PypsenFeatures.tick(mc);

            if (xrayOn != xrayWasOn) {
                mc.field_1769.method_3279();
                xrayWasOn = xrayOn;
            }
        });
    }

    private static float[] getRotations(class_1297 p, class_1297 target) {
        return getRotations(p, target, true);
    }

    private static float[] getRotations(class_1297 p, class_1297 target, boolean applyAuraJitter) {
        double targetX = target.method_23317();
        double targetZ = target.method_23321();
        double targetY = target.method_23318();

        if (auraPredict) {
            class_243 v = target.method_18798();
            targetX += v.field_1352 * 2.0;
            targetZ += v.field_1350 * 2.0;
        }

        switch (auraTargetPart) {
            case 0 -> targetY += target.method_18381(target.method_18376()); // Head
            case 1 -> targetY += target.method_17682() * 0.6; // Chest
            case 2 -> targetY += target.method_17682() * 0.2; // Legs
            case 3 -> {} // Feet
        }

        if (applyAuraJitter && (auraAimJitter > 0 || auraRandomize)) {
            double jitter = auraRandomize ? Math.max(auraAimJitter, 0.1) : auraAimJitter;
            targetX += (Math.random() - 0.5) * jitter;
            targetY += (Math.random() - 0.5) * jitter;
            targetZ += (Math.random() - 0.5) * jitter;
        }

        double dx = targetX - p.method_23317();
        double dz = targetZ - p.method_23321();
        double dy = targetY - (p.method_23318() + p.method_18381(p.method_18376()));
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        // GCD Fix
        float f = class_310.method_1551().field_1690.method_42495().method_41753().floatValue() * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        yaw -= yaw % gcd;
        pitch -= pitch % gcd;

        return new float[]{yaw, pitch};
    }

    private static int getArmorScore(net.minecraft.class_1799 stack) {
        if (stack.method_7909() instanceof net.minecraft.class_1738 armor) {
            int score = armor.method_7687();
            score += net.minecraft.class_1890.method_8225(net.minecraft.class_1893.field_9111, stack);
            return score;
        }
        return -1;
    }

    private static int findBestWeapon(net.minecraft.class_746 p, boolean preferAxe) {
        int bestSlot = -1;
        float bestDamage = -1f;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = p.method_31548().method_5438(i);
            if (stack.method_7960()) continue;
            float damage;
            if (stack.method_7909() instanceof class_1829 sword) {
                damage = sword.method_8020();
            } else if (stack.method_7909() instanceof class_1743 axe) {
                damage = axe.method_26366();
            } else {
                continue;
            }
            if (preferAxe && stack.method_7909() instanceof class_1743) damage += 1000f;
            if (damage > bestDamage) {
                bestDamage = damage;
                bestSlot = i;
            }
        }
        return bestSlot;
    }

    private static boolean isValidTriggerTarget(class_1297 e, net.minecraft.class_746 p, class_310 mc) {
        if (!(e instanceof class_1309 living) || !living.method_5805() || e == p || e.method_7325()) return false;
        if (friends.contains(e.method_5477().getString())) return false;
        if (p.method_5739(e) > triggerRange) return false;

        boolean isPlayer = e instanceof net.minecraft.class_1657;
        boolean isMob = e instanceof net.minecraft.class_1588;
        boolean isAnimal = e instanceof net.minecraft.class_1429;
        if (isPlayer && !triggerTargetPlayers) return false;
        if (isMob && !triggerTargetMobs) return false;
        if (isAnimal && !triggerTargetAnimals) return false;

        if (antiBotOn && isPlayer && (e.field_6012 < 20 || e.method_5477().getString().isEmpty() || e.method_5477().getString().contains(" "))) return false;
        if (!triggerThroughWalls && !p.method_6057(e)) return false;
        return true;
    }

    private static int getHealthColor(float hp, float maxHp) {
        float ratio = hp / maxHp;
        if (ratio > 0.75f) return 0xFF00FF00; // Green
        if (ratio > 0.5f) return 0xFFFFFF00;  // Yellow
        if (ratio > 0.25f) return 0xFFFF8800; // Orange
        return 0xFFFF0000;                    // Red
    }

    private static double getAngleDifference(class_1297 p, class_1297 e) {
        float[] rots = getRotations(p, e, false);
        return Math.abs(class_3532.method_15393(p.method_36454() - rots[0]));
    }

    private static float[] projectToScreen(class_243 pos, class_243 camPos, org.joml.Vector3f right,
                                           org.joml.Vector3f up, org.joml.Vector3f forward,
                                           double focal, int sw, int sh) {
        double rx = pos.field_1352 - camPos.field_1352;
        double ry = pos.field_1351 - camPos.field_1351;
        double rz = pos.field_1350 - camPos.field_1350;
        double cx = rx * right.x + ry * right.y + rz * right.z;
        double cy = rx * up.x + ry * up.y + rz * up.z;
        double cz = rx * forward.x + ry * forward.y + rz * forward.z;
        if (cz <= 0.1) return null;

        float sx = (float) (sw * 0.5 + (cx / cz) * focal);
        float sy = (float) (sh * 0.5 - (cy / cz) * focal);
        if (sx < -4096f || sx > 4096f || sy < -4096f || sy > 4096f) return null;
        return new float[]{sx, sy, (float) cz};
    }

    private static void drawEspLine(class_332 ctx, int x0, int y0, int x1, int y1, int color) {
        int dx = Math.abs(x1 - x0);
        int dy = Math.abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1;
        int sy = y0 < y1 ? 1 : -1;
        int err = dx - dy;
        while (true) {
            ctx.method_25294(x0, y0, x0 + 1, y0 + 1, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = err * 2;
            if (e2 > -dy) { err -= dy; x0 += sx; }
            if (e2 < dx) { err += dx; y0 += sy; }
        }
    }

    private static int espColor(class_1297 e) {
        if (e == currentTarget) return 0xFFFFFF00;
        if (e instanceof net.minecraft.class_1657) {
            return friends.contains(e.method_5477().getString()) ? 0xFF55FF55 : 0xFFFF5555;
        }
        if (e instanceof class_1542) return 0xFF55FFFF;
        if (e instanceof net.minecraft.class_1588) return 0xFFFF8800;
        return 0xFF55FF55;
    }

    private static void drawEsp(class_332 ctx, class_310 mc, float tickDelta) {
        if (!espOn || mc.field_1687 == null || mc.field_1724 == null) return;
        class_4184 camera = mc.field_1773.method_19418();
        if (!camera.method_19332()) return;

        class_243 camPos = camera.method_19326();
        org.joml.Vector3f right = camera.method_35689();
        org.joml.Vector3f up = camera.method_19336();
        org.joml.Vector3f forward = camera.method_19335();

        int sw = mc.method_22683().method_4486();
        int sh = mc.method_22683().method_4502();
        double fov = mc.field_1690.method_41808().method_41753().floatValue();
        double halfFov = Math.toRadians(fov) * 0.5;
        double focal = (sh * 0.5) / Math.tan(halfFov);
        if (!Double.isFinite(focal) || focal <= 0 || halfFov <= 0 || halfFov >= Math.PI * 0.5) return;

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (e == mc.field_1724 || e.method_7325()) continue;

            boolean isItem = e instanceof class_1542;
            if (!isItem && !(e instanceof class_1309)) continue;
            if (e instanceof class_1309 && !((class_1309) e).method_5805()) continue;

            if (isItem) {
                if (!espItemsOn) continue;
            } else {
                boolean isPlayer = e instanceof net.minecraft.class_1657;
                boolean isMob = e instanceof net.minecraft.class_1588;
                boolean isAnimal = e instanceof net.minecraft.class_1429;
                if (isPlayer && !espPlayersOn) continue;
                if (isMob && !espMobsOn) continue;
                if (isAnimal && !espAnimalsOn) continue;
            }

            double dist = mc.field_1724.method_5739(e);
            if (dist > espRange) continue;

            class_238 box = e.method_5829();
            double ox = class_3532.method_16436(tickDelta, e.field_6014, e.method_23317()) - e.method_23317();
            double oy = class_3532.method_16436(tickDelta, e.field_6036, e.method_23318()) - e.method_23318();
            double oz = class_3532.method_16436(tickDelta, e.field_5969, e.method_23321()) - e.method_23321();
            double minX = box.field_1323 + ox, minY = box.field_1322 + oy, minZ = box.field_1321 + oz;
            double maxX = box.field_1320 + ox, maxY = box.field_1325 + oy, maxZ = box.field_1324 + oz;

            float minSx = Float.POSITIVE_INFINITY, minSy = Float.POSITIVE_INFINITY;
            float maxSx = Float.NEGATIVE_INFINITY, maxSy = Float.NEGATIVE_INFINITY;
            boolean fullyVisible = true;

            for (int i = 0; i < 8; i++) {
                double px = (i & 1) == 0 ? minX : maxX;
                double py = (i & 2) == 0 ? minY : maxY;
                double pz = (i & 4) == 0 ? minZ : maxZ;
                float[] s = projectToScreen(new class_243(px, py, pz), camPos, right, up, forward, focal, sw, sh);
                if (s == null) { fullyVisible = false; break; }
                minSx = Math.min(minSx, s[0]);
                minSy = Math.min(minSy, s[1]);
                maxSx = Math.max(maxSx, s[0]);
                maxSy = Math.max(maxSy, s[1]);
            }
            if (!fullyVisible || maxSx < minSx || maxSy < minSy) continue;

            int x1 = class_3532.method_15340((int) minSx, 0, sw);
            int y1 = class_3532.method_15340((int) minSy, 0, sh);
            int x2 = class_3532.method_15340((int) maxSx, 0, sw);
            int y2 = class_3532.method_15340((int) maxSy, 0, sh);
            if (x2 - x1 < 2 || y2 - y1 < 2) continue;

            int color = espColor(e);
            if (espFillOn) ctx.method_25294(x1, y1, x2, y2, (color & 0x00FFFFFF) | 0x22000000);

            if (espBoxesOn || isItem) {
                ctx.method_25294(x1, y1, x2, y1 + 1, color);
                ctx.method_25294(x1, y2 - 1, x2, y2, color);
                ctx.method_25294(x1, y1, x1 + 1, y2, color);
                ctx.method_25294(x2 - 1, y1, x2, y2, color);
            }

            if (espTracersOn) {
                drawEspLine(ctx, sw / 2, sh - 1, (x1 + x2) / 2, (y1 + y2) / 2, (color & 0x00FFFFFF) | 0x88000000);
            }

            String label;
            if (isItem) {
                class_1799 stack = ((class_1542) e).method_6983();
                label = stack.method_7964().getString() + " x" + stack.method_7947();
            } else {
                label = PypsenFeatures.label(e.method_5477().getString(), "Entity");
            }

            int textY = Math.max(2, y1 - 11);
            if (espNamesOn) {
                ctx.method_27535(mc.field_1772, class_2561.method_43470(label), x1, textY, color);
                textY -= 10;
            }
            if (espDistanceOn) {
                ctx.method_27535(mc.field_1772, class_2561.method_43470(String.format("%.1fm", dist)), x2 + 3, y1, 0xFFAAAAAA);
            }
            if (espHealthOn && e instanceof class_1309 living) {
                float ratio = living.method_6063() > 0 ? living.method_6032() / living.method_6063() : 0f;
                ratio = class_3532.method_15363(ratio, 0f, 1f);
                int barW = Math.max(1, x2 - x1);
                ctx.method_25294(x1, y2 + 2, x1 + barW, y2 + 5, 0xFF333333);
                ctx.method_25294(x1, y2 + 2, x1 + (int) (barW * ratio), y2 + 5, getHealthColor(living.method_6032(), living.method_6063()));
            }
        }
    }

    private static final Set<Integer> pressedKeys = new HashSet<>();
    private static boolean wasPressed(long handle, int key) {
        if (key == GLFW.GLFW_KEY_UNKNOWN) return false;
        boolean down = GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
        if (down && pressedKeys.add(key)) return true;
        if (!down) pressedKeys.remove(key);
        return false;
    }

    public static String keyName(int key) {
        if (key == GLFW.GLFW_KEY_UNKNOWN) return "NONE";
        String name = GLFW.glfwGetKeyName(key, 0);
        if (name != null) return name.toUpperCase();
        return switch (key) {
            case GLFW.GLFW_KEY_MINUS       -> "MINUS";
            case GLFW.GLFW_KEY_LEFT_SHIFT  -> "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL-> "LCTRL";
            case GLFW.GLFW_KEY_SPACE       -> "SPACE";
            case GLFW.GLFW_KEY_TAB         -> "TAB";
            default -> "KEY_" + key;
        };
    }

    // ══════════ CONFIG SYSTEM ══════════
    public static void saveConfig() {
        try {
            File file = new File(class_310.method_1551().field_1697, "pypsen_config.txt");
            FileWriter writer = new FileWriter(file);
            writer.write("speedVal=" + speedVal + "\n");
            writer.write("auraRange=" + auraRange + "\n");
            writer.write("hitboxVal=" + hitboxVal + "\n");
            writer.write("flySpeed=" + flySpeed + "\n");
            writer.write("clickerCps=" + clickerCps + "\n");
            writer.write("triggerCps=" + triggerCps + "\n");
            writer.write("auraMode=" + auraMode + "\n");
            writer.write("auraBypass=" + auraBypass + "\n");
            writer.write("speedBypass=" + speedBypass + "\n");
            writer.write("flyBypass=" + flyBypass + "\n");
            writer.write("auraRotMode=" + auraRotMode + "\n");
            writer.write("auraTargetMode=" + auraTargetMode + "\n");
            writer.write("auraTimingMode=" + auraTimingMode + "\n");
            writer.write("auraTargetPart=" + auraTargetPart + "\n");
            writer.write("visualsTargetMode=" + visualsTargetMode + "\n");
            writer.write("auraAimJitter=" + auraAimJitter + "\n");
            writer.write("auraStickiness=" + auraStickiness + "\n");
            writer.write("auraRotCurve=" + auraRotCurve + "\n");
            writer.write("auraRotSpeed=" + auraRotSpeed + "\n");
            writer.write("auraFov=" + auraFov + "\n");
            writer.write("triggerRange=" + triggerRange + "\n");
            writer.write("auraTargetPlayers=" + auraTargetPlayers + "\n");
            writer.write("auraTargetMobs=" + auraTargetMobs + "\n");
            writer.write("auraTargetAnimals=" + auraTargetAnimals + "\n");
            writer.write("autoWeapon=" + autoWeapon + "\n");
            writer.write("criticals=" + criticals + "\n");
            writer.write("auraThroughWalls=" + auraThroughWalls + "\n");
            writer.write("auraHitInGuis=" + auraHitInGuis + "\n");
            writer.write("auraSpinBot=" + auraSpinBot + "\n");
            writer.write("triggerWeaponOnly=" + triggerWeaponOnly + "\n");
            writer.write("autoTotemOn=" + autoTotemOn + "\n");
            writer.write("autoTotemHealth=" + autoTotemHealth + "\n");
            writer.write("autoTotemMode=" + autoTotemMode + "\n");
            writer.write("aimLockOn=" + aimLockOn + "\n");
            writer.write("aimOn=" + aimOn + "\n");
            writer.write("aimSpeed=" + aimSpeed + "\n");
            writer.write("antiBotOn=" + antiBotOn + "\n");
            writer.write("fullBrightOn=" + fullBrightOn + "\n");
            writer.write("nameHiderOn=" + nameHiderOn + "\n");
            writer.write("spiderOn=" + spiderOn + "\n");
            writer.write("spiderMode=" + spiderMode + "\n");
            writer.write("noWebOn=" + noWebOn + "\n");
            writer.write("noWebMode=" + noWebMode + "\n");
            writer.write("noclipOn=" + noclipOn + "\n");
            writer.write("noclipBypass=" + noclipBypass + "\n");
            writer.write("freezeOn=" + freezeOn + "\n");
            writer.write("freezeMode=" + freezeMode + "\n");
            writer.write("airJumpOn=" + airJumpOn + "\n");
            writer.write("airJumpMode=" + airJumpMode + "\n");
            writer.write("noFallOn=" + noFallOn + "\n");
            writer.write("noFallMode=" + noFallMode + "\n");
            writer.write("velocityMode=" + velocityMode + "\n");
            writer.write("jesusOn=" + jesusOn + "\n");
            writer.write("jesusMode=" + jesusMode + "\n");
            writer.write("visualsParticles=" + visualsParticles + "\n");
            writer.write("waterCrits=" + waterCrits + "\n");
            writer.write("crasherTimerMode=" + crasherTimerMode + "\n");
            writer.write("godModeMode=" + godModeMode + "\n");
            writer.write("seeInvisOn=" + seeInvisOn + "\n");
            writer.write("noFireOn=" + noFireOn + "\n");
            writer.write("noNauseaOn=" + noNauseaOn + "\n");
            writer.write("targetEspOn=" + targetEspOn + "\n");
            writer.write("noHurtCamOn=" + noHurtCamOn + "\n");
            writer.write("playerEspOn=" + playerEspOn + "\n");
            writer.write("shieldBreaker=" + shieldBreaker + "\n");
            writer.write("keyEsp=" + keyEsp + "\n");
            writer.write("hudOn=" + hudOn + "\n");
            writer.write("targetHudOn=" + targetHudOn + "\n");
            writer.write("fakeName=" + fakeName + "\n");
            writer.write("useModernGui=" + useModernGui + "\n");
            writer.write("espOn=" + espOn + "\n");
            writer.write("espBoxesOn=" + espBoxesOn + "\n");
            writer.write("espNamesOn=" + espNamesOn + "\n");
            writer.write("espHealthOn=" + espHealthOn + "\n");
            writer.write("espDistanceOn=" + espDistanceOn + "\n");
            writer.write("espItemsOn=" + espItemsOn + "\n");
            writer.write("espTracersOn=" + espTracersOn + "\n");
            writer.write("espFillOn=" + espFillOn + "\n");
            writer.write("espPlayersOn=" + espPlayersOn + "\n");
            writer.write("espMobsOn=" + espMobsOn + "\n");
            writer.write("espAnimalsOn=" + espAnimalsOn + "\n");
            writer.write("espRange=" + espRange + "\n");
            writer.write("triggerThroughWalls=" + triggerThroughWalls + "\n");
            writer.write("triggerSmartDelay=" + triggerSmartDelay + "\n");
            writer.write("triggerTargetPlayers=" + triggerTargetPlayers + "\n");
            writer.write("triggerTargetMobs=" + triggerTargetMobs + "\n");
            writer.write("triggerTargetAnimals=" + triggerTargetAnimals + "\n");
            writer.write("triggerAutoWeapon=" + triggerAutoWeapon + "\n");
            writer.write("triggerCriticals=" + triggerCriticals + "\n");
            writer.write("triggerWaitHurtTime=" + triggerWaitHurtTime + "\n");
            writer.write("triggerCooldown=" + triggerCooldown + "\n");
            writer.write("triggerJitter=" + triggerJitter + "\n");
            writer.write("triggerFov=" + triggerFov + "\n");
            writer.write("friends=" + String.join(",", friends) + "\n");
            PypsenFeatures.save(writer);
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void loadConfig() {
        try {
            File file = new File(class_310.method_1551().field_1697, "pypsen_config.txt");
            if (!file.exists()) return;
            List<String> lines = Files.readAllLines(file.toPath());
            for (String line : lines) {
                String[] parts = line.split("=", 2);
                if (parts.length < 2) continue;
                String key = parts[0];
                String val = parts[1];
                switch (key) {
                    case "speedVal" -> speedVal = Float.parseFloat(val);
                    case "auraRange" -> auraRange = Float.parseFloat(val);
                    case "hitboxVal" -> hitboxVal = Float.parseFloat(val);
                    case "flySpeed" -> flySpeed = Float.parseFloat(val);
                    case "clickerCps" -> clickerCps = Float.parseFloat(val);
                    case "triggerCps" -> triggerCps = Float.parseFloat(val);
                    case "auraMode" -> auraMode = Integer.parseInt(val);
                    case "auraBypass" -> auraBypass = Integer.parseInt(val);
                    case "speedBypass" -> speedBypass = Integer.parseInt(val);
                    case "flyBypass" -> flyBypass = Integer.parseInt(val);
                    case "auraRotMode" -> auraRotMode = Integer.parseInt(val);
                    case "auraTargetMode" -> auraTargetMode = Integer.parseInt(val);
                    case "auraTimingMode" -> auraTimingMode = Integer.parseInt(val);
                    case "auraTargetPart" -> auraTargetPart = Integer.parseInt(val);
                    case "visualsTargetMode" -> visualsTargetMode = Integer.parseInt(val);
                    case "auraAimJitter" -> auraAimJitter = Float.parseFloat(val);
                    case "auraStickiness" -> auraStickiness = Float.parseFloat(val);
                    case "auraRotCurve" -> auraRotCurve = Float.parseFloat(val);
                    case "auraRotSpeed" -> auraRotSpeed = Float.parseFloat(val);
                    case "auraFov" -> auraFov = Float.parseFloat(val);
                    case "triggerRange" -> triggerRange = Float.parseFloat(val);
                    case "auraTargetPlayers" -> auraTargetPlayers = Boolean.parseBoolean(val);
                    case "auraTargetMobs" -> auraTargetMobs = Boolean.parseBoolean(val);
                    case "auraTargetAnimals" -> auraTargetAnimals = Boolean.parseBoolean(val);
                    case "autoWeapon" -> autoWeapon = Boolean.parseBoolean(val);
                    case "criticals" -> criticals = Boolean.parseBoolean(val);
                    case "auraThroughWalls" -> auraThroughWalls = Boolean.parseBoolean(val);
                    case "auraHitInGuis" -> auraHitInGuis = Boolean.parseBoolean(val);
                    case "auraSpinBot" -> auraSpinBot = Boolean.parseBoolean(val);
                    case "triggerWeaponOnly" -> triggerWeaponOnly = Boolean.parseBoolean(val);
                    case "autoTotemOn" -> autoTotemOn = Boolean.parseBoolean(val);
                    case "autoTotemHealth" -> autoTotemHealth = Float.parseFloat(val);
                    case "autoTotemMode" -> autoTotemMode = Integer.parseInt(val);
                    case "aimLockOn" -> aimLockOn = Boolean.parseBoolean(val);
                    case "aimOn" -> aimOn = Boolean.parseBoolean(val);
                    case "aimSpeed" -> aimSpeed = Float.parseFloat(val);
                    case "antiBotOn" -> antiBotOn = Boolean.parseBoolean(val);
                    case "fullBrightOn" -> fullBrightOn = Boolean.parseBoolean(val);
                    case "nameHiderOn" -> nameHiderOn = Boolean.parseBoolean(val);
                    case "spiderOn" -> spiderOn = Boolean.parseBoolean(val);
                    case "spiderMode" -> spiderMode = Integer.parseInt(val);
                    case "noWebOn" -> noWebOn = Boolean.parseBoolean(val);
                    case "noWebMode" -> noWebMode = Integer.parseInt(val);
                    case "noclipOn" -> noclipOn = Boolean.parseBoolean(val);
                    case "noclipBypass" -> noclipBypass = Integer.parseInt(val);
                    case "freezeOn" -> freezeOn = Boolean.parseBoolean(val);
                    case "freezeMode" -> freezeMode = Integer.parseInt(val);
                    case "airJumpOn" -> airJumpOn = Boolean.parseBoolean(val);
                    case "airJumpMode" -> airJumpMode = Integer.parseInt(val);
                    case "noFallOn" -> noFallOn = Boolean.parseBoolean(val);
                    case "noFallMode" -> noFallMode = Integer.parseInt(val);
                    case "velocityMode" -> velocityMode = Integer.parseInt(val);
                    case "jesusOn" -> jesusOn = Boolean.parseBoolean(val);
                    case "jesusMode" -> jesusMode = Integer.parseInt(val);
                    case "visualsParticles" -> visualsParticles = Integer.parseInt(val);
                    case "waterCrits" -> waterCrits = Boolean.parseBoolean(val);
                    case "crasherTimerMode" -> crasherTimerMode = Integer.parseInt(val);
                    case "godModeMode" -> godModeMode = Integer.parseInt(val);
                    case "seeInvisOn" -> seeInvisOn = Boolean.parseBoolean(val);
                    case "noFireOn" -> noFireOn = Boolean.parseBoolean(val);
                    case "noNauseaOn" -> noNauseaOn = Boolean.parseBoolean(val);
                    case "targetEspOn" -> targetEspOn = Boolean.parseBoolean(val);
                    case "noHurtCamOn" -> noHurtCamOn = Boolean.parseBoolean(val);
                    case "playerEspOn" -> playerEspOn = Boolean.parseBoolean(val);
                    case "shieldBreaker" -> shieldBreaker = Boolean.parseBoolean(val);
                    case "keyEsp" -> keyEsp = Integer.parseInt(val);
                    case "hudOn" -> hudOn = Boolean.parseBoolean(val);
                    case "targetHudOn" -> targetHudOn = Boolean.parseBoolean(val);
                    case "fakeName" -> fakeName = val;
                    case "useModernGui" -> useModernGui = Boolean.parseBoolean(val);
                    case "espOn" -> espOn = Boolean.parseBoolean(val);
                    case "espBoxesOn" -> espBoxesOn = Boolean.parseBoolean(val);
                    case "espNamesOn" -> espNamesOn = Boolean.parseBoolean(val);
                    case "espHealthOn" -> espHealthOn = Boolean.parseBoolean(val);
                    case "espDistanceOn" -> espDistanceOn = Boolean.parseBoolean(val);
                    case "espItemsOn" -> espItemsOn = Boolean.parseBoolean(val);
                    case "espTracersOn" -> espTracersOn = Boolean.parseBoolean(val);
                    case "espFillOn" -> espFillOn = Boolean.parseBoolean(val);
                    case "espPlayersOn" -> espPlayersOn = Boolean.parseBoolean(val);
                    case "espMobsOn" -> espMobsOn = Boolean.parseBoolean(val);
                    case "espAnimalsOn" -> espAnimalsOn = Boolean.parseBoolean(val);
                    case "espRange" -> espRange = Float.parseFloat(val);
                    case "triggerThroughWalls" -> triggerThroughWalls = Boolean.parseBoolean(val);
                    case "triggerSmartDelay" -> triggerSmartDelay = Boolean.parseBoolean(val);
                    case "triggerTargetPlayers" -> triggerTargetPlayers = Boolean.parseBoolean(val);
                    case "triggerTargetMobs" -> triggerTargetMobs = Boolean.parseBoolean(val);
                    case "triggerTargetAnimals" -> triggerTargetAnimals = Boolean.parseBoolean(val);
                    case "triggerAutoWeapon" -> triggerAutoWeapon = Boolean.parseBoolean(val);
                    case "triggerCriticals" -> triggerCriticals = Boolean.parseBoolean(val);
                    case "triggerWaitHurtTime" -> triggerWaitHurtTime = Boolean.parseBoolean(val);
                    case "triggerCooldown" -> triggerCooldown = Float.parseFloat(val);
                    case "triggerJitter" -> triggerJitter = Float.parseFloat(val);
                    case "triggerFov" -> triggerFov = Float.parseFloat(val);
                    case "friends" -> {
                        friends.clear();
                        if (!val.isEmpty()) friends.addAll(Arrays.asList(val.split(",")));
                    }
                    default -> PypsenFeatures.load(key, val);
                }
            }

            // Keep every parsed value inside the range the GUI and modes expect.
            espRange = class_3532.method_15363(espRange, 5f, 256f);
            triggerRange = class_3532.method_15363(triggerRange, 1f, 12f);
            triggerCps = class_3532.method_15363(triggerCps, 1f, 50f);
            triggerCooldown = class_3532.method_15363(triggerCooldown, 0f, 1f);
            triggerJitter = class_3532.method_15363(triggerJitter, 0f, 100f);
            triggerFov = class_3532.method_15363(triggerFov, 1f, 180f);
            auraMode = class_3532.method_15340(auraMode, 0, AURA_MODES.length - 1);
            auraRotMode = class_3532.method_15340(auraRotMode, 0, AURA_ROTS.length - 1);
            auraTimingMode = class_3532.method_15340(auraTimingMode, 0, AURA_TIMINGS.length - 1);
            auraTargetPart = class_3532.method_15340(auraTargetPart, 0, AURA_PARTS.length - 1);
            auraTargetMode = class_3532.method_15340(auraTargetMode, 0, AURA_TARGETS.length - 1);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ══════════ XRAY SCREEN ══════════
    public static class XrayScreen extends class_437 {
        private final class_437 parent;
        private net.minecraft.class_342 searchField;
        private int scroll = 0;
        private final List<class_2248> allBlocks = new ArrayList<>();
        private final List<class_2248> filteredBlocks = new ArrayList<>();

        public XrayScreen(class_437 parent) {
            super(class_2561.method_43470("XRay Blocks"));
            this.parent = parent;
            class_7923.field_41175.forEach(b -> {
                if (b != class_2246.field_10124 && b != class_2246.field_10543 && b != class_2246.field_10243) {
                    allBlocks.add(b);
                }
            });
            allBlocks.sort(Comparator.comparing(b -> b.method_9518().getString()));
            filteredBlocks.addAll(allBlocks);
        }

        @Override
        protected void method_25426() {
            method_37063(class_4185.method_46430(class_2561.method_43470("<- Back"), b -> {
                class_310.method_1551().method_1507(parent);
                class_310.method_1551().field_1769.method_3279();
            }).method_46434(10, 10, 60, 20).method_46431());

            searchField = new net.minecraft.class_342(field_22793, field_22789 / 2 - 100, 10, 200, 20, class_2561.method_43470("Search"));
            searchField.method_1863(text -> {
                filteredBlocks.clear();
                String q = text.toLowerCase();
                for (class_2248 b : allBlocks) {
                    if (b.method_9518().getString().toLowerCase().contains(q)) {
                        filteredBlocks.add(b);
                    }
                }
                scroll = 0;
            });
            method_37063(searchField);
        }

        @Override
        public void method_25394(class_332 ctx, int mx, int my, float d) {
            method_25420(ctx);
            super.method_25394(ctx, mx, my, d);

            int y = 40 + scroll;
            int x = field_22789 / 2 - 100;

            for (int i = 0; i < filteredBlocks.size(); i++) {
                if (y > 30 && y < field_22790 - 20) {
                    class_2248 b = filteredBlocks.get(i);
                    boolean on = XRAY_BLOCKS.contains(b);
                    String name = b.method_9518().getString();
                    if (name.length() > 25) name = name.substring(0, 25) + "..";

                    boolean hovered = mx >= x && mx <= x + 200 && my >= y && my <= y + 20;
                    ctx.method_25294(x, y, x + 200, y + 20, on ? 0x7700FF00 : (hovered ? 0x77555555 : 0x77000000));
                    ctx.method_25303(field_22793, name, x + 5, y + 6, 0xFFFFFF);
                    ctx.method_25303(field_22793, on ? "ON" : "OFF", x + 175, y + 6, on ? 0x55FF55 : 0xFF5555);
                }
                y += 22;
            }
        }

        @Override
        public boolean method_25402(double mx, double my, int button) {
            if (super.method_25402(mx, my, button)) return true;
            int y = 40 + scroll;
            int x = field_22789 / 2 - 100;
            for (int i = 0; i < filteredBlocks.size(); i++) {
                if (y > 30 && y < field_22790 - 20) {
                    if (mx >= x && mx <= x + 200 && my >= y && my <= y + 20) {
                        class_2248 b = filteredBlocks.get(i);
                        if (XRAY_BLOCKS.contains(b)) XRAY_BLOCKS.remove(b);
                        else XRAY_BLOCKS.add(b);
                        return true;
                    }
                }
                y += 22;
            }
            return false;
        }

        @Override
        public boolean method_25401(double mx, double my, double amount) {
            scroll += (int)(amount * 22);
            if (scroll > 0) scroll = 0;
            int maxScroll = -(filteredBlocks.size() * 22 - (field_22790 - 60));
            if (maxScroll > 0) maxScroll = 0;
            if (scroll < maxScroll) scroll = maxScroll;
            return true;
        }
    }

    // ══════════ MAIN MENU SCREEN ══════════
    public static class MenuScreen extends class_437 {
        private int scroll = 0;
        private int bindingTarget = -1;

        public MenuScreen() { super(class_2561.method_43470("Pypsen v2")); }

        @Override
        protected void method_25426() { buildWidgets(); }

        private void applyPreset(String preset) {
            switch (preset) {
                case "Funtime" -> {
                    auraRange = 3.0f; auraMode = 0; auraRotMode = 2; auraBypass = 7;
                    hitboxVal = 0.1f; velocityOn = true; antiFlagOn = true; auraThroughWalls = false;
                    speedBypass = 7; flyBypass = 7; auraHitInGuis = false; autoWeapon = true; criticals = true;
                }
                case "ReallyWorld" -> {
                    auraRange = 3.0f; auraMode = 0; auraRotMode = 1; auraBypass = 8;
                    hitboxVal = 0.1f; velocityOn = true; antiFlagOn = true; auraThroughWalls = false;
                    speedBypass = 8; flyBypass = 8; auraHitInGuis = false; autoWeapon = true; criticals = true;
                }
                case "Test" -> {
                    auraRange = 3.5f; auraMode = 0; auraRotMode = 2; auraBypass = 4;
                    hitboxVal = 0.5f; velocityOn = false; antiFlagOn = true; auraThroughWalls = false;
                    speedBypass = 4; flyBypass = 4; auraHitInGuis = true; autoWeapon = false; criticals = false;
                }
                case "HvH" -> {
                    auraRange = 6.0f; auraMode = 1; auraRotMode = 3; auraBypass = 0;
                    hitboxVal = 2.0f; velocityOn = true; antiFlagOn = false; auraThroughWalls = true;
                    speedBypass = 0; flyBypass = 0; auraHitInGuis = true; autoWeapon = true; criticals = true;
                }
            }
            rebuild();
        }

        private void buildWidgets() {
            method_37067();
            int x = field_22789 / 2 - 105;
            int y = 30 + scroll;
            int w = 210;

            // Save Config Button
            method_37063(class_4185.method_46430(class_2561.method_43470("\u00a7b\u25BC Save Config to Documents \u25BC"), b -> {
                saveConfig();
            }).method_46434(x, y, w, 20).method_46431()); y += 26;

            method_37063(class_4185.method_46430(class_2561.method_43470("\u00a7d\u2728 Switch to Modern GUI \u2728"), b -> {
                useModernGui = true;
                if (field_22787 != null) field_22787.method_1507(new ModernGuiScreen());
            }).method_46434(x, y, w, 20).method_46431()); y += 26;

            method_37063(class_4185.method_46430(class_2561.method_43470("\u00a7e--- PRESETS ---"), b -> {}).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Funtime"), b -> applyPreset("Funtime")).method_46434(x, y, w/2 - 2, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("ReallyWorld"), b -> applyPreset("ReallyWorld")).method_46434(x + w/2 + 4, y, w/2 - 4, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Test"), b -> applyPreset("Test")).method_46434(x, y, w/2 - 2, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("HvH"), b -> applyPreset("HvH")).method_46434(x + w/2 + 4, y, w/2 - 4, 20).method_46431()); y += 26;

            y = section(x, y, w, "KillAura", auraOn, b -> { auraOn = !auraOn; rebuild(); }, keyAura, 1);
            method_37063(slider(x, y, w, "Range", 1f, 20f, auraRange, v -> auraRange = v)); y += 22;
            method_37063(cycleBtn(x, y, w, "Mode", AURA_MODES, auraMode, v -> { auraMode = v; rebuild(); })); y += 22;
            method_37063(cycleBtn(x, y, w, "Target", AURA_TARGETS, auraTargetMode, v -> { auraTargetMode = v; rebuild(); })); y += 22;
            method_37063(cycleBtn(x, y, w, "Rotation", AURA_ROTS, auraRotMode, v -> { auraRotMode = v; rebuild(); })); y += 22;
            method_37063(cycleBtn(x, y, w, "Timing", AURA_TIMINGS, auraTimingMode, v -> { auraTimingMode = v; rebuild(); })); y += 22;
            method_37063(cycleBtn(x, y, w, "Aim Part", AURA_PARTS, auraTargetPart, v -> { auraTargetPart = v; rebuild(); })); y += 22;
            method_37063(slider(x, y, w, "Aim Jitter", 0f, 1f, auraAimJitter, v -> auraAimJitter = v)); y += 22;
            method_37063(slider(x, y, w, "Stickiness", 0f, 100f, auraStickiness, v -> auraStickiness = v)); y += 22;
            method_37063(slider(x, y, w, "Rot Curve", 0f, 100f, auraRotCurve, v -> auraRotCurve = v)); y += 22;
            method_37063(slider(x, y, w, "Rot Speed", 1f, 180f, auraRotSpeed, v -> auraRotSpeed = v)); y += 22;
            method_37063(slider(x, y, w, "FOV", 10f, 360f, auraFov, v -> auraFov = v)); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Predict: " + (auraPredict ? "§aON" : "§cOFF")), b -> { auraPredict = !auraPredict; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Randomize: " + (auraRandomize ? "§aON" : "§cOFF")), b -> { auraRandomize = !auraRandomize; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(cycleBtn(x, y, w, "Bypass", BYPASS_NAMES, auraBypass, v -> { auraBypass = v; rebuild(); })); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Target Players: " + (auraTargetPlayers ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraTargetPlayers = !auraTargetPlayers; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Target Mobs: " + (auraTargetMobs ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraTargetMobs = !auraTargetMobs; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Target Animals: " + (auraTargetAnimals ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraTargetAnimals = !auraTargetAnimals; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("AutoWeapon: " + (autoWeapon ? "\u00a7aON" : "\u00a7cOFF")), b -> { autoWeapon = !autoWeapon; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Criticals: " + (criticals ? "\u00a7aON" : "\u00a7cOFF")), b -> { criticals = !criticals; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Shield Breaker: " + (shieldBreaker ? "\u00a7aON" : "\u00a7cOFF")), b -> { shieldBreaker = !shieldBreaker; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Water Crits: " + (waterCrits ? "\u00a7aON" : "\u00a7cOFF")), b -> { waterCrits = !waterCrits; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Jump & Attack: " + (auraJump ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraJump = !auraJump; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Through Walls: " + (auraThroughWalls ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraThroughWalls = !auraThroughWalls; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Hit in GUIs: " + (auraHitInGuis ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraHitInGuis = !auraHitInGuis; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("AntiBot: " + (antiBotOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { antiBotOn = !antiBotOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("SpinBot (Idle): " + (auraSpinBot ? "\u00a7aON" : "\u00a7cOFF")), b -> { auraSpinBot = !auraSpinBot; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 26;

            y = section(x, y, w, "Visuals (ESP)", visualsOn, b -> { visualsOn = !visualsOn; rebuild(); }, keyVisuals, 8);
            method_37063(cycleBtn(x, y, w, "Target", VISUALS_TARGETS, visualsTargetMode, v -> { visualsTargetMode = v; rebuild(); })); y += 22;
            method_37063(cycleBtn(x, y, w, "Particles", PARTICLES_MODES, visualsParticles, v -> { visualsParticles = v; rebuild(); })); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Player ESP (Tags): " + (playerEspOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { playerEspOn = !playerEspOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("FullBright: " + (fullBrightOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { fullBrightOn = !fullBrightOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("NameHider (Record): " + (nameHiderOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { nameHiderOn = !nameHiderOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("See Invisibles: " + (seeInvisOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { seeInvisOn = !seeInvisOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("No Fire: " + (noFireOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { noFireOn = !noFireOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("No Nausea: " + (noNauseaOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { noNauseaOn = !noNauseaOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Target ESP: " + (targetEspOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { targetEspOn = !targetEspOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("NoHurtCam: " + (noHurtCamOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { noHurtCamOn = !noHurtCamOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 26;

            y = section(x, y, w, "2D ESP", espOn, b -> { espOn = !espOn; rebuild(); }, keyEsp, 28);
            method_37063(slider(x, y, w, "Range", 5f, 256f, espRange, v -> espRange = v)); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Boxes: " + (espBoxesOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espBoxesOn = !espBoxesOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Names: " + (espNamesOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espNamesOn = !espNamesOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Health: " + (espHealthOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espHealthOn = !espHealthOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Distance: " + (espDistanceOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espDistanceOn = !espDistanceOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Fill: " + (espFillOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espFillOn = !espFillOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Tracers: " + (espTracersOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espTracersOn = !espTracersOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Players: " + (espPlayersOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espPlayersOn = !espPlayersOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Mobs: " + (espMobsOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espMobsOn = !espMobsOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Animals: " + (espAnimalsOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espAnimalsOn = !espAnimalsOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Items: " + (espItemsOn ? "\u00a7aON" : "\u00a7cOFF")), b -> { espItemsOn = !espItemsOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 26;

            y = section(x, y, w, "TriggerBot", triggerBotOn, b -> { triggerBotOn = !triggerBotOn; rebuild(); }, keyTriggerBot, 13);
            method_37063(slider(x, y, w, "CPS", 1f, 50f, triggerCps, v -> triggerCps = v)); y += 22;
            method_37063(slider(x, y, w, "Range", 1f, 12f, triggerRange, v -> triggerRange = v)); y += 22;
            method_37063(slider(x, y, w, "Cooldown", 0f, 1f, triggerCooldown, v -> triggerCooldown = v)); y += 22;
            method_37063(slider(x, y, w, "Jitter %", 0f, 100f, triggerJitter, v -> triggerJitter = v)); y += 22;
            method_37063(slider(x, y, w, "Scan FOV", 1f, 180f, triggerFov, v -> triggerFov = v)); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Weapon Only: " + (triggerWeaponOnly ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerWeaponOnly = !triggerWeaponOnly; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Smart Delay: " + (triggerSmartDelay ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerSmartDelay = !triggerSmartDelay; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Wait Hurt Time: " + (triggerWaitHurtTime ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerWaitHurtTime = !triggerWaitHurtTime; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Through Walls: " + (triggerThroughWalls ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerThroughWalls = !triggerThroughWalls; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Auto Weapon: " + (triggerAutoWeapon ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerAutoWeapon = !triggerAutoWeapon; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Criticals: " + (triggerCriticals ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerCriticals = !triggerCriticals; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Target Players: " + (triggerTargetPlayers ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerTargetPlayers = !triggerTargetPlayers; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Target Mobs: " + (triggerTargetMobs ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerTargetMobs = !triggerTargetMobs; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Target Animals: " + (triggerTargetAnimals ? "\u00a7aON" : "\u00a7cOFF")), b -> { triggerTargetAnimals = !triggerTargetAnimals; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 26;

            y = section(x, y, w, "AutoTotem", autoTotemOn, b -> { autoTotemOn = !autoTotemOn; rebuild(); }, keyAutoTotem, 16);
            method_37063(slider(x, y, w, "Health", 1f, 20f, autoTotemHealth, v -> autoTotemHealth = v)); y += 22;
            method_37063(cycleBtn(x, y, w, "Mode", TOTEM_MODES, autoTotemMode, v -> { autoTotemMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "AutoClicker", autoClickerOn, b -> { autoClickerOn = !autoClickerOn; rebuild(); }, keyAutoClicker, 10);
            method_37063(slider(x, y, w, "CPS", 1f, 50f, clickerCps, v -> clickerCps = v)); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Right Click: " + (autoClickerRight ? "§aON" : "§cOFF")), b -> { autoClickerRight = !autoClickerRight; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 22;
            method_37063(class_4185.method_46430(class_2561.method_43470("Farm Mode: " + (autoClickerFarm ? "§aON" : "§cOFF")), b -> { autoClickerFarm = !autoClickerFarm; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 26;

            y = section(x, y, w, "FreeCam", freecamOn, b -> {
                freecamOn = !freecamOn;
                if (freecamOn && class_310.method_1551().field_1724 != null) {
                    freecamPos = class_310.method_1551().field_1724.method_19538();
                    freecamYaw = class_310.method_1551().field_1724.method_36454();
                    freecamPitch = class_310.method_1551().field_1724.method_36455();
                } else if (!freecamOn && class_310.method_1551().field_1724 != null) {
                    class_310.method_1551().field_1724.field_5960 = false;
                    class_310.method_1551().field_1724.method_31549().field_7479 = false;
                    if (freecamPos != null) {
                        class_310.method_1551().field_1724.method_33574(freecamPos);
                        class_310.method_1551().field_1724.method_36456(freecamYaw);
                        class_310.method_1551().field_1724.method_36457(freecamPitch);
                        class_310.method_1551().field_1724.method_18800(0, 0, 0);
                    }
                }
                rebuild();
            }, keyFreecam, 15); y += 26;

            y = section(x, y, w, "AimAssist", aimOn, b -> { aimOn = !aimOn; rebuild(); }, keyAim, 6);
            method_37063(slider(x, y, w, "Smooth Speed", 1f, 100f, aimSpeed, v -> aimSpeed = v)); y += 26;

            y = section(x, y, w, "\u00a75AimLock (Hard Lock)", aimLockOn, b -> { aimLockOn = !aimLockOn; rebuild(); }, keyAimLock, 17); y += 4;

            y = section(x, y, w, "Hitbox", hitboxOn, b -> { hitboxOn = !hitboxOn; rebuild(); }, keyHitbox, 2);
            method_37063(slider(x, y, w, "Size (Cube)", 0.1f, 1000f, hitboxVal, v -> hitboxVal = v)); y += 26;

            y = section(x, y, w, "Velocity (Anti-KB)", velocityOn, b -> { velocityOn = !velocityOn; rebuild(); }, keyVelocity, 5);
            method_37063(cycleBtn(x, y, w, "Mode", VELOCITY_MODES, velocityMode, v -> { velocityMode = v; rebuild(); })); y += 26;
            y = section(x, y, w, "Strafe", strafeOn, b -> { strafeOn = !strafeOn; rebuild(); }, keyStrafe, 7); y += 4;
            y = section(x, y, w, "Noclip", noclipOn, b -> { noclipOn = !noclipOn; rebuild(); }, keyNoclip, 11);
            method_37063(cycleBtn(x, y, w, "Mode", NOCLIP_MODES, noclipBypass, v -> { noclipBypass = v; rebuild(); })); y += 26;
            y = section(x, y, w, "Anti-Flag", antiFlagOn, b -> { antiFlagOn = !antiFlagOn; rebuild(); }, keyAntiFlag, 12); y += 4;

            y = section(x, y, w, "Spider", spiderOn, b -> { spiderOn = !spiderOn; rebuild(); }, keySpider, 18);
            method_37063(cycleBtn(x, y, w, "Mode", SPIDER_MODES, spiderMode, v -> { spiderMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "NoWeb", noWebOn, b -> { noWebOn = !noWebOn; rebuild(); }, keyNoWeb, 19);
            method_37063(cycleBtn(x, y, w, "Mode", NOWEB_MODES, noWebMode, v -> { noWebMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "Freeze", freezeOn, b -> { freezeOn = !freezeOn; rebuild(); }, keyFreeze, 20);
            method_37063(cycleBtn(x, y, w, "Mode", FREEZE_MODES, freezeMode, v -> { freezeMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "AirJump", airJumpOn, b -> { airJumpOn = !airJumpOn; rebuild(); }, keyAirJump, 25);
            method_37063(cycleBtn(x, y, w, "Mode", AIRJUMP_MODES, airJumpMode, v -> { airJumpMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "NoFall", noFallOn, b -> { noFallOn = !noFallOn; rebuild(); }, keyNoFall, 26);
            method_37063(cycleBtn(x, y, w, "Mode", NOFALL_MODES, noFallMode, v -> { noFallMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "Jesus", jesusOn, b -> { jesusOn = !jesusOn; rebuild(); }, keyJesus, 27);
            method_37063(cycleBtn(x, y, w, "Mode", JESUS_MODES, jesusMode, v -> { jesusMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "Speed", speedOn, b -> { speedOn = !speedOn; rebuild(); }, keySpeed, 0);
            method_37063(slider(x, y, w, "Speed", 0.1f, 100f, speedVal, v -> speedVal = v)); y += 22;
            method_37063(cycleBtn(x, y, w, "Bypass", BYPASS_NAMES, speedBypass, v -> { speedBypass = v; rebuild(); })); y += 26;

            y = section(x, y, w, "Fly", flyOn, b -> { flyOn = !flyOn; rebuild(); }, keyFly, 3);
            method_37063(slider(x, y, w, "Fly Speed", 0.1f, 50f, flySpeed, v -> flySpeed = v)); y += 22;
            method_37063(cycleBtn(x, y, w, "Bypass", BYPASS_NAMES, flyBypass, v -> { flyBypass = v; rebuild(); })); y += 26;

            y = section(x, y, w, "XRay", xrayOn, b -> { xrayOn = !xrayOn; class_310.method_1551().field_1769.method_3279(); rebuild(); }, keyXray, 4);
            method_37063(class_4185.method_46430(class_2561.method_43470("Select XRay Blocks..."), b -> {
                class_310.method_1551().method_1507(new XrayScreen(this));
            }).method_46434(x, y, w, 20).method_46431()); y += 26;

            y = section(x, y, w, "HUD Settings", hudOn, b -> { hudOn = !hudOn; rebuild(); }, GLFW.GLFW_KEY_UNKNOWN, -1);
            method_37063(class_4185.method_46430(class_2561.method_43470("Target HUD: " + (targetHudOn ? "§aON" : "§cOFF")), b -> { targetHudOn = !targetHudOn; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 26;
            method_37063(class_4185.method_46430(class_2561.method_43470("\u00a5 Advanced Features (AI / Crystal / FakeLag / Food)"), b -> {
                class_310.method_1551().method_1507(new PypsenFeatures.FeaturesScreen(this));
            }).method_46434(x, y, w, 20).method_46431()); y += 26;

            y = section(x, y, w, "Server Crasher", serverCrasherOn, b -> { serverCrasherOn = !serverCrasherOn; rebuild(); }, keyCrasher, 21);
            method_37063(cycleBtn(x, y, w, "Mode", CRASHER_MODES, crasherMode, v -> { crasherMode = v; rebuild(); })); y += 22;
            method_37063(cycleBtn(x, y, w, "Timer", CRASHER_TIMERS, crasherTimerMode, v -> { crasherTimerMode = v; rebuild(); })); y += 26;

            y = section(x, y, w, "GodMode", godModeOn, b -> { godModeOn = !godModeOn; rebuild(); }, keyGodMode, 22);
            method_37063(cycleBtn(x, y, w, "Mode", GODMODE_MODES, godModeMode, v -> { godModeMode = v; rebuild(); })); y += 26;
            y = section(x, y, w, "AutoArmor", autoArmorOn, b -> { autoArmorOn = !autoArmorOn; rebuild(); }, keyAutoArmor, 23); y += 4;

            y = section(x, y, w, "FastBow", fastBowOn, b -> { fastBowOn = !fastBowOn; rebuild(); }, keyFastBow, 24);
            method_37063(class_4185.method_46430(class_2561.method_43470("BowJump: " + (bowJump ? "§aON" : "§cOFF")), b -> { bowJump = !bowJump; rebuild(); }).method_46434(x, y, w, 20).method_46431()); y += 26;

            method_37063(class_4185.method_46430(class_2561.method_43470("Drop All Items"), b -> { dropAllItems = true; }).method_46434(x, y, w, 20).method_46431()); y += 26;

            method_37063(bindBtn(x, y, w, "Panic Key", keyPanic, 14)); y += 22;
            method_37063(bindBtn(x, y, w, "Menu Key", keyMenu, 9));
        }

        private int section(int x, int y, int w, String name, boolean on, java.util.function.Consumer<class_4185> toggle, int key, int bindId) {
            int halfW = w / 2 - 2;
            method_37063(class_4185.method_46430(class_2561.method_43470(name + ": " + (on ? "\u00a7aON" : "\u00a7cOFF")), b -> toggle.accept(b)).method_46434(x, y, halfW, 20).method_46431());
            if (bindId != -1) {
                method_37063(bindBtn(x + halfW + 4, y, halfW, "Key", key, bindId));
            }
            return y + 22;
        }

        private class_4185 bindBtn(int x, int y, int w, String label, int key, int id) {
            String text = (bindingTarget == id) ? label + ": \u00a7e[...]" : label + ": \u00a7f" + keyName(key);
            return class_4185.method_46430(class_2561.method_43470(text), b -> { bindingTarget = id; rebuild(); }).method_46434(x, y, w, 20).method_46431();
        }

        private class_4185 cycleBtn(int x, int y, int w, String label, String[] options, int current, java.util.function.Consumer<Integer> setter) {
            return class_4185.method_46430(class_2561.method_43470(label + ": \u00a7b" + options[current]), b -> setter.accept((current + 1) % options.length)).method_46434(x, y, w, 20).method_46431();
        }

        @Override
        public boolean method_25404(int keyCode, int scanCode, int modifiers) {
            if (bindingTarget >= 0 && keyCode != GLFW.GLFW_KEY_ESCAPE) {
                switch (bindingTarget) {
                    case 0 -> keySpeed       = keyCode;
                    case 1 -> keyAura        = keyCode;
                    case 2 -> keyHitbox      = keyCode;
                    case 3 -> keyFly         = keyCode;
                    case 4 -> keyXray        = keyCode;
                    case 5 -> keyVelocity    = keyCode;
                    case 6 -> keyAim         = keyCode;
                    case 7 -> keyStrafe      = keyCode;
                    case 8 -> keyVisuals     = keyCode;
                    case 9 -> keyMenu        = keyCode;
                    case 10 -> keyAutoClicker= keyCode;
                    case 11 -> keyNoclip     = keyCode;
                    case 12 -> keyAntiFlag   = keyCode;
                    case 13 -> keyTriggerBot = keyCode;
                    case 14 -> keyPanic      = keyCode;
                    case 15 -> keyFreecam    = keyCode;
                    case 16 -> keyAutoTotem  = keyCode;
                    case 17 -> keyAimLock    = keyCode;
                    case 18 -> keySpider     = keyCode;
                    case 19 -> keyNoWeb      = keyCode;
                    case 20 -> keyFreeze     = keyCode;
                    case 21 -> keyCrasher    = keyCode;
                    case 22 -> keyGodMode    = keyCode;
                    case 23 -> keyAutoArmor  = keyCode;
                    case 24 -> keyFastBow    = keyCode;
                    case 25 -> keyAirJump    = keyCode;
                    case 26 -> keyNoFall     = keyCode;
                    case 27 -> keyJesus      = keyCode;
                    case 28 -> keyEsp        = keyCode;
                }
                bindingTarget = -1;
                rebuild();
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE && bindingTarget >= 0) {
                bindingTarget = -1;
                rebuild();
                return true;
            }
            return super.method_25404(keyCode, scanCode, modifiers);
        }

        @Override
        public boolean method_25401(double mouseX, double mouseY, double amount) {
            if (bindingTarget >= 0) {
                switch (bindingTarget) {
                    case 0 -> keySpeed       = GLFW.GLFW_KEY_UNKNOWN;
                    case 1 -> keyAura        = GLFW.GLFW_KEY_UNKNOWN;
                    case 2 -> keyHitbox      = GLFW.GLFW_KEY_UNKNOWN;
                    case 3 -> keyFly         = GLFW.GLFW_KEY_UNKNOWN;
                    case 4 -> keyXray        = GLFW.GLFW_KEY_UNKNOWN;
                    case 5 -> keyVelocity    = GLFW.GLFW_KEY_UNKNOWN;
                    case 6 -> keyAim         = GLFW.GLFW_KEY_UNKNOWN;
                    case 7 -> keyStrafe      = GLFW.GLFW_KEY_UNKNOWN;
                    case 8 -> keyVisuals     = GLFW.GLFW_KEY_UNKNOWN;
                    case 9 -> keyMenu        = GLFW.GLFW_KEY_UNKNOWN;
                    case 10 -> keyAutoClicker= GLFW.GLFW_KEY_UNKNOWN;
                    case 11 -> keyNoclip     = GLFW.GLFW_KEY_UNKNOWN;
                    case 12 -> keyAntiFlag   = GLFW.GLFW_KEY_UNKNOWN;
                    case 13 -> keyTriggerBot = GLFW.GLFW_KEY_UNKNOWN;
                    case 14 -> keyPanic      = GLFW.GLFW_KEY_UNKNOWN;
                    case 15 -> keyFreecam    = GLFW.GLFW_KEY_UNKNOWN;
                    case 16 -> keyAutoTotem  = GLFW.GLFW_KEY_UNKNOWN;
                    case 17 -> keyAimLock    = GLFW.GLFW_KEY_UNKNOWN;
                    case 18 -> keySpider     = GLFW.GLFW_KEY_UNKNOWN;
                    case 19 -> keyNoWeb      = GLFW.GLFW_KEY_UNKNOWN;
                    case 20 -> keyFreeze     = GLFW.GLFW_KEY_UNKNOWN;
                    case 21 -> keyCrasher    = GLFW.GLFW_KEY_UNKNOWN;
                    case 22 -> keyGodMode    = GLFW.GLFW_KEY_UNKNOWN;
                    case 23 -> keyAutoArmor  = GLFW.GLFW_KEY_UNKNOWN;
                    case 24 -> keyFastBow    = GLFW.GLFW_KEY_UNKNOWN;
                    case 25 -> keyAirJump    = GLFW.GLFW_KEY_UNKNOWN;
                    case 26 -> keyNoFall     = GLFW.GLFW_KEY_UNKNOWN;
                    case 27 -> keyJesus      = GLFW.GLFW_KEY_UNKNOWN;
                    case 28 -> keyEsp        = GLFW.GLFW_KEY_UNKNOWN;
                }
                bindingTarget = -1;
                rebuild();
                return true;
            }

            scroll += (int)(amount * 25);
            if (scroll > 0) scroll = 0;
            rebuild();
            return true;
        }

        @Override
        public void method_25394(class_332 ctx, int mx, int my, float d) {
            method_25420(ctx);
            ctx.method_25300(field_22793, "\u00a7a\u00a7l\u2588 Pypsen v2 \u2588", field_22789 / 2, 10, 0x55FF55);
            super.method_25394(ctx, mx, my, d);
        }

        @Override public boolean method_25421() { return false; }

        private void rebuild() {
            buildWidgets();
        }
    }

    // ══════════ MODERN GUI SCREEN ══════════
    public static class ModernGuiScreen extends class_437 {
        public static int[] cX = {20, 180, 340, 500};
        public static int[] cY = {40, 40, 40, 40};
        public static Set<String> expanded = new HashSet<>();
        private int[] curY = new int[4];
        private int dragging = -1;
        private int dragX, dragY;
        private int bindingTarget = -1;

        public ModernGuiScreen() { super(class_2561.method_43470("Modern GUI")); }

        @Override
        protected void method_25426() {
            method_37063(class_4185.method_46430(class_2561.method_43470("§c◀ Back to Classic GUI"), b -> {
                useModernGui = false;
                if (field_22787 != null) field_22787.method_1507(new MenuScreen());
            }).method_46434(5, 5, 150, 20).method_46431());

            curY = new int[]{20, 20, 20, 20};

            // Combat
            addMod(0, "KillAura", auraOn, v->auraOn=v, () -> {
                addS(0, "Range", 1f, 20f, auraRange, v->auraRange=v);
                addC(0, "Mode", AURA_MODES, auraMode, v->auraMode=v);
                addC(0, "Target", AURA_TARGETS, auraTargetMode, v->auraTargetMode=v);
                addC(0, "Rotation", AURA_ROTS, auraRotMode, v->auraRotMode=v);
                addC(0, "Timing", AURA_TIMINGS, auraTimingMode, v->auraTimingMode=v);
                addC(0, "Aim Part", AURA_PARTS, auraTargetPart, v->auraTargetPart=v);
                addS(0, "Aim Jitter", 0f, 1f, auraAimJitter, v->auraAimJitter=v);
                addS(0, "Stickiness", 0f, 100f, auraStickiness, v->auraStickiness=v);
                addS(0, "Rot Curve", 0f, 100f, auraRotCurve, v->auraRotCurve=v);
                addS(0, "Rot Speed", 1f, 180f, auraRotSpeed, v->auraRotSpeed=v);
                addS(0, "FOV", 10f, 360f, auraFov, v->auraFov=v);
                addB(0, "Predict", auraPredict, v->auraPredict=v);
                addB(0, "Randomize", auraRandomize, v->auraRandomize=v);
                addC(0, "Bypass", BYPASS_NAMES, auraBypass, v->auraBypass=v);
                addB(0, "Target Players", auraTargetPlayers, v->auraTargetPlayers=v);
                addB(0, "Target Mobs", auraTargetMobs, v->auraTargetMobs=v);
                addB(0, "Target Animals", auraTargetAnimals, v->auraTargetAnimals=v);
                addB(0, "AutoWeapon", autoWeapon, v->autoWeapon=v);
                addB(0, "Criticals", criticals, v->criticals=v);
                addB(0, "Shield Breaker", shieldBreaker, v->shieldBreaker=v);
                addB(0, "Water Crits", waterCrits, v->waterCrits=v);
                addB(0, "Jump & Attack", auraJump, v->auraJump=v);
                addB(0, "Through Walls", auraThroughWalls, v->auraThroughWalls=v);
                addB(0, "Hit in GUIs", auraHitInGuis, v->auraHitInGuis=v);
                addB(0, "AntiBot", antiBotOn, v->antiBotOn=v);
                addB(0, "SpinBot (Idle)", auraSpinBot, v->auraSpinBot=v);
                addBind(0, "Bind", 1);
            });
            addMod(0, "AutoClicker", autoClickerOn, v->autoClickerOn=v, () -> {
                addS(0, "CPS", 1f, 50f, clickerCps, v->clickerCps=v);
                addB(0, "Right Click", autoClickerRight, v->autoClickerRight=v);
                addB(0, "Farm Mode", autoClickerFarm, v->autoClickerFarm=v);
            });
            addMod(0, "TriggerBot", triggerBotOn, v->triggerBotOn=v, () -> {
                addS(0, "CPS", 1f, 50f, triggerCps, v->triggerCps=v);
                addS(0, "Range", 1f, 12f, triggerRange, v->triggerRange=v);
                addS(0, "Cooldown", 0f, 1f, triggerCooldown, v->triggerCooldown=v);
                addS(0, "Jitter %", 0f, 100f, triggerJitter, v->triggerJitter=v);
                addS(0, "Scan FOV", 1f, 180f, triggerFov, v->triggerFov=v);
                addB(0, "Weapon Only", triggerWeaponOnly, v->triggerWeaponOnly=v);
                addB(0, "Smart Delay", triggerSmartDelay, v->triggerSmartDelay=v);
                addB(0, "Wait Hurt Time", triggerWaitHurtTime, v->triggerWaitHurtTime=v);
                addB(0, "Through Walls", triggerThroughWalls, v->triggerThroughWalls=v);
                addB(0, "Auto Weapon", triggerAutoWeapon, v->triggerAutoWeapon=v);
                addB(0, "Criticals", triggerCriticals, v->triggerCriticals=v);
                addB(0, "Target Players", triggerTargetPlayers, v->triggerTargetPlayers=v);
                addB(0, "Target Mobs", triggerTargetMobs, v->triggerTargetMobs=v);
                addB(0, "Target Animals", triggerTargetAnimals, v->triggerTargetAnimals=v);
            });
            addMod(0, "AutoTotem", autoTotemOn, v->autoTotemOn=v, () -> {
                addS(0, "Health", 1f, 20f, autoTotemHealth, v->autoTotemHealth=v);
                addC(0, "Mode", TOTEM_MODES, autoTotemMode, v->autoTotemMode=v);
            });
            addMod(0, "AutoArmor", autoArmorOn, v->autoArmorOn=v, null);
            addMod(0, "FastBow", fastBowOn, v->fastBowOn=v, () -> {
                addB(0, "BowJump", bowJump, v->bowJump=v);
            });
            addMod(0, "AimAssist", aimOn, v->aimOn=v, () -> {
                addS(0, "Smooth Speed", 1f, 100f, aimSpeed, v->aimSpeed=v);
            });
            addMod(0, "AimLock", aimLockOn, v->aimLockOn=v, null);
            addMod(0, "Hitbox", hitboxOn, v->hitboxOn=v, () -> {
                addS(0, "Size", 0.1f, 1000f, hitboxVal, v->hitboxVal=v);
            });
            addMod(0, "AntiBot", antiBotOn, v->antiBotOn=v, null);

            // Movement
            addMod(1, "Speed", speedOn, v->speedOn=v, () -> {
                addS(1, "Speed", 0.1f, 100f, speedVal, v->speedVal=v);
                addC(1, "Bypass", BYPASS_NAMES, speedBypass, v->speedBypass=v);
            });
            addMod(1, "Fly", flyOn, v->flyOn=v, () -> {
                addS(1, "Speed", 0.1f, 50f, flySpeed, v->flySpeed=v);
                addC(1, "Bypass", BYPASS_NAMES, flyBypass, v->flyBypass=v);
            });
            addMod(1, "Spider", spiderOn, v->spiderOn=v, () -> {
                addC(1, "Mode", SPIDER_MODES, spiderMode, v->spiderMode=v);
            });
            addMod(1, "NoWeb", noWebOn, v->noWebOn=v, () -> {
                addC(1, "Mode", NOWEB_MODES, noWebMode, v->noWebMode=v);
            });
            addMod(1, "Freeze", freezeOn, v->freezeOn=v, () -> {
                addC(1, "Mode", FREEZE_MODES, freezeMode, v->freezeMode=v);
                addBind(1, "Bind", 20);
            });
            addMod(1, "AirJump", airJumpOn, v->airJumpOn=v, () -> {
                addC(1, "Mode", AIRJUMP_MODES, airJumpMode, v->airJumpMode=v);
                addBind(1, "Bind", 25);
            });
            addMod(1, "NoFall", noFallOn, v->noFallOn=v, () -> {
                addC(1, "Mode", NOFALL_MODES, noFallMode, v->noFallMode=v);
                addBind(1, "Bind", 26);
            });
            addMod(1, "Jesus", jesusOn, v->jesusOn=v, () -> {
                addC(1, "Mode", JESUS_MODES, jesusMode, v->jesusMode=v);
                addBind(1, "Bind", 27);
            });
            addMod(1, "Noclip", noclipOn, v->noclipOn=v, () -> {
                addC(1, "Mode", NOCLIP_MODES, noclipBypass, v->noclipBypass=v);
                addBind(1, "Bind", 11);
            });
            addMod(1, "Velocity", velocityOn, v->velocityOn=v, () -> {
                addC(1, "Mode", VELOCITY_MODES, velocityMode, v->velocityMode=v);
            });
            addMod(1, "Strafe", strafeOn, v->strafeOn=v, null);
            addMod(1, "Anti-Flag", antiFlagOn, v->antiFlagOn=v, null);

            // Visuals
            addMod(2, "XRay", xrayOn, v->{xrayOn=v; if(field_22787!=null)field_22787.field_1769.method_3279();}, () -> {
                method_37063(class_4185.method_46430(class_2561.method_43470("Select Blocks..."), b -> {
                    if(field_22787!=null) field_22787.method_1507(new XrayScreen(this));
                }).method_46434(cX[2] + 5, cY[2] + curY[2], 140, 20).method_46431());
                curY[2] += 22;
            });
            addMod(2, "Glowing ESP", visualsOn, v->visualsOn=v, () -> {
                addC(2, "Target", VISUALS_TARGETS, visualsTargetMode, v->visualsTargetMode=v);
                addBind(2, "Bind", 8);
            });
            addMod(2, "2D ESP", espOn, v->espOn=v, () -> {
                addS(2, "Range", 5f, 256f, espRange, v->espRange=v);
                addB(2, "Boxes", espBoxesOn, v->espBoxesOn=v);
                addB(2, "Names", espNamesOn, v->espNamesOn=v);
                addB(2, "Health", espHealthOn, v->espHealthOn=v);
                addB(2, "Distance", espDistanceOn, v->espDistanceOn=v);
                addB(2, "Fill", espFillOn, v->espFillOn=v);
                addB(2, "Tracers", espTracersOn, v->espTracersOn=v);
                addB(2, "Players", espPlayersOn, v->espPlayersOn=v);
                addB(2, "Mobs", espMobsOn, v->espMobsOn=v);
                addB(2, "Animals", espAnimalsOn, v->espAnimalsOn=v);
                addB(2, "Items", espItemsOn, v->espItemsOn=v);
                addBind(2, "Bind", 28);
            });
            addMod(2, "Target HUD", targetHudOn, v->targetHudOn=v, null);
            addMod(2, "Player ESP", playerEspOn, v->playerEspOn=v, null);
            addMod(2, "FullBright", fullBrightOn, v->fullBrightOn=v, null);
            addMod(2, "NameHider", nameHiderOn, v->nameHiderOn=v, null);
            addMod(2, "See Invis", seeInvisOn, v->seeInvisOn=v, null);
            addMod(2, "Target ESP", targetEspOn, v->targetEspOn=v, null);
            addMod(2, "No Fire", noFireOn, v->noFireOn=v, null);
            addMod(2, "No Nausea", noNauseaOn, v->noNauseaOn=v, null);
            addMod(2, "NoHurtCam", noHurtCamOn, v->noHurtCamOn=v, null);

            // Misc
            addMod(3, "Freecam", freecamOn, v->{
                freecamOn=v;
                if (field_22787 != null && field_22787.field_1724 != null) {
                    if (freecamOn) {
                        freecamPos = field_22787.field_1724.method_19538();
                        freecamYaw = field_22787.field_1724.method_36454();
                        freecamPitch = field_22787.field_1724.method_36455();
                    } else {
                        field_22787.field_1724.field_5960 = false;
                        field_22787.field_1724.method_31549().field_7479 = false;
                        if (freecamPos != null) {
                            field_22787.field_1724.method_33574(freecamPos);
                            field_22787.field_1724.method_36456(freecamYaw);
                            field_22787.field_1724.method_36457(freecamPitch);
                            field_22787.field_1724.method_18800(0, 0, 0);
                        }
                    }
                }
            }, null);
            addMod(3, "GodMode", godModeOn, v->godModeOn=v, () -> {
                addC(3, "Mode", GODMODE_MODES, godModeMode, v->godModeMode=v);
                addBind(3, "Bind", 22);
            });
            addMod(3, "Server Crasher", serverCrasherOn, v->serverCrasherOn=v, () -> {
                addC(3, "Mode", CRASHER_MODES, crasherMode, v->crasherMode=v);
                addC(3, "Timer", CRASHER_TIMERS, crasherTimerMode, v->crasherTimerMode=v);
            });
            method_37063(class_4185.method_46430(class_2561.method_43470("Drop All Items"), b -> { dropAllItems = true; }).method_46434(cX[3], cY[3] + curY[3], 150, 20).method_46431()); curY[3]+=22;
            addMod(3, "Panic", panicOn, v->panicOn=v, null);
            method_37063(class_4185.method_46430(class_2561.method_43470("\u00a5 Advanced Features"), b -> {
                class_310.method_1551().method_1507(new PypsenFeatures.FeaturesScreen(this));
            }).method_46434(cX[3], cY[3] + curY[3], 150, 20).method_46431()); curY[3] += 22;
        }

        private void addMod(int col, String name, boolean val, java.util.function.Consumer<Boolean> act, Runnable settings) {
            int x = cX[col];
            int y = cY[col] + curY[col];
            int w = settings != null ? 130 : 150;
            method_37063(class_4185.method_46430(class_2561.method_43470(name + ": " + (val?"§aON":"§cOFF")), b -> { act.accept(!val); rebuild(); }).method_46434(x, y, w, 20).method_46431());
            if (settings != null) {
                boolean isExp = expanded.contains(name);
                method_37063(class_4185.method_46430(class_2561.method_43470(isExp ? "-" : "+"), b -> {
                    if (isExp) expanded.remove(name); else expanded.add(name);
                    rebuild();
                }).method_46434(x + 130, y, 20, 20).method_46431());
                curY[col] += 22;
                if (isExp) {
                    settings.run();
                }
            } else {
                curY[col] += 22;
            }
        }

        private void addS(int col, String label, float min, float max, float val, java.util.function.Consumer<Float> setter) {
            method_37063(slider(cX[col] + 5, cY[col] + curY[col], 140, label, min, max, val, v -> setter.accept(v)));
            curY[col] += 22;
        }

        private void addC(int col, String label, String[] options, int current, java.util.function.Consumer<Integer> setter) {
            method_37063(class_4185.method_46430(class_2561.method_43470(label + ": §b" + options[current]), b -> { setter.accept((current + 1) % options.length); rebuild(); }).method_46434(cX[col] + 5, cY[col] + curY[col], 140, 20).method_46431());
            curY[col] += 22;
        }

        private void addB(int col, String label, boolean val, java.util.function.Consumer<Boolean> act) {
            method_37063(class_4185.method_46430(class_2561.method_43470(label + ": " + (val?"§aON":"§cOFF")), b -> { act.accept(!val); rebuild(); }).method_46434(cX[col] + 5, cY[col] + curY[col], 140, 20).method_46431());
            curY[col] += 22;
        }

        private int getKeyCode(int id) {
            return switch(id) {
                case 0 -> keySpeed; case 1 -> keyAura; case 2 -> keyHitbox; case 3 -> keyFly;
                case 4 -> keyXray; case 5 -> keyVelocity; case 6 -> keyAim; case 7 -> keyStrafe;
                case 8 -> keyVisuals; case 9 -> keyMenu; case 10 -> keyAutoClicker; case 11 -> keyNoclip;
                case 12 -> keyAntiFlag; case 13 -> keyTriggerBot; case 14 -> keyPanic; case 15 -> keyFreecam;
                case 16 -> keyAutoTotem; case 17 -> keyAimLock; case 18 -> keySpider; case 19 -> keyNoWeb;
                case 20 -> keyFreeze; case 21 -> keyCrasher; case 22 -> keyGodMode; case 23 -> keyAutoArmor;
                case 24 -> keyFastBow; case 25 -> keyAirJump; case 26 -> keyNoFall; case 27 -> keyJesus;
                case 28 -> keyEsp;
                default -> GLFW.GLFW_KEY_UNKNOWN;
            };
        }

        private void addBind(int col, String label, int keyId) {
            int currentKey = getKeyCode(keyId);
            String text = (bindingTarget == keyId) ? label + ": §e[...]" : label + ": §f" + keyName(currentKey);
            method_37063(class_4185.method_46430(class_2561.method_43470(text), b -> { bindingTarget = keyId; rebuild(); }).method_46434(cX[col] + 5, cY[col] + curY[col], 140, 20).method_46431());
            curY[col] += 22;
        }

        @Override
        public boolean method_25402(double mx, double my, int button) {
            if (bindingTarget != -1) {
                if (button == 2) { // Middle click to unbind
                    switch (bindingTarget) {
                        case 0 -> keySpeed = GLFW.GLFW_KEY_UNKNOWN; case 1 -> keyAura = GLFW.GLFW_KEY_UNKNOWN;
                        case 2 -> keyHitbox = GLFW.GLFW_KEY_UNKNOWN; case 3 -> keyFly = GLFW.GLFW_KEY_UNKNOWN;
                        case 4 -> keyXray = GLFW.GLFW_KEY_UNKNOWN; case 5 -> keyVelocity = GLFW.GLFW_KEY_UNKNOWN;
                        case 6 -> keyAim = GLFW.GLFW_KEY_UNKNOWN; case 7 -> keyStrafe = GLFW.GLFW_KEY_UNKNOWN;
                        case 8 -> keyVisuals = GLFW.GLFW_KEY_UNKNOWN; case 9 -> keyMenu = GLFW.GLFW_KEY_UNKNOWN;
                        case 10 -> keyAutoClicker = GLFW.GLFW_KEY_UNKNOWN; case 11 -> keyNoclip = GLFW.GLFW_KEY_UNKNOWN;
                        case 12 -> keyAntiFlag = GLFW.GLFW_KEY_UNKNOWN; case 13 -> keyTriggerBot = GLFW.GLFW_KEY_UNKNOWN;
                        case 14 -> keyPanic = GLFW.GLFW_KEY_UNKNOWN; case 15 -> keyFreecam = GLFW.GLFW_KEY_UNKNOWN;
                        case 16 -> keyAutoTotem = GLFW.GLFW_KEY_UNKNOWN; case 17 -> keyAimLock = GLFW.GLFW_KEY_UNKNOWN;
                        case 18 -> keySpider = GLFW.GLFW_KEY_UNKNOWN; case 19 -> keyNoWeb = GLFW.GLFW_KEY_UNKNOWN;
                        case 20 -> keyFreeze = GLFW.GLFW_KEY_UNKNOWN; case 21 -> keyCrasher = GLFW.GLFW_KEY_UNKNOWN;
                        case 22 -> keyGodMode = GLFW.GLFW_KEY_UNKNOWN; case 23 -> keyAutoArmor = GLFW.GLFW_KEY_UNKNOWN;
                        case 24 -> keyFastBow = GLFW.GLFW_KEY_UNKNOWN; case 25 -> keyAirJump = GLFW.GLFW_KEY_UNKNOWN;
                        case 26 -> keyNoFall = GLFW.GLFW_KEY_UNKNOWN; case 27 -> keyJesus = GLFW.GLFW_KEY_UNKNOWN;
                        case 28 -> keyEsp = GLFW.GLFW_KEY_UNKNOWN;
                    }
                    bindingTarget = -1;
                    rebuild();
                    return true;
                }
            }
            for (int i = 0; i < 4; i++) {
                if (mx >= cX[i] && mx <= cX[i] + 150 && my >= cY[i] && my <= cY[i] + 20) {
                    dragging = i;
                    dragX = (int)mx - cX[i];
                    dragY = (int)my - cY[i];
                    return true;
                }
            }
            return super.method_25402(mx, my, button);
        }

        @Override
        public boolean method_25403(double mx, double my, int button, double dx, double dy) {
            if (dragging >= 0) {
                cX[dragging] = (int)mx - dragX;
                cY[dragging] = (int)my - dragY;
                rebuild();
                return true;
            }
            return super.method_25403(mx, my, button, dx, dy);
        }

        @Override
        public boolean method_25406(double mx, double my, int button) {
            dragging = -1;
            return super.method_25406(mx, my, button);
        }

        @Override
        public boolean method_25404(int keyCode, int scanCode, int modifiers) {
            if (bindingTarget != -1) {
                if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                    bindingTarget = -1;
                    rebuild();
                    return true;
                }
                switch (bindingTarget) {
                    case 0 -> keySpeed = keyCode; case 1 -> keyAura = keyCode;
                    case 2 -> keyHitbox = keyCode; case 3 -> keyFly = keyCode;
                    case 4 -> keyXray = keyCode; case 5 -> keyVelocity = keyCode;
                    case 6 -> keyAim = keyCode; case 7 -> keyStrafe = keyCode;
                    case 8 -> keyVisuals = keyCode; case 9 -> keyMenu = keyCode;
                    case 10 -> keyAutoClicker = keyCode; case 11 -> keyNoclip = keyCode;
                    case 12 -> keyAntiFlag = keyCode; case 13 -> keyTriggerBot = keyCode;
                    case 14 -> keyPanic = keyCode; case 15 -> keyFreecam = keyCode;
                    case 16 -> keyAutoTotem = keyCode; case 17 -> keyAimLock = keyCode;
                    case 18 -> keySpider = keyCode; case 19 -> keyNoWeb = keyCode;
                    case 20 -> keyFreeze = keyCode; case 21 -> keyCrasher = keyCode;
                    case 22 -> keyGodMode = keyCode; case 23 -> keyAutoArmor = keyCode;
                    case 24 -> keyFastBow = keyCode; case 25 -> keyAirJump = keyCode;
                    case 26 -> keyNoFall = keyCode; case 27 -> keyJesus = keyCode;
                    case 28 -> keyEsp = keyCode;
                }
                bindingTarget = -1;
                rebuild();
                return true;
            }
            return super.method_25404(keyCode, scanCode, modifiers);
        }

        @Override
        public void method_25394(class_332 ctx, int mx, int my, float d) {
            method_25420(ctx);
            String[] titles = {"§c⚔ Combat", "§b✈ Movement", "§d✨ Visuals", "§7⚙ Misc"};
            for (int i = 0; i < 4; i++) {
                ctx.method_25294(cX[i], cY[i], cX[i] + 150, cY[i] + 20, 0xFF222222); // Header
                ctx.method_25294(cX[i], cY[i] + 20, cX[i] + 150, cY[i] + curY[i] + 4, 0xAA000000); // Body
                ctx.method_27535(field_22793, class_2561.method_43470(titles[i]), cX[i] + 5, cY[i] + 6, 0xFFFFFF);
            }
            super.method_25394(ctx, mx, my, d);
        }

        @Override public boolean method_25421() { return false; }
        private void rebuild() { method_37067(); method_25426(); }
    }

    private static class_357 slider(int x, int y, int w, String label, float min, float max, float cur, java.util.function.Consumer<Float> cb) {
        return new class_357(x, y, w, 20, class_2561.method_43470(String.format("%s: %.1f", label, cur)), (cur - min) / (max - min)) {
            @Override protected void method_25346() { method_25355(class_2561.method_43470(String.format("%s: %.1f", label, min + field_22753 * (max - min)))); }
            @Override protected void method_25344() { cb.accept((float)(min + field_22753 * (max - min))); }
        };
    }
}
